-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 19, 2017 at 10:26 AM
-- Server version: 5.5.27
-- PHP Version: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `vdo`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

CREATE TABLE IF NOT EXISTS `admin_login` (
  `admin_login_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` text NOT NULL,
  `password` text NOT NULL,
  `image` text NOT NULL,
  `name` text NOT NULL,
  PRIMARY KEY (`admin_login_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `compose`
--

CREATE TABLE IF NOT EXISTS `compose` (
  `compose_id` int(11) NOT NULL AUTO_INCREMENT,
  `from_id` int(20) NOT NULL,
  `to_email` text NOT NULL,
  `from_email` text NOT NULL,
  `emailcc` text NOT NULL,
  `subject` text NOT NULL,
  `message` text NOT NULL,
  `days` int(11) NOT NULL,
  `expiredate` date NOT NULL,
  `filename` text NOT NULL,
  `filesize` text NOT NULL,
  `total` bigint(20) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `formatFileSize` text NOT NULL,
  `formattotal` text NOT NULL,
  PRIMARY KEY (`compose_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `compose`
--

INSERT INTO `compose` (`compose_id`, `from_id`, `to_email`, `from_email`, `emailcc`, `subject`, `message`, `days`, `expiredate`, `filename`, `filesize`, `total`, `created_date`, `formatFileSize`, `formattotal`) VALUES
(1, 1, 'nikunjkaria@altdigital.com', 'manishkumar@afterdoor.com', '', 'test', '<p>test message form final bulid <br></p>', 1, '2017-05-20', 'small(2).mp4,Bonafide-Certificate-without-Photo.jpg', '383631,156822', 540453, '2017-05-19 08:22:40', '383.63 KB,156.82 KB', '540.45');

-- --------------------------------------------------------

--
-- Table structure for table `count`
--

CREATE TABLE IF NOT EXISTS `count` (
  `count_id` int(11) NOT NULL AUTO_INCREMENT,
  `compose_id` text NOT NULL,
  `filename` text NOT NULL,
  `totalcount` text NOT NULL,
  `status` varchar(225) NOT NULL DEFAULT '0',
  `play_date` datetime NOT NULL,
  PRIMARY KEY (`count_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `download`
--

CREATE TABLE IF NOT EXISTS `download` (
  `download_id` int(11) NOT NULL AUTO_INCREMENT,
  `compose_id` text NOT NULL,
  `mail_receiver` text NOT NULL,
  `filename` text NOT NULL,
  `filesize` text NOT NULL,
  `download_date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`download_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `general`
--

CREATE TABLE IF NOT EXISTS `general` (
  `general_id` int(20) NOT NULL AUTO_INCREMENT,
  `site_name` text NOT NULL,
  `address` text NOT NULL,
  `phone` text NOT NULL,
  `email` text NOT NULL,
  `logo` text NOT NULL,
  `days` text NOT NULL,
  `videocount` text NOT NULL,
  `background` text NOT NULL,
  `domain` varchar(225) NOT NULL,
  `file_types` text NOT NULL,
  PRIMARY KEY (`general_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `general`
--

INSERT INTO `general` (`general_id`, `site_name`, `address`, `phone`, `email`, `logo`, `days`, `videocount`, `background`, `domain`, `file_types`) VALUES
(1, 'Alt Balaji', '302, Stayadeve plaza, Behind Hardrock Cafe, Off Veera Desai Road, Andheri West, Mumbai', '9729068040', 'nikunjkaria@altdigital.com', 'logo.png', '1,3,5,7', '4', 'images.jpg', '@altdigital.com', '.jpeg,.png,.mp4');

-- --------------------------------------------------------

--
-- Table structure for table `ldap`
--

CREATE TABLE IF NOT EXISTS `ldap` (
  `ldap_id` int(11) NOT NULL AUTO_INCREMENT,
  `host` varchar(225) NOT NULL,
  `port` varchar(225) NOT NULL,
  `ldap_username` varchar(225) NOT NULL,
  `ldap_password` varchar(225) NOT NULL,
  `domain` varchar(225) NOT NULL,
  PRIMARY KEY (`ldap_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `ldap`
--

INSERT INTO `ldap` (`ldap_id`, `host`, `port`, `ldap_username`, `ldap_password`, `domain`) VALUES
(1, '192.168.0.150', '389', 'example@domain.local', 'Windows@2017', 'domain.local');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE IF NOT EXISTS `register` (
  `register_id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(225) NOT NULL,
  `fname` varchar(225) NOT NULL,
  `lname` varchar(225) NOT NULL,
  `phone` int(11) NOT NULL,
  `password` text NOT NULL,
  `referal_id` text NOT NULL,
  `tempass` text NOT NULL,
  `type` varchar(225) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` varchar(225) NOT NULL DEFAULT '0',
  `userstatus` int(11) NOT NULL DEFAULT '0' COMMENT '1=inactive,0=active',
  `usertype` int(11) NOT NULL DEFAULT '0' COMMENT '0=normal,1=admin',
  PRIMARY KEY (`register_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`register_id`, `email`, `fname`, `lname`, `phone`, `password`, `referal_id`, `tempass`, `type`, `created_at`, `status`, `userstatus`, `usertype`) VALUES
(1, 'vdoadmin@altdigital.com', 'Nikunj', 'Karia', 1234567890, '81dc9bdb52d04dc20036dbd8313ed055', '', '', 'external', '2017-05-19 08:24:37', '1', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `smtp`
--

CREATE TABLE IF NOT EXISTS `smtp` (
  `smtp_id` int(11) NOT NULL AUTO_INCREMENT,
  `host` text NOT NULL,
  `port` text NOT NULL,
  `username` text NOT NULL,
  `password` text NOT NULL,
  PRIMARY KEY (`smtp_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `smtp`
--

INSERT INTO `smtp` (`smtp_id`, `host`, `port`, `username`, `password`) VALUES
(1, 'ssl://smtp.gmail.com', '465', 'mydigitaldelivery@gmail.com', 'Lotus@123');

-- --------------------------------------------------------

--
-- Table structure for table `social`
--

CREATE TABLE IF NOT EXISTS `social` (
  `social_id` int(11) NOT NULL AUTO_INCREMENT,
  `facebook` text NOT NULL,
  `twitter` text NOT NULL,
  `googleplus` text NOT NULL,
  PRIMARY KEY (`social_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
