/* this script is displaying the image preview of general setting picture 
starts here*/
function readURL(input) {

    if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.onload = function (e) {
        $('#blah').attr('src', e.target.result);
        }
        reader.readAsDataURL(input.files[0]);
    }
 }

 $("#logo").change(function(){    readURL(this);	});
 

 /* this script is displaying the image preview of profile picture starts here*/

 function profileprev(input) {

    if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.onload = function (e) {
        $('#profileimageshw').attr('src', e.target.result);
        }
        reader.readAsDataURL(input.files[0]);
    }
 }

 $("#profileimage").change(function(){    profileprev(this); });


 /* this script is updating password starts here*/
    $("#pswd_submit").click(function(){
        var old_pass=$("#old_pass").val();
        var new_pass=$("#new_pass").val();
        var regex_pass=/((?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{6,20})/;
        var re_new_pass=$("#re_new_pass").val();

       if(old_pass=="")
       {
        swal("Please enter old password!");
        $("#old_pass").css('border','2px solid red');
        return false;
       }
        $("#old_pass").css('border','');
       if(new_pass=="")
       {
        swal("Please enter new password!");
        $("#new_pass").css('border','2px solid red');
        return false;
       }
       $("#new_pass").css('border','');
       if(!regex_pass.test(new_pass))
       {
        swal("Can't proceed...!", "Please enter a secure password", "error");
        //alert("please enter secure password");
        return false;
       }
       if(re_new_pass=="")
       {
        swal("Please Re-enter new password!");
        $("#re_new_pass").css('border','2px solid red');
        return false;
       }
       $("#re_new_pass").css('border','');
       if(new_pass && re_new_pass!=="")
       {
        if(new_pass==re_new_pass)
        {
         swal("Good Job", "Passwords match", "success");
         /*swal({
          title: "Are you sure?",
          text: "You will not be able to recover this imaginary file!",
          type: "warning",
          showCancelButton: true,
          confirmButtonColor: "#DD6B55",
          confirmButtonText: "Yes, delete it!",
          closeOnConfirm: false
        },
          function(){
         swal("Deleted!", "Your imaginary file has been deleted.", "success");

          });*/
        
        }

        else
        {
          swal("Can't proceed...", "New Passwords don't match", "error");
          return false;
        }
       }

       
    });

 /* this script for updating background image in general setting*/
 function general_bg(input) {

    if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.onload = function (e) {
        $('#general_bg').attr('src', e.target.result);
        }
        reader.readAsDataURL(input.files[0]);
    }
 }

 $("#background").change(function(){    general_bg(this);  });

/*script is used for  validation on general settings */
 $("#update_gen").click(function(){
  /*console.log("hello");*/
      var phone=$("#phone").val();
      var email=$("#email").val();
      var phone_re = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;
      var email_re= /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
            
       if(!phone_re.test(phone))
       {
        $( "div.failure" ).html("Invalid phone number!!! Please enter correct phone number");
        $( "div.failure" ).fadeIn( 300 ).delay( 1500 ).fadeOut( 400 );
        return false;
       }
       if(!email_re.test(email))
       {
        $( "div.failure" ).html("Invalid email!!! Please enter correct email");
        $( "div.failure" ).fadeIn( 300 ).delay( 1500 ).fadeOut( 400 );
        //alert("email is invalid");
        return false;
       } 
       
           
    });

 
 /* used to show and hide password in profile.php in admin*/
 $("#showHide").click(function () {

 if ($("#new_pass").attr("type")=="password") {
 $("#new_pass").attr("type", "text");
 $("#shwimg").attr("class", "glyphicon glyphicon-eye-open");

 }
 else{
 $("#new_pass").attr("type", "password");
 $("#shwimg").attr("class", "glyphicon glyphicon-eye-close");
 }
 
 });

 /* used to show and hide password in evry where commonly using classes in admin*/
 $(".showHide").click(function () {

 if ($(".pswd").attr("type")=="password") {
 $(".pswd").attr("type", "text");
 $(".shwimg").attr("class", "glyphicon glyphicon-eye-open");

 }
 else{
 $(".pswd").attr("type", "password");
 $(".shwimg").attr("class", "glyphicon glyphicon-eye-close");
 }
 
 });

 /* script for pie chart in dashboard*/

 $(document).ready(function () {
            $('#demo-pie-1').pieChart({
                barColor: '#F39C12',
                trackColor: '#00C0EF',
                lineCap: 'round',
                lineWidth: 20,
                onStep: function (from, to, percent) {
                    $(this.element).find('.pie-value').text(percent.toFixed(1) + '%');
                }
            });


            $('#demo-pie-4').pieChart({
                barColor: '#D94569',
                trackColor: '#00A65A',
                lineCap: 'round',
                lineWidth: 20,
                rotate: 90,
                onStep: function (from, to, percent) {
                    $(this.element).find('.pie-value').text(percent.toFixed(1) + '%');
                }
            });
        });

 $(document).ready(function(){
$("body").on("click", "#checkconnection", function(e) {
        e.preventDefault();
       
        var host= $("#host").val();
        var port= $("#port").val();
        var username= $("#username").val();
        var password= $("#password").val();
        var domains= $("#domains").val();
        $('#check1').html("<i class='fa fa-spinner fa-spin' style='font-size:24px; margin-top:8px;'></i>");
        $.ajax({
            url:base_url +'admin/socialC/CheckConnection/',
            type: 'POST',
            data: {host:host,port:port,username:username,password:password,domains:domains}, 
            success: function(res){
                 //$('#result').html(res);
                 if(res==1){
                  $("#update").prop("disabled", false );
                  $('#check1').html("<p class='alert alert-success' style='font-size:15px;height:34px;padding:5px;width:25%;'>Successfully Connected.</p>");
                  //$("#check1").css("color", " #008000"); 
                }else{
                  $("#update").prop("disabled", true );
                  $('#check1').html("<p class='alert alert-danger' style='font-size:15px;height:34px;padding:5px;width:25%;'>Connection Failed.</p>");
                  //$("#check1").css("color", "#008000");
                }
                }
        });
    });
    });
 $(document).ready(function() {
    $('#example1').DataTable( {
        dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ]
    } );
} );