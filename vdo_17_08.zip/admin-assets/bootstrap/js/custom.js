/*jquery for to email input*/
function onAddTag(tag) {
 alert("Added a tag: " + tag);
}

function onRemoveTag(tag) {
 alert("Removed a tag: " + tag);
}

function onChangeTag(input, tag) {
 alert("Changed a tag: " + tag);
}
$(function() {

 $('.tags_3').tagsinput({
  confirmKeys: [13, 44, 32],
  trimValue: true

 });

 $('.tags_3').on('itemAdded', function(event) {
  // event.item: contains the item
  var curemail = event.item;
  if (!checkEmail(curemail)) {
   $('.tags_3').tagsinput('remove', curemail, {
    preventPost: true
   });
   swal("Email Not Valid!");
  }
 });

 
});
$(function() {

 $('.tags_2').tagsinput({
  confirmKeys: [13, 44, 32],
  trimValue: true

 });

 $('.tags_2').on('itemAdded', function(event) {
  // event.item: contains the item
  var curemail = event.item;
  var email = $(this).val();
  
  if (!checkEmail(curemail)) {
   $('.tags_2').tagsinput('remove', curemail, {
    preventPost: true
   });
   swal("Email Not Valid!");
  }
 });
});

/*jquery for to email input end*/

  $(document).ready(function(){

    var getemail=0;
$('.tags_2').on('itemAdded', function(event) {
       var icount=0;
     getemail=0;
       var curemail = event.item;
       var email= $(".tags_2").val();
       var arr=email.split(',');//split email
       var str=$(".domain").val();
       var domsplt=str.split(',');//split domain
        while (icount < arr.length) {
          var emailnew=arr[icount].split('@');
          var checkemail="@"+emailnew[1];
            if(domsplt.indexOf(checkemail)!="-1"){ 
              getemail=getemail+1;
              $("body .tags_2").prev('div').css("border-color", "#fff");
            }
            else{
                if(getemail==0 && icount!=0 ){
                $('.tags_2').tagsinput('remove', curemail, {
                  preventPost: true
                 });
                swal("Email is restricted.");
                }
            }
           icount++;
        }  
  });


$('.tags_2').on('itemRemoved', function(event) {
  var email = $(".tags_2").val();
       var arr = email.split(',');
       var str=$(".domain").val();
       var domsplt=str.split(',');
     var icount111=0;
     var curemail=event.item;
     /*alert(curemail);*/
      var emailnew=curemail.split('@');
      var checkemail="@"+emailnew[1];
        if(domsplt.indexOf(checkemail)!="-1"){ 
          getemail=getemail-1;
          
        }
});
$('body').on('click', '.check1',function(event) {
  
       var email = $(".tags_2").val();
       var arr = email.split(',');
       var str=$(".domain").val();
       var domsplt=str.split(',');
     var icount111=0;
     var invalcount=0;
    /*alert(foundemail,'check');*/
    if(getemail<=0){
    while (icount111 < arr.length) {
      var emailnew=arr[icount111].split('@');
      var checkemail="@"+emailnew[1];
      
        if(domsplt.indexOf(checkemail)!="-1"){ 
        
        }
        else{
          
             invalcount=invalcount+1;
        }     
         icount111=icount111+1;    
    }

    if(invalcount>0){
      swal("You must have atleast one email form authorised domain ");
      $("body .tags_2").prev('div').css("border-color", "red");
      return false;
    }
  }
});

     $('#register').on('click', function(event) {
 var to = $('.email').val();
 var cc = $('.emailcc').val();
 if (to=="") {
  swal("Email Empty!");
  return false;
 }
 if (cc=="") {
  swal("CC is mandatory!");
  return false;
 }
       });

     /*$('.check').on('click', function(event) {
      alert('k');
      return false;
       });*/

/* used to show and hide password in profile.php in front*/
 $("#showHideuser").click(function () {

 if ($("#new_pass_user").attr("type")=="password") {
 $("#new_pass_user").attr("type", "text");
 $("#shwimguser").attr("class", "glyphicon glyphicon-eye-open");

 }
 else{
 $("#new_pass_user").attr("type", "password");
 $("#shwimguser").attr("class", "glyphicon glyphicon-eye-close");
 }
 
 });

});//ready
    



/*jquery for days radio button*/

$(".toggle-btn:not('.noscript') input[type=radio]").addClass("visuallyhidden");
$(".toggle-btn:not('.noscript') input[type=radio]").change(function() {
 if ($(this).attr("name")) {
  $(this).parent().addClass("success").siblings().removeClass("success")
 } else {
  $(this).parent().toggleClass("success");
 }
});
/*jquery for days radio button end*/


/*for email validation*/
function checkEmail(email) {
  var pattern = /^([a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+(\.[a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+)*|"((([ \t]*\r\n)?[ \t]+)?([\x01-\x08\x0b\x0c\x0e-\x1f\x7f\x21\x23-\x5b\x5d-\x7e\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|\\[\x01-\x09\x0b\x0c\x0d-\x7f\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))*(([ \t]*\r\n)?[ \t]+)?")@(([a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.)+([a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.?$/i;
  return pattern.test(email);
}

function checkEmails() {
 var tags_1 = document.getElementById("tags_1").value;
 var emailArray = tags_1.split(",");
 var invEmails = "";
 var problem_desc = document.getElementById("compose-textarea");

 for (i = 0; i <= (emailArray.length - 1); i++) {
  if (checkEmail(emailArray[i])) {
   //Do what ever with the email.

  } else {
   invEmails += emailArray[i] + "\n";
  }
 }
 if (invEmails != "") {
  alert("Invalid emails:\n" + invEmails);

 }
}
/*email validation end*/

/*for form validation*/
function validateForm() {
 var problem_desc = document.getElementById("compose-textarea");
 var form = document.getElementById("log");
 var sub = document.getElementById("sub");
 var mail = document.getElementById("tags_1");
 var rad = document.getElementById("rad");
 if (problem_desc.value.replace(/ /g, '').length && form.value.replace(/ /g, '').length && sub.value.replace(/ /g, '').length && mail.value.replace(/ /g, '').length && rad.value.replace(/ /g, '').length) {
  return true;
 } 
 else {

  swal("Filed Empty");
  return false;
 }
}

/*for form validation*/

/*tooltip*/
$('a').tooltip();
/*tooltip*/




