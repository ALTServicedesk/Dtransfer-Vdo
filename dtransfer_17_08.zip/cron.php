<?php
$date=date('Y-m-d H:i:s');
/* so again, make your connection */
$sql = new mysqli('localhost','root','12345678','dtransfer');
 // mkdir("testing");
/* write our query */
$query = "select * from files where date(`expiry`) <'$date'";
 
/* set our result information */
$result = $sql->query($query);
 
if ( $result->num_rows > 0 ) {
    while ( $row = $result->fetch_object() ) {
        $files=explode(",",$row->filename);
	 foreach ($files as $key2 => $value2) {
if(file_exists("./server/php/files/". trim($value2))) { 
echo $value2."-----Removed.<br>";
unlink("./server/php/files/". trim($value2)); 
}
	 	
	 }
    }
} else {
    echo 'There are no results to display.';
}
 
/* and close up */
$sql->close();
?>
