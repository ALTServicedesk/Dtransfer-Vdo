<style type="text/css">
.page-center-in {
  display: table-cell;
  padding: none;
  vertical-align: middle;
}
.full-height {
    height:100vh;
   background: #fff none repeat scroll 0 0;
   float: right;
}
.sign-box {
  border: none;
  border-radius: none;
  font-size: 1rem;
  margin: 0 auto;
  padding: 20px;
  position: relative;
  width: 450px;
  max-width: 450px;
}
.sign-box .sign-title {
  color: #3b3b3b !important;
  font-size: 14px !important;
line-height: normal !important;
margin: 0px 0 30px !important;
text-align: left !important;
font-family: "Segoe UI" , "Segoe" , "SegoeUI-Regular-final", Tahoma, Helvetica, Arial, sans-serif;
}
.sign-box a {
  border-bottom: 1px solid transparent;
  color: #000;
  text-decoration: underline;
}
.sign-note {
  color: #3b3b3b;
  font-size: 14px;
  font-family: "Segoe UI" , "Segoe" , "SegoeUI-Regular-final", Tahoma, Helvetica, Arial, sans-serif;
}

.sign-box .btn {
  display: block;
  margin: 15px 0px;
  min-width: 108px;
}
.sign-box .form-control {
  background: rgba(0, 0, 0, 0) none repeat scroll 0 0;
  color: #000 !important;
}
.logo-dt {
  margin-bottom: 60px;
  padding-top: 30px;
}
.input-control {
  height: 29px;
  padding: 0px 3px 0px 3px;
  font-size: 14px;
}
.btnn {
  font-size: 14px;
  border: none;
  background-color: rgb(38, 114, 236);
  min-width: 80px !important;
  padding: 4px 20px 6px 20px;
  color: #fff;
  border-radius: 0;
  font-family: "Segoe UI" , "Segoe" , "SegoeUI-Regular-final", Tahoma, Helvetica, Arial, sans-serif;
}
.btnn:hover{
  background-color: #D4E3FB;
  color:#fff;
}
.signin-btndiv {
  margin-top: 38px;
  margin-bottom: 50px;
}
.reset-passarea {
  font-size: 14px;
  font-family: "Segoe UI" , "Segoe" , "SegoeUI-Regular-final", Tahoma, Helvetica, Arial, sans-serif;
}
.reset-passarea a {
  font-size: 14px;
  font-family: "Segoe UI" , "Segoe" , "SegoeUI-Regular-final", Tahoma, Helvetica, Arial, sans-serif;
  color: #2672ec;
}
.sign-note a {
  font-size: 14px;
  font-family: "Segoe UI" , "Segoe" , "SegoeUI-Regular-final", Tahoma, Helvetica, Arial, sans-serif;
  color: #2672ec;
}
</style>
<div class="page-center" id="homepage">
        <div class="">
            <div class="full-height">
                <form action="<?php echo base_url();?>user/login" method="post" class="sign-box">
                     <div class="logo-dt"> 
                       <img src="<?php echo asset_url();?>img/Grey_FinalLogo_260x35.png" alt="" width="auto" height="auto">
                    </div><!--logo-dt-->

                    <header class="sign-title">Sign In with your organizational email account for ALTBALAJI Employees</header>
                    <?php echo $this->session->flashdata("forgotpassmsg");?>
                    <?php echo $this->session->flashdata("messageverify");?>
            		<?php echo $this->session->flashdata("messagecompleteprofile");?>
            		<?php if(isset($messagelogin)) { echo $messagelogin; } ?>
                    
                    <div class="form-group">
                        <input type="email" name="emaillogin" class="form-control input-control" value="<?php echo set_value('emaillogin');?>" placeholder="someone@example.com" autocomplete="off" requried>
                        <?php echo form_error('emaillogin');?>
                    </div>
                    <div class="form-group">
                        <input type="password" name="passwordlogin" class="form-control input-control" placeholder="Password"/ requried>
                        <?php echo form_error('passwordlogin');?> 
                    </div>
                    <div class="form-group">
                        <!-- <div class="checkbox float-left">
                            <input type="checkbox" id="signed-in"/>
                            <label for="signed-in">Keep me signed in</label>
                        </div> -->
                        <!-- <div class="float-right reset">
                            <a href="<?php echo base_url();?>user/forgotpass">Reset Password</a>
                        </div> -->
                    </div>
                    <div class="signin-btndiv">
                      <button type="submit" class="btn btnn">Sign in</button>
                    </div>
                    
                    <p class="reset-passarea">For external user click 
                      <a href="<?php echo base_url();?>user/forgotpass"> here </a>to reset the password</p>
                    </br>
                    <p class="reset-passarea">You can only send files to ALTBALAJI
                    </p>
                    </br>
                    <p class="sign-note">New to our file transfer portal? <a href="<?php echo base_url();?>user/register">Sign up</a></p>
                    <!--<button type="button" class="close">
                        <span aria-hidden="true">&times;</span>
                    </button>-->
                </form>
            </div>
        </div>
    </div><!--.page-center-->