<table class="table table-bordered table-hover">
						<thead>
							<th>S No.</th>
							<th>Sender</th>
							<th>Receiver</th>
							<th>Current Percentage</th>
							<th>Current File Size</th>
							<th>Total File Size</th>
						</thead>
							<?php
							$i=1;
							foreach ($uploads as $key => $value) {
							?>
							<tr>
								<td><?php echo $i++;?></td>
								<td>To : <?php echo $value->email;?><br>
									CC : <?php echo $value->cc_email;?>
								</td>
								<td><?php echo $value->percentage;?></td>
								
								<td><?php echo $value->percentage;?></td>
								<td><?php echo $value->current_file_size;?></td>
								<td><?php echo $value->total_file_size;?></td>
							</tr>
							<?php
							}
							?>							
					</table>