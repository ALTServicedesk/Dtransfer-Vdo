<input type="hidden" id="type" value="<?php echo $type;?>">
<div class="page-content" id="inboxmailpage">
		<div class="container-fluid">
		<?php echo $this->session->flashdata("deletemessage");?>
			<section class="box-typical mail-box">
				<header class="mail-box-header">
					<div class="mail-box-header-left">
						<a href="<?php echo base_url();?>user/compose" class="btn write"><i class="fa fa-envelope-o"></i> Compose</a>
						<div class="btns-icon">
							<button type="button" class="btn-icon"><i class="font-icon font-icon-refresh-2"></i></button>
							<!-- <button type="button" class="btn-icon"><i class="font-icon font-icon-check-circle"></i></button>
							<button type="button" class="btn-icon"><i class="font-icon font-icon-folder"></i></button> -->
						</div>
					</div>
					<div class="mail-box-header-right">
						<ul class="mail-box-header-nav">
							<li><a href="<?php echo base_url();?>user/sentmail" class="active" >Go to Sent Items</a></li>
						</ul>
						<!-- <div class="search">
							<input type="text" class="form-control form-control-rounded" placeholder="Search"/>
							<button type="submit" class="btn-icon"><i class="font-icon font-icon-search"></i></button>
						</div> -->
					</div>
				</header><!--.mail-box-header-->

				<section class="mail-box-list  scrollable-block">
					<?php
					if($mail!=NULL)
					{			

						foreach ($mail as $key => $value) {
							// count no of attachments
							$filename=explode(",",$value->filename);
							//photo
							$image=$value->staff[0]['image']==""?"assets/img/avatar-2-64.png":"uploads/".$value->staff[0]['image'];
						?>

						<div class="mail-box-item selected-line">
						<?php
						if($this->config->item("user_allow_otp_email")=="yes" || $this->config->item("user_allow_otp_phone")=="yes")
						{
							?>
							<div class="mail-item-link-otp" data-mailid="<?php echo $value->files_id;?>">
							<?php
						}	
						else{
							?>
							<div class="mail-item-link" data-mailid="<?php echo $value->files_id;?>">
							<?php
						}
						?>
								<div class="mail-box-item-header">
									<div class="mail-box-item-photo">
										<img src="<?php echo base_url();?><?php echo $image;?>" alt="">
									</div>
									<div class="tbl mail-box-item-head-tbl">
										<div class="tbl-row">
											<div class="tbl-cell">
												<div class="tbl mail-box-item-user-tbl">
													<div class="tbl-row">
														<div class="tbl-cell tbl-cell-name"><?php echo getExcerpt($value->subject,25);?></div>
														<div class="tbl-cell tbl-cell-new"> <i class="font-icon-clip"></i> <span class="label label-pill label-danger"> <?php echo count($filename);?> </span></div>
														
													</div>
												</div>
											</div>
											<div class="tbl-cell tbl-cell-date"><?php  $time= strtotime($value->timestamp); echo $time = showtime($time);?></div>
										</div>
									</div>
									<div class="mail-box-item-title"><?php echo getExcerpt($value->description,45);?></div>
								</div>
							</div>							
						</div><!--.mail-box-item-->

						<?php
						}
					}
					else
					{
						?>
						<div class="mail-box-item selected-line">
							<div class="mail-box-item-header">
								<div class="mail-box-item-photo">
									<img src="img/photo-64-1.jpg" alt="">
								</div>
								<div class="tbl mail-box-item-head-tbl">
									<div class="tbl-row">
										<div class="tbl-cell">
											<div class="tbl mail-box-item-user-tbl">
												<div class="tbl-row">
													<div class="tbl-cell tbl-cell-name">No Mail</div>
													
												</div>
											</div>
										</div>
									</div>
								</div>
								
							</div>							
						</div><!--.mail-box-item-->
						<?php
					}
					?>

					
				</section><!--.mail-box-list-->

				<section class="mail-box-work-area" id="viewmail">

				</section><!--.mail-box-work-area-->
			</section><!--.mail-box-->
		</div><!--.container-fluid-->
</div><!--.page-content-->
	