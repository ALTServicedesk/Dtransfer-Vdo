<div class="page-content" id="composeresponse">
		<div class="container-fluid">
			<section class="card">
				<header class="card-header card-header-lg">
					All Users
					<!-- <div class="pull-right"><a href="<?php //echo base_url();?>user/adduser" class="btn btn-sm">Add New</a></div> -->
				</header>
				<div class="card-block">
					<div class="row ">

					<table class="table table-bordered table-hover datatable">
						<thead>
							<th>S No.</th>
							<th>Name</th>
							<th>Email</th>
							<th>Phone</th>
							<!-- <th>Group Name</th>
							<th>Actions</th> -->
						</thead>
							<?php
							$i=1;
							//print_r($groups);
							if(!empty($groups)){
								foreach ($groups as $value) {
								?>
								<tr>
									<td><?php echo $i++;?></td>
									<td><?php echo $value->name." ".$value->lname;?></td>
									<td><?php echo $value->email;?></td>
									<td><?php echo $value->phone;?></td>
									<!-- <td><?php //echo $value->groupname;?></td>
									<td>
									
									<a href="<?php //echo base_url();?>user/edituser/<?php //echo $value->user_id;?>" class="btn btn-sm btn-info"><i class="fa fa-pencil"></i></a>
									<a href="<?php //echo base_url();?>user/deleteuser/<?php //echo $value->user_id;?>" class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></a>
									</td> -->
								</tr>
								<?php
								}
							}else{
								//echo'No User in this group';
							}
							?>							
					</table>
					</div>					
				</div>
			</section>
		</div><!--.container-fluid-->
</div><!--.page-content-->
	