
		<div class="page-content" id="overlay">
		<div class="container-fluid" >
		<section class="card">
				<header class="card-header card-header-lg">
					Knowledgebase articles
				</header>
				<div class="card-block">
				<?php $count = 0; ?> 
					<div class="row "><?php foreach($allcategories as $all){  ?>
							<div class="col-md-3">
								<article class="faq-page-quest">
									<header class="faq-page-quest-title">
										<a href="<?php echo base_url();?>support/catarticle/<?php echo $all->ArticleCat_ID;?>"><?php echo ucfirst($all->ArticleCat_Name); ?></a>
									</header>
									<!-- <p><?php // echo $all->Faq_Ans; ?></p> -->
								</article>
							</div>
							
					<?php } ?>

					</div>			
				</div>
			</section>


		</div><!--.container-fluid-->
	</div>
