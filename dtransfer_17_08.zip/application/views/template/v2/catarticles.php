

		<div class="page-content" id="overlay">
		<div class="container-fluid" >
		<section class="card">
				<header class="card-header card-header-lg">
					All Articles
				</header>
				<div class="card-block">
				<?php $count = 0; ?> 
					<div class="row "><?php foreach($allticket as $all){  ?>
							<div class="col-md-2">
								<time datetime="<?php echo date('Y-d-m');?>" class="icon">
								  <em><?php echo date('M');?></em>
								  <strong><?php echo date('l');?></strong>
								  <span><?php echo date('d');?></span>
								</time>
							</div>
							<div class="col-md-10">
									<article class="faq-page-quest">
										<header class="faq-page-quest-title">
											<a href="<?php echo base_url();?>support/article/<?php echo $all->Article_ID;?>"><?php echo ucfirst($all->Article_Title); ?></a>
											<p><?php echo getExcerpt($all->Article_Description,340); ?> <a href="<?php echo base_url();?>support/article/<?php echo $all->Article_ID;?>">Read More.</a></p>
										</header>
										<!-- <p><?php // echo $all->Faq_Ans; ?></p> -->
									</article>
							</div>
							
					<?php } ?>

					</div>			
				</div>
			</section>

						
						
					<p class="text-center">
							<a href="<?php echo base_url();?>support/knowledgebase" class="btn btn-rounded btn-inline btn-primary-outline" type="submit"><i class="fa fa-angle-left"></i> Back</a>
							</p>	

		</div><!--.container-fluid-->
	</div>


