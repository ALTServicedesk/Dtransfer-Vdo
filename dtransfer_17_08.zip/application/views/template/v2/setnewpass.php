<div class="page-center" id="homepage">
        <div class="page-center-in">
            <div class="container-fluid">
                <form action="<?php echo base_url();?>user/updatepass/" method="post" class="sign-box">
                <input type="hidden" name="key" value="<?php echo $key;?>">
                    <div class="sign-avatar">
                        <img src="<?php echo asset_url();?>img/avatar-sign.png" alt="">
                    </div>

                    <header class="sign-title">Change your password</header>
            		<?php echo $this->session->flashdata("forgotpassmsg");?>
            		<?php if(isset($messagelogin)) { echo $messagelogin; } ?>
                    
                    <div class="form-group">
                        <input type="password" placeholder="New Password" name="newpass" id="form_control_1" autocomplete="off" class="form-control" required="">
                        <?php echo form_error('newpass');?>
                    </div>
                    <div class="form-group">
                        <input type="password" placeholder="Confirm Password" name="confirmpass" id="form_control_1" autocomplete="off" class="form-control" required="">
                        <?php echo form_error('confirmpass');?> 
                    </div>
                    <button type="submit" class="btn btn-rounded">Reset Password</button>
                    <p class="sign-note">Know your password? <a href="<?php echo base_url();?>user/login">Login</a></p>
                    <p class="sign-note">New to our website? <a href="<?php echo base_url();?>user/register">Sign up</a></p>
                    <!--<button type="button" class="close">
                        <span aria-hidden="true">&times;</span>
                    </button>-->
                </form>
            </div>
        </div>
    </div><!--.page-center-->