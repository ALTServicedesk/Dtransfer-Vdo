<div class="page-content" id="composeresponse">
		<div class="container-fluid">
			<section class="card">
				<header class="card-header card-header-lg">
					Download Report Page 
				</header>
				<div class="card-block">
					<div class="row ">
					

						<table class="table table-bordered table-hover datatable dt-responsive">
						<thead>
							<th>S No.</th>
							<th>User Name</th>
							<th>User Email</th>
							<th>File Name</th>
							<th>Size</th>
							<th>IP</th>
							<th>Timestamp</th>
						</thead>
							<?php
							$i=1;
							
							foreach ($details as $value) {
							?>
							<tr>
								<td><?php echo $i++;?></td>
								<td><?php echo $value->username;?></td>
								<td><?php echo $value->useremail;?></td>
								<td><?php echo $value->filename;?></td>
								<td><?php echo formatBytes($value->filesize);?></td>
								<td><?php echo $value->ip;?></td>
								<td><?php echo generatedatetime($value->timestamp);?></td>
							</tr>
							<?php
							}
							?>							
					</table>
					</div>					
				</div>
			</section>
		</div><!--.container-fluid-->
</div><!--.page-content-->
	