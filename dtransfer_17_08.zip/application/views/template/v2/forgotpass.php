<style type="text/css">
.page-center-in {
  display: table-cell;
  padding: none;
  vertical-align: middle;
}
.full-height {
    height:100vh;
   background: #fff none repeat scroll 0 0;
   float: right;
}
.sign-box {
  border: none;
  border-radius: none;
  font-size: 1rem;
  margin: 0 auto;
  padding: 20px;
  position: relative;
  width: 450px;
  max-width: 450px;
}
.sign-box .sign-title {
  color: #3b3b3b !important;
  line-height: normal;
  margin: 5px 0 15px;
  text-align: left;
  font-size: 14px !important;
  font-family: "Segoe UI" , "Segoe" , "SegoeUI-Regular-final", Tahoma, Helvetica, Arial, sans-serif;
}
.sign-box a {
  border-bottom: 1px solid transparent;
  color: #000;
  text-decoration: underline;
}
.sign-note {
  color: #3b3b3b;
  font-size: 14px !important;
  font-family: "Segoe UI" , "Segoe" , "SegoeUI-Regular-final", Tahoma, Helvetica, Arial, sans-serif;
}
.sign-box .btn {
  display: block;
  margin: 15px 0px;
  min-width: 108px;
}
.sign-box .form-control {
  background: rgba(0, 0, 0, 0) none repeat scroll 0 0;
  color: #000 !important;
}
.logo-dt {
  margin-bottom: 60px;
  padding-top: 30px;
}
.input-control {
  height: 29px;
  padding: 0px 3px 0px 3px;
  font-size: 14px;
}
.signin-btndiv {
  margin-top: 38px;
  margin-bottom: 50px;
}
.btnn {
  font-size: 14px;
  border: none;
  background-color: rgb(38, 114, 236);
  min-width: 80px !important;
  padding: 4px 20px 6px 20px;
  color: #fff !important;
  border-radius: 0;
  font-family: "Segoe UI" , "Segoe" , "SegoeUI-Regular-final", Tahoma, Helvetica, Arial, sans-serif;
}
.btnn:hover{
  background-color: #D4E3FB;
  color:#fff;
}
.sign-note a {
  font-size: 14px !important;
  font-family: "Segoe UI" , "Segoe" , "SegoeUI-Regular-final", Tahoma, Helvetica, Arial, sans-serif;
  color: #2672ec;
}
</style>
<div class="page-center" id="homepage">
        <div class="">
            <div class="full-height">
                <form action="<?php echo base_url();?>user/forgotpassproccess" method="post" class="sign-box">
                <div class="logo-dt">
                  <img src="<?php echo asset_url();?>img/Grey_FinalLogo_260x35.png" alt="">
                 </div>

                    <header class="sign-title">Forgot Password</header>
            		
            		<?php if(isset($messagelogin)) { echo $messagelogin; } ?>
                    
                    <div class="form-group">
                        <input type="email" name="email" class="form-control input-control" value="<?php echo set_value('email');?>" placeholder="E-Mail" requried>
                        <?php echo form_error('email');?>
                    </div>
                    
                    <div class="signin-btndiv">
                      <button type="submit" class="btn btnn">Reset</button>
                    </div>
                    <p class="sign-note">Know your password? <a href="<?php echo base_url();?>user/login">Login</a></p>
                    <p class="sign-note">New to our file transfer portal? <a href="<?php echo base_url();?>user/register">Sign up</a></p>
                </form>
            </div>
        </div>
    </div><!--.page-center-->