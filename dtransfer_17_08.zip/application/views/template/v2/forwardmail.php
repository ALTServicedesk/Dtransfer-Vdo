
<div class="page-content" id="composestart">
        <div class="container-fluid">
            <section class="card">
                <header class="card-header card-header-lg">
                    Forward Files
                </header>
                <div class="card-block">
                <?php echo $this->session->flashdata("forwardmessage");?>
					<div class="row">
						<table class="table table-bordered table-hover">
							<tr>
                                <th colspan="2">Sender</th>
                                <td colspan="2"><?php echo $files->sendername;?> (<?php echo $files->senderemail;?>)</td>
                            </tr>
                            <tr>
                                <th colspan="2">To</th>
                                <td colspan="2"><?php echo $files->recivername;?> (<?php echo $files->reciveremail;?>)</td>
                            </tr>
							<tr>
								<th colspan="2">Subject</th>
								<td colspan="2"><?php echo $files->subject;?></td>
							</tr>
							<tr>
								<th colspan="2">Description</th>
								<td colspan="2"><?php echo $files->description;?></td>
							</tr>
							<tr>
								<th>One Time</th>
								<td><?php echo $files->onetime==1?"Yes":"No";?></td>
								<th>Validity</th>
								<td><?php echo $files->validity;?> <?php echo $files->validity>1?"Days":"Day";?></td>
							</tr>
						    
                        </table>
                        <br>
                        <?php 
                            $filesname=explode(",",$files->filename);
                        ?>
                        <h5>Files</h5>
                            <table class="table table-bordered table-hover">
                                <tr>
                                    <th>Sno</th>
                                    <th>Name</th>
                                    <th>Filesize</th>
                                </tr>
                            <?php 
                            $i=1;
                            foreach ($filesname as $key => $value) {
                              ?>
                            <tr>
                                <td>
                                <?php echo $i++; ?>
                                </td>
                                <td>
                                <?php echo $value; ?>
                                </td>
                                <td>
                                <?php echo file_size($value); ?>
                                </td>
                                </tr>
                                <?php
                                }
                                ?>
                            </table>
                            <br>
                            <form action="<?php echo base_url();?>user/forwardsubmit" method="post">
                            <input type="hidden" name="mailid" value="<?php echo $files->files_id;?>">
                                <div class="row">
                                    <div class="col-lg-12">                         
                                        <div class="form-group row">
                                            <label class="col-sm-2 form-control-label">Forward To</label>
                                            <div class="col-sm-10">
                                                <p class="form-control-static">
                                                    <textarea class="email-tag-editor" name="email" required></textarea>
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <p class="text-center margintop20">
                                    <button type="submit" class="btn btn-rounded btn-inline btn-primary-outline"><i class="fa fa-share"></i> Forward</button>
                                    </p>
                            </form>
					</div>				
				</div>
                  
		</div><!--.container-fluid-->

		
</div>