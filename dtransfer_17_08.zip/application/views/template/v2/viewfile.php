<div class="page-center" id="homepage">
        <div class="page-center-in">
            <div class="container">
                <section class="card">
                    <header class="card-header card-header-lg">
                        <?php echo $filename;?>
                        <h6 style="float:right;"><strong>Filesize:</strong> <?php echo file_size($filename); ?></h6>
                    </header>
                    <div class="card-block text-center">
                        
                    <a  href="<?php echo base_url();?>files/download/<?php echo $user_id;?>?filename=<?php echo trim($filename);?>" class="btn btn-primary">Download</a>
                    
                    
        
                                 
                    <!-- <button class="btn btn-primary" id="downloadselected">Download Selected</button>

                <a class="yourlinks"></a> -->
                    </div>
            </section>
            </div>
        </div>
    </div><!--.page-center-->