<div class="page-content" id="composeresponse">
		<div class="container-fluid">
			<section class="card">
				<header class="card-header card-header-lg">
					SMTP 
				</header>
				<div class="card-block">
				 <?php if(isset($message)) { echo $message; } ?>
					<div class="row ">
						<form action="<?php echo base_url();?>settings/smtpsettings" method="POST">
                            <div class="form-group form-md-line-input form-md-floating-label">
                                <label for="form_control_1">SMTP Host</label>
                                <input type="text" name="smtphost" value="<?php echo $settings->smtphost;?>" required id="form_control_1" autocomplete="off" class="form-control">
                                <small>*example://name.example.com</small>
                                <?php echo form_error("smtphost");?>
                            </div>

                            <div class="form-group form-md-line-input form-md-floating-label">
                                <label for="form_control_1">SMTP Port</label>
                                <input type="text" name="smtpport" value="<?php echo $settings->smtpport;?>" required id="form_control_1" autocomplete="off" class="form-control">
                                <?php echo form_error("smtpport");?>
                            </div>

                            <div class="form-group form-md-line-input form-md-floating-label">
                                <label for="form_control_1">SMTP User</label>
                                <input type="text" name="smtpuser" value="<?php echo $settings->smtpuser;?>" required id="form_control_1" autocomplete="off" class="form-control">
                                <?php echo form_error("smtpuser");?>
                            </div>

                            <div class="form-group form-md-line-input form-md-floating-label">
                                <label for="form_control_1">SMTP Pass</label>
                                <input type="password" name="smtppass" value="<?php echo $settings->smtppass;?>" required id="form_control_1" autocomplete="off" class="form-control">
                                <?php echo form_error("smtppass");?>
                            </div>

                           
                        <div class="form-actions noborder">
                            <button class="btn blue" type="submit">Update</button>
                        </div>
                    </form>
					</div>					
				</div>
			</section>
		</div><!--.container-fluid-->
</div><!--.page-content-->
	