<div class="page-content" id="composeresponse">
		<div class="container-fluid">
			<section class="card">
				<header class="card-header card-header-lg">
					Upload Stats Report
				</header>
				<form action="<?php echo base_url();?>reports/generateuploads" method="post">
				<div class="card-block">
					<div class="row ">
						<div class="col-md-4">
							<div class="form-group">
								<div class="input-group date">
									<input type="text" class="form-control daterange" name="date" >
									<span class="input-group-addon">
										<i class="font-icon font-icon-calend"></i>
									</span>
								</div>
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">							 
									<div class="col-md-12">
										<select class="form-control selectsearch" name="user_id">
											<option value="" selected>Select User</option>
											<option value="All">All</option>
											<?php
											foreach ($users as $key => $value) {
												echo "<option value='".$value->user_id."'>".$value->name." (".$value->email.")</option>";
											}
											?>
										</select>
									</div>
								</div>
							</div>
							<div class="col-md-2">
								<div class="form-group">
									<button type="submit" class="btn btn-success">Go</button>
								</div>
							</div>
						</form>
						</div>

					</div>					
				</div>
			</section>
		</div><!--.container-fluid-->
</div><!--.page-content-->
	