<div class="page-content" id="composeresponse">
    <div class="container-fluid">
      <section class="card">
        <header class="card-header card-header-lg">
         LDAP Settings
        <small>Configure LDAP settings here</small>
        </header>
        <div class="card-block">
         <?php echo $this->session->flashdata("linkmessage");?>
          <div class="row ">
            <form action="<?php echo base_url();?>settings/ldapupdate" method="POST">
                            <div class="form-group form-md-line-input form-md-floating-label">
                                <label for="form_control_1">Host</label>
                                <input type="text" name="ldaphost" value="<?php echo $value->host?>" required id="host" autocomplete="off" class="form-control">
                                
                            </div>

                            <div class="form-group form-md-line-input form-md-floating-label">
                                <label for="form_control_1">Port</label>
                                <input type="text" name="ldapport" value="<?php echo $value->port;?>" required id="port" autocomplete="off" class="form-control">
                               
                            </div>

                            <div class="form-group form-md-line-input form-md-floating-label">
                                <label for="form_control_1">LDAP Username</label>
                                <input type="text" name="ldapuser" value="<?php echo $value->ldapuser;?>" required id="ldapuser" autocomplete="off" class="form-control">
                                
                            </div>

                            <div class="form-group form-md-line-input form-md-floating-label">
                                <label for="form_control_1">LDAP Password</label>
                                <input type="password" name="ldappass" value="<?php echo $value->ldappass;?>" required id="ldappass" autocomplete="off" class="form-control">
                                
                            </div>
                            <div class="form-group form-md-line-input form-md-floating-label">
                                <label for="form_control_1">Domain</label>
                                <input type="text" name="domain" value="<?php echo $value->domain;?>" required id="domain" autocomplete="off" class="form-control">
                                
                            </div>
                           
                             <div class="form-actions noborder">
                            <input type="submit" value="Update" class="btn blue" disabled="disabled" id="update">  </input>
                            <input type="submit" class="btn btn-primary" id="checkconnection" value="Test Connection"></input>
                            <span style='font-size:24px; margin-top:8px;' id="check1"></span>
                        </div>
                       
                          
                        
                         
                    </form>
          </div>          
        </div>
      </section>
    </div><!--.container-fluid-->
</div><!--.page-content-->
  