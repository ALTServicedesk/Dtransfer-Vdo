<div class="page-content" id="overlay">
		<div class="container-fluid" >
			<h4>System Messages</h4>
			<form id="messages_form">
			<section class="tabs-section">
				<div class="tabs-section-nav tabs-section-nav-icons">
					<div class="tbl">
						<ul role="tablist" class="nav">
							<li class="nav-item">
								<a data-toggle="tab" role="tab" href="#tabs-1-tab-1" class="nav-link active">
									<span class="nav-link-in">
										<i class="font-icon font-icon-cogwheel"></i>
										General
									</span>
								</a>
							</li>
							<li class="nav-item">
								<a data-toggle="tab" role="tab" href="#tabs-1-tab-2" class="nav-link">
									<span class="nav-link-in">
										<span class="glyphicon glyphicon-music"></span>
										Success
									</span>
								</a>
							</li>
							<li class="nav-item">
								<a data-toggle="tab" role="tab" href="#tabs-1-tab-3" class="nav-link">
									<span class="nav-link-in">
										<i class="fa fa-product-hunt"></i>
										Error
									</span>
								</a>
							</li>
							<li class="nav-item">
								<a data-toggle="tab" role="tab" href="#tabs-1-tab-4" class="nav-link">
									<span class="nav-link-in">
										<i class="font-icon font-icon-users"></i>
										Warning
									</span>
								</a>
							</li>
							<li class="nav-item">
								<a data-toggle="tab" role="tab" href="#tabs-1-tab-5" class="nav-link">
									<span class="nav-link-in">
										<i class="font-icon font-icon-home"></i>
										Information
									</span>
								</a>
							</li>
						</ul>
					</div>
				</div><!--.tabs-section-nav-->

				<div class="tab-content">
					<div id="tabs-1-tab-1" class="tab-pane fade in active" role="tabpanel">

						<?php
						foreach ($language['general'] as $key => $value) {
							?>
							<div class="form-group row">
								<label class="col-sm-4 form-control-label"><?php echo $value->name;?></label>
								<div class="col-sm-8">
									<p class="form-control-static">
										<input name="<?php echo $value->language_id;?>" type="text" class="form-control" value="<?php echo $value->token;?>">
										<small class="text-muted"><?php echo $value->description;?></small>
									</p>
								</div>
							</div>
							<?php
						}
						?>

					</div><!--.tab-pane-->
					<div id="tabs-1-tab-2" class="tab-pane fade" role="tabpanel">
						
						<?php
						foreach ($language['success'] as $key => $value) {
							?>
							<div class="form-group row">
								<label class="col-sm-4 form-control-label"><?php echo $value->name;?></label>
								<div class="col-sm-8">
									<p class="form-control-static">
										<input type="text"  name="<?php echo $value->language_id;?>" class="form-control" value="<?php echo $value->token;?>">
										<small class="text-muted"><?php echo $value->description;?></small>
									</p>
								</div>
							</div>
							<?php
						}
						?>

					</div><!--.tab-pane-->
					<div id="tabs-1-tab-3" class="tab-pane fade" role="tabpanel">

						<?php
						foreach ($language['error'] as $key => $value) {
							?>
							<div class="form-group row">
								<label class="col-sm-4 form-control-label"><?php echo $value->name;?></label>
								<div class="col-sm-8">
									<p class="form-control-static">
										<input type="text" name="<?php echo $value->language_id;?>" class="form-control" value="<?php echo $value->token;?>">
										<small class="text-muted"><?php echo $value->description;?></small>
									</p>
								</div>
							</div>
							<?php
						}
						?>

					</div><!--.tab-pane-->
					<div id="tabs-1-tab-4" class="tab-pane fade" role="tabpanel">

						<?php
						foreach ($language['warning'] as $key => $value) {
							?>
							<div class="form-group row">
								<label class="col-sm-4 form-control-label"><?php echo $value->name;?></label>
								<div class="col-sm-8">
									<p class="form-control-static">
										<input type="text" name="<?php echo $value->language_id;?>" class="form-control" value="<?php echo $value->token;?>">
										<small class="text-muted"><?php echo $value->description;?></small>
									</p>
								</div>
							</div>
							<?php
						}
						?>

					</div><!--.tab-pane-->
					<div id="tabs-1-tab-5" class="tab-pane fade" role="tabpanel">

						<?php
						foreach ($language['information'] as $key => $value) {
							?>
							<div class="form-group row">
								<label class="col-sm-4 form-control-label"><?php echo $value->name;?></label>
								<div class="col-sm-8">
									<p class="form-control-static">
										<input type="text" name="<?php echo $value->language_id;?>" class="form-control" value="<?php echo $value->token;?>">
										<small class="text-muted"><?php echo $value->description;?></small>
									</p>
								</div>
							</div>
							<?php
						}
						?>

					</div><!--.tab-pane-->
				</div><!--.tab-content-->
				<p class="text-center margintop40">
				<button class="btn btn-rounded btn-inline btn-primary-outline save_messages" type="button"><i class="fa fa-save"></i> Save</button>
				</p>				
			</form>
			</section>
		</div><!--.container-fluid-->
	</div>