<div class="page-content" id="composestart">
		<div class="container-fluid">
			<section class="card">
				<header class="card-header card-header-lg">
					Fill details  
				</header>
				<form action="<?php echo base_url();?>user/composeupload" method="post" id="uploadform" class="validatetrue">
				<input type="hidden" name="session_id" value="<?php echo $session_id;?>">
				<div class="card-block">
					<div class="row">
					<?php
					if($this->config->item('user_domain_restriction')=='yes')
					{
					?>
						<p style="float:right;color: #E61540;font-size: 12px;padding: 0px 12px ;">* One recipient must be from '<?php echo $parse;?>'</p>
					<?php
					}
					?>
						<div class="col-lg-12">							
							<div class="form-group row">
								<label class="col-sm-2 form-control-label">To</label>
								<div class="col-sm-10">
									<p class="form-group">
										<!-- <textarea class="email-tag-editor tags" name="email" required></textarea> -->
										<input type="email" name="email"  class="form-control <?php if($logged_in_user->type==1){echo "tags_2";}else{echo "tags_1";}?>" placeholder="To:" value="" data-type="email"required/>

										<input type="hidden" name="domain" class="domain" value="<?php echo $domain->domain;?>">
										<small class="text-muted exm" style="font-size: 14px!important;"><?php if($logged_in_user->type==2){echo "Use space or enter to validate email.";}else{ echo "Use space or enter to validate email, You can only send files to "?> <?php echo $domain->domain;?>.
										<?php
											} 
											?> </small>
									</p>
								</div>
							</div>
							<div class="form-group row">
								<label class="col-sm-2 form-control-label">CC</label>
								<div class="col-sm-10">
								<p class="">
									<input type="text" name="cc" id="" class="form-control email-tag-editor cc <?php if($value->type==1){echo "tags_4";}else{echo "tags_3";}?>" placeholder="cc:"  data-type="cc"/>
									<small class="text-muted exm" style="font-size: 14px!important;"><?php if($logged_in_user->type==2){echo "Use space or enter to validate email, You must send atleast one CC email to " ?><?php echo $domain->domain;?> <?php ;}else{ echo "Use space or enter to validate email.";
											} ?></small>
								</p>
									<!-- <p class="form-control-static">
										<textarea class="email-tag-editor" name="cc"></textarea>
										<small class="text-muted">Use space or enter to vailidate email.</small>
									</p> -->
								</div>
							</div>
							<div class="form-group row">
								<label class="col-sm-2 form-control-label">Subject</label>
								<div class="col-sm-10">
									<p class="form-control-static">
										<input type="text" class="form-control" name="subject" placeholder="Subject here" required>
									</p>
								</div>
							</div>
							<div class="form-group row">
								<label class="col-sm-2 form-control-label">Message</label>
								<div class="col-sm-10">
									<p class="form-control-static">
										<textarea class="myeditor" name="description" placeholder="Message goes here." required></textarea>
									</p>
								</div>
							</div>
							<div class="form-group row">
								<label class="col-sm-2 form-control-label">Validity</label>
								<div class="col-sm-6">
										<div data-toggle="buttons" class="btn-group">
										<?php 
										$i=1;
										if ($i==1) {
											$class="active";
										}
						                $cats = explode(",", $domain->no_days);
						                foreach($cats as $cat) {
						                $cat = trim($cat);
						                ?>
				<label class="btn <?php if($i++=="1"){echo "active";}?>">
				<input type="radio" name="validity" value="<?php echo $cat;?>"> <?php echo $cat;?> Day
											</label>
											 <?php
							                    }
							                    ?>
										</div>
								</div>
							</div>
							<div class="form-group row">
								<label class="col-sm-2 form-control-label">One time Download</label>
								<div class="col-sm-10">
										<div data-toggle="buttons" class="btn-group">
											<label class="btn ">
												<input type="radio" checked="" autocomplete="off" name="onetime" value="1"> Yes
											</label>
											<label class="btn active">
												<input type="radio" autocomplete="off" name="onetime" value="0"> No
											</label>
										</div>
								</div>
							</div>
						</div>
					</div>				
				</div>
			</section>
			<p class="text-center margintop40">
				<button type="submit" class="btn btn-rounded btn-inline btn-primary-outline   <?php if($logged_in_user->type==1){echo "check1";}else{echo "check";}?>"><i class="fa fa-save"></i> Next & Upload Files</button>
				</p>
		</div><!--.container-fluid-->
				</form>
</div>
	