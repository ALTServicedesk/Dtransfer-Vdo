<div class="page-content" id="composeresponse">
		<div class="container-fluid">
			<section class="card">
				<header class="card-header card-header-lg">
					Profile 
				</header>
				<div class="card-block">
					<div class="row ">
						<div class="col-md-6">
							<form action="<?php echo base_url();?>user/profile" method="POST">
                                <div class="form-group form-md-line-input form-md-floating-label">
                                        <label class="control-label">First Name</label>
                                        <input type="text" class="form-control" name="name" value="<?php echo $user->name;?>"> </div>
                                    <div class="form-group form-md-line-input form-md-floating-label">
                                        <label class="control-label">Last Name</label>
                                        <input type="text" class="form-control" name="lname" value="<?php echo $user->lname;?>"> </div>
                                    <div class="form-group form-md-line-input form-md-floating-label">
                                        <label class="control-label">Mobile Number</label>
                                        <input type="text" class="form-control" name="phone" value="<?php echo $user->phone;?>"> </div>
                                    
                                    <div class="margiv-top-10">
                                        <button class="btn green" type="submit"> Save Changes </button>
                                      </div>
                                </form>
						</div>
						<div class="col-md-6">
							<?php echo form_open_multipart('user/profileimage');?>
                                <div class="form-group">
                                    <div data-provides="fileinput" class="fileinput fileinput-new">
                                        <div style="width: 200px; height: 200px;" class="fileinput-new thumbnail">
                                        <?php
                                        if($logged_in_user->image=="")
                                        {
                                        	$src='http://www.placehold.it/200x150/EFEFEF/AAAAAA&amp;text=no+image';
                                        }
                                        else{
                                        	$src=base_url()."uploads/".$logged_in_user->image;
                                        }
                                        ?>
                                        <img alt="" style="width: 190px; height: 190px;" id="previewHolder" src="<?php echo $src;?>"> 
                                        </div>
                                        
                                        <div>
                                            <span class="btn default btn-file">
                                                <span class="fileinput-new"> Select New Image </span>
                                                <input type="file" id="imageuploadpreview" name="profileimage"> </span>
                                        </div>
                                    </div>
                                </div>
                                <div class="margin-top-10">
                                    <button class="btn green" type="submit"> Upload </button>
                                </div>
                            </form>
						</div>
					</div>					
				</div>
			</section>
		</div><!--.container-fluid-->
</div><!--.page-content-->
	