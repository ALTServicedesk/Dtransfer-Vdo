<style type="text/css">
.page-center-in {
  display: table-cell;
  padding: none;
  vertical-align: middle;
}
.full-height {
    height:100vh;
   background: #fff none repeat scroll 0 0;
   float: right;
}
.sign-box {
  border: none;
  border-radius: none;
  font-size: 1rem;
  margin: 0 auto;
  padding: 20px;
  position: relative;
  width: 350px;
}
.sign-box .sign-title {
  color: #3b3b3b !important;
  font-size: 1.25rem;
  line-height: normal;
  margin: 5px 0 15px;
  text-align: left;
}
.sign-box a {
  border-bottom: 1px solid transparent;
  color: #000;
  text-decoration: underline;
}
.sign-note {
  color: #000;
}
.sign-box .btn {
  display: block;
  margin: 15px 0px;
  min-width: 108px;
}
.sign-box .form-control {
  background: rgba(0, 0, 0, 0) none repeat scroll 0 0;
  color: #000 !important;
}
</style>
<div class="page-center" id="homepage">
        <div class="">
            <div class="full-height">
                <form action="<?php echo base_url();?>user/completeprofile/<?php echo $user->user_id;?>" method="post" class="sign-box">
                   
                    <header class="sign-title">Profile</header>
            <div class='alert alert-danger'  id="messagewarning">Complete your profile first to start the download.</div>
            		<?php echo $this->session->flashdata("messageregister");?>
            		<?php if(isset($messagelogin)) { echo $messagelogin; } ?>
                    
                    <div class="form-group">
                        <input type="text" class="form-control" placeholder="First Name" name="name" value="<?php echo set_value('name');?>">
                        <?php echo form_error("name");?>
                    </div>
                   
                    <div class="form-group">
                        <input type="text" class="form-control" placeholder="Last Name" name="lname" value="<?php echo set_value('lname');?>"> 
                    <?php echo form_error("lname");?>
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" placeholder="Phone" name="phone" value="<?php echo set_value('phone');?>">
                    <?php echo form_error("phone");?>
                    </div>
                    <div class="form-group">
                        <input type="password" class="form-control" placeholder="Password" name="pass" value=""> 
                        <?php echo form_error("pass");?>
                    </div>
                     <div class="form-group">
                        <input type="password" class="form-control" placeholder="Confirm Password" name="confirmpass" value=""> 
                        <?php echo form_error("confirmpass");?>
                    </div>
                   
                    <button type="submit" class="btn btn-rounded">Save Changes</button>
                    
                </form>
            </div>
        </div>
    </div><!--.page-center-->