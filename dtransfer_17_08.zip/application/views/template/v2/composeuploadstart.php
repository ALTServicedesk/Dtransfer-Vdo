<div class="page-content" id="composestartfinal">
        <div class="container-fluid">
            <section class="card">
                <header class="card-header card-header-lg">
                    Upload Files
                </header>
                <div class="card-block">
					<div class="row">
						<table class="table table-bordered table-hover">
							<tr>
                                <th colspan="2">Email</th>
                                <td colspan="2">
                                <?php echo $this->input->get("email");?></td>
                            </tr>
                            <tr>
                                <th colspan="2">CC</th>
                                <td colspan="2"><?php echo $this->input->get("cc");?></td>
                            </tr>
							<tr>
								<th colspan="2">Subject</th>
								<td colspan="2"><?php echo $this->input->get("subject");?></td>
							</tr>
							<tr>
								<th colspan="2">Description</th>
								<td colspan="2"><?php echo $this->input->get("description");?></td>
							</tr>
							<tr>
								<th>One Time</th>
								<td><?php echo $this->input->get("onetime")==1?"Yes":"No";?></td>
								<th>Validity</th>
								<td><!-- <?php //echo $this->input->get("validity");?> <?php //echo $this->input->get("validity")>1?"Days":"Day";?> -->
                                <?php
                                $today=date('d-m-Y');
                                $one=1;
                                $date=$this->input->get("validity");
                                if ($date=="") {
                                $next_date= date('d-M-Y', strtotime($today. ' + '.$one.'days'));
                                }else{
                                    $next_date= date('d-M-Y', strtotime($today. ' + '.$date.'days'));
                                }
                                echo $next_date;
                                ?>
                                </td>
							</tr>
						</table>
					</div>				
				</div>
                    <form id="fileupload" action="<?php echo base_url();?>user/uploadfile" method="POST" enctype="multipart/form-data">
                    
                    <!-- additional data to be sent-->
                    <input type="hidden" name="session_id" value="<?php echo base64_decode($this->input->get("session_id"));?>">
                    <input type="hidden" name="email" class="email" value="<?php echo $this->input->get("email");?>">
                    <input type="hidden" name="cc" class="cc_email" value="<?php echo $this->input->get("cc");?>">
                    <input type="hidden" name="subject" class="subject" value="<?php echo $this->input->get("subject");?>">
                    <input type="hidden" name="description" class="description" value="<?php echo $this->input->get("description");?>">
                    <input type="hidden" name="onetime" value="<?php echo $this->input->get("onetime");?>">
                    <?php  
                                $one=1;
                                $date=$this->input->get("validity");
                                if ($date=="") {
                                    ?>
                                <input type="hidden" name="validity" class="validity" value="<?php echo $one;?>">
                                <?php
                                }else{
                                    ?>
                                    <input type="hidden" name="validity" class="validity" value="<?php echo $this->input->get("validity");?>">
                                    <?php
                                }
                                ?>
                    
                    <input type="hidden" name="user_id" value="<?php echo $user->user_id;?>">
                     <input type="hidden" name="insert_id" class="insert_id" value="">
                    <!-- additional data to be sent-->

                    <div class="row fileupload-buttonbar">
                    <div class="col-lg-12">
                        <div class="col-lg-12">
                            <!-- The fileinput-button span is used to style the file input field as button -->
                            <span class="btn btn-success fileinput-button">
                                <i class="glyphicon glyphicon-plus"></i>
                                <span>Add files...</span>
                                <input type="file" multiple="" name="files[]">
                            </span>
                            <button class="btn btn-primary start" type="submit">
                                <i class="glyphicon glyphicon-upload"></i>
                                <span>Start upload</span>
                            </button>
                            <button class="btn btn-warning cancel" type="reset">
                                <i class="glyphicon glyphicon-ban-circle"></i>
                                <span>Cancel upload</span>
                            </button>
                            <button class="btn btn-danger delete" type="button">
                                <i class="glyphicon glyphicon-trash"></i>
                                <span>Delete</span>
                            </button>
                            <button type="button" id="uploadman" class="btn btn-info cancel">
                            <i class="fa fa-upload"></i>
                            <span>Send Manually</span>
                             </button>
                            <input type="checkbox" class="toggle">
                            <!-- The global file processing state -->
                            <span class="fileupload-process"></span>
                        </div>
                        <!-- The global progress state -->
                        <div class="col-lg-12 fileupload-progress fade">
                            <!-- The global progress bar -->
                            <div aria-valuemax="100" aria-valuemin="0" role="progressbar" class="progress progress-striped active" aria-valuenow="0">
                                <div style="width:0%;" class="progress-bar progress-bar-success"></div>
                            </div>
                            <!-- The extended global progress state -->
                            <div class="progress-extended " id="get_prog">&nbsp;</div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12 filescontainer">
                        <table class="table table-striped" role="presentation">
                            <tbody class="files">
                            </tbody>
                        </table>
                    </div>
                    <div class="col-md-6">       
                    <table style="margin-left:20px;font-size: 12px">
                    	<tr>
                    		<td>Kb/sec</td>
                    		<td>
	                    		<div class="demo-container">
	                            <div id="containergraph" class="demo-placeholder">
	                            </div>
	                            	<div class="text-center">Time</div>
	                            
	                        	</div>
                        	</td>
                    	</tr>
                    </table>                 
                        
                    </div>
                </div>
        </form>
		</div><!--.container-fluid-->

		
</div>
	<script id="template-upload" type="text/x-tmpl">
{%  for (var i=0, file; file=o.files[i]; i++) { %}
    <tr class="template-upload fade">
        <td>
            <span class=""></span>
        </td>
        <td>
            <p class="name">{%=file.name%}</p>
            <strong class="error text-danger"></strong>
        </td>
        <td>
            <p class="size">Processing...</p>
            <div class="progress progress-striped active" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><div class="progress-bar progress-bar-success" style="width:0%;"></div></div>
        </td>
        <td>
            {% if (!i && !o.options.autoUpload) { %}
                <button class="btn btn-primary start" style="display:none;" disabled>
                    <i class="glyphicon glyphicon-upload"></i>
                    <span></span>
                </button>
            {% } %}
            {% if (!i) { %}
                <button class="btn btn-warning cancel">
                    <i class="glyphicon glyphicon-ban-circle"></i>
                    <span>Cancel</span>
                </button>
            {% } %}
        </td>
    </tr>
{%  } %}
</script>
<!-- The template to display files available for download -->
<script id="template-download" type="text/x-tmpl">
{% for (var i=0, file; file=o.files[i]; i++) { %}
    <tr class="template-download fade">
        <td>
            <span class="">
                {% if (file.thumbnailUrl) { %}
                    <img src="{%=file.thumbnailUrl%}">
                {% } %}
            </span>
        </td>
        <td>
            <p class="name">
                {% if (file.url) { %}
                    {%=file.name%}
                    <input type="hidden" value="{%=file.name%}" name="filename[]" class="file_name">
                    <input type="hidden" value="{%=file.size%}" name="filesize[]" class="file-size">
                {% } else { %}
                    <span>{%=file.name%}</span>
                {% } %}
            </p>
            {% if (file.error) { %}
                <div><span class="label label-danger">Error</span> {%=file.error%}</div>
            {% } %}
        </td>
        <td>
            <span class="size">{%=o.formatFileSize(file.size)%}</span>
        </td>
        <td>
            {% if (file.deleteUrl) { %}
                <button class="btn btn-danger delete" data-type="{%=file.deleteType%}" data-url="{%=file.deleteUrl%}"{% if (file.deleteWithCredentials) { %} data-xhr-fields='{"withCredentials":true}'{% } %}>
                    <i class="glyphicon glyphicon-trash"></i>
                    <span>Delete</span>
                </button>
                <input type="checkbox" name="delete" value="1" class="toggle">
            {% } else { %}
                <button class="btn btn-warning cancel">
                    <i class="glyphicon glyphicon-ban-circle"></i>
                    <span>Cancel</span>
                </button>
            {% } %}
        </td>
    </tr>
{% } %}
</script>