<div class="page-content" id="composeresponse">
		<div class="container-fluid">
			<section class="card">
				<header class="card-header card-header-lg">
					Add User Group
				</header>
				<div class="card-block">
					<?php if(isset($message)) { echo $message; } ?>
					<form action="<?php echo base_url();?>user/addgroup" method="post" class="validatetrue">
						<div class="form-group row">
								<label class="col-sm-2 form-control-label">Group Name</label>
								<div class="col-sm-10">
									<p class="form-control-static">
										<input type="text" required="" placeholder="Group Name" name="name" class="form-control" aria-required="true" aria-invalid="true">
									</p>
									<?php echo form_error('name');?>
								</div>
						</div>
						
						
				</div>
			</section>

				<p class="text-center margintop40">
				<button type="submit" class="btn btn-rounded btn-inline btn-primary-outline"><i class="fa fa-save"></i> Submit</button>
				</p>

				</form>
		</div><!--.container-fluid-->
</div><!--.page-content-->
	