<div class="page-content" id="overlay">
		<div class="container-fluid" >
		<section class="card">
		
				<header class="card-header card-header-lg">
					Ticket Id: # <?php echo $singleticket->help_id;?>
				</header>
                <div class="form-group float-right col-md-6 col-sm-6">
                        <div class="col-md-3">
                            <label for="status">Status<span class="text-danger">*</span></label>
                        </div>
                        <div class="col-md-6">
                            <select required name="status" class="form-control col-md-8" id="status">
                                 <option value="">Select</option>
                                 <option value="open" <?php if($singleticket->help_status == 'open'){ echo 'selected="selected"';}?>>open</option>
                                 <option value="client" <?php if($singleticket->help_status == 'client'){ echo 'selected="selected"';}?>>client</option>
                                 <option value="reply" <?php if($singleticket->help_status == 'reply'){ echo 'selected="selected"';}?>>reply</option>
                                 <option value="awaiting" <?php if($singleticket->help_status == 'awaiting'){ echo 'selected="selected"';}?>>awaiting</option>
                                 <option value="response" <?php if($singleticket->help_status == 'response'){ echo 'selected="selected"';}?>>response</option>
                                 <option value="canceled" <?php if($singleticket->help_status == 'canceled'){ echo 'selected="selected"';}?>>canceled</option>
                                 <option value="closed" <?php if($singleticket->help_status == 'closed'){ echo 'selected="selected"';}?>>closed</option>
                            </select>
                            </div> 
                            <div class="col-md-3">
                                    <div class="form-group text-right m-b-0">
                                        <button class="btn btn-primary waves-effect waves-light" type="submit">
                                           <i class="fa fa-save"></i> Save
                                        </button>
                                    </div>
                                     <?php echo form_close(); ?>
                            </div> 
                        </div>
				<div class="card-block">
					<table class="table">
							<tr>
								<th>Subject</th>
								<td><?php echo $singleticket->help_subject;?></td>
								<th>Department</th>
								<td><?php echo $singleticket->help_department;?></td>
							</tr>
							<tr>
								<th>Priority</th>
								<td><?php echo $singleticket->help_priority; ?></td>
								<th>Status</th>
								<td><?php echo $singleticket->help_status; ?></td>
							</tr>
							<tr>
								<th>Description</th>
								<td colspan="3"><?php echo $singleticket->help_description; ?></td>
							</tr>
						</table>
						<br>
						<?php $attributes = array("name" => "changestatus", "data-parsley-validate novalidate");
                            echo form_open_multipart("help/changeStatus", $attributes);?>
                                    <div class="row">

                                        <div class="form-group col-md-6 col-sm-12">
                                        <label></label>
                                        <input type="hidden" name="helpid" required class="form-control number" value="<?php echo $singleticket->help_id; ?>" id="helpid">
                                           
                                        </div>
                                    </div>
                                    
						<?php 
							//$replies = $allticket->$replies;
							foreach ($replies as $rp) { ?>							
								 <div class="col-sm-12">
						            <div id="tb-testimonial" class="testimonial testimonial-primary">
						                <div class="testimonial-section">
						                    <?php echo $rp->description;?>
						                </div>
						                <div class="testimonial-desc">
						                    <img src="https://placeholdit.imgix.net/~text?txtsize=9&txt=100%C3%97100&w=100&h=100" alt="" />
						                    <div class="testimonial-writer">
						                    	<div class="testimonial-writer-name"><?php echo $rp->name.' '.$rp->lname; ?></div>
						                    	<div class="testimonial-writer-designation"><?php echo  date('M d,Y H:i a', strtotime($rp->timestamp)); ?></div>
						                    </div>
						                </div>
						            </div>   
								</div>
							<?php
							}
							?>

							<?php $attributes = array("name" => "ticketreply", "data-parsley-validate novalidate");
                        echo form_open_multipart("help/ticketreply", $attributes);?>
                                    <div class="row">

                                        <div class="form-group col-md-6 col-sm-12">
                                        <label></label>
                                        <input type="hidden" name="ticketid" required class="form-control number" value="<?php echo $singleticket->help_id; ?>" id="ticketid">
                                           
                                        </div>
                                         
                                        
                                    </div>
                                    
                                    <div class="row">

                                       <div class="form-group col-md-12 col-sm-12">
                                            <label for="description">Reply<span class="text-danger">*</span></label>
                                            <textarea class="form-control" required name="description" parsley-trigger="change" id="description"></textarea>
                                       </div>
                                      
                                    </div>
                                    
                                    <div class="form-group text-right m-b-0">
                                        <button class="btn btn-primary waves-effect waves-light" type="submit">
                                           <i class="fa fa-save"></i> Save
                                        </button>
                                        <button type="reset" class="btn btn-secondary waves-effect m-l-5">
                                            Cancel
                                        </button>
                                    </div>

                               <?php echo form_close(); ?>
					</div>			
				</div>
			</section>


		</div><!--.container-fluid-->
	</div>
