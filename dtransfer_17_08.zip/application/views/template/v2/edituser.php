<div class="page-content" id="composeresponse">
		<div class="container-fluid">
			<section class="card">
				<header class="card-header card-header-lg">
					Edit User 
				</header>
				<div class="card-block">
					<?php if(isset($message)) { echo $message; } ?>
					<form action="<?php echo base_url();?>user/edituser/<?php echo $user->user_id;?>" method="post" class="validatetrue">
						<div class="form-group row">
								<label class="col-sm-2 form-control-label">First Name</label>
								<div class="col-sm-10">
									<p class="form-control-static">
										<input type="text" required="" value="<?php echo $user->name;?>" placeholder="First Name" name="name" class="form-control" aria-required="true" aria-invalid="true">
									</p>
									<?php echo form_error('name');?>
								</div>
						</div>
						<div class="form-group row">
								<label class="col-sm-2 form-control-label">Last Name</label>
								<div class="col-sm-10">
									<p class="form-control-static">
										<input type="text" required="" value="<?php echo $user->lname;?>" placeholder="Last Name" name="lname" class="form-control" aria-required="true">
									</p>
									<?php echo form_error('lname');?>
								</div>
						</div>
						<div class="form-group row">
								<label class="col-sm-2 form-control-label">Phone</label>
								<div class="col-sm-10">
									<p class="form-control-static">
										<input type="text" required="" value="<?php echo $user->phone;?>" placeholder="Phone" name="phone" class="form-control" aria-required="true">
									</p>
									<?php echo form_error('phone');?>
								</div>
						</div>
						<div class="form-group row">
								<label class="col-sm-2 form-control-label">Email</label>
								<div class="col-sm-10">
									<p class="form-control-static">
										<input type="email" required="" value="<?php echo $user->email;?>" placeholder="Email" name="email" class="form-control" aria-required="true">
										<?php echo form_error('email');?>
									</p>
								</div>
						</div>
						<div class="form-group row">
								<label class="col-sm-2 form-control-label">New Password</label>
								<div class="col-sm-10">
									<p class="form-control-static">
										<input type="password" placeholder="Password" id="newpass" name="newpassword" class="form-control" >
									</p>
									<?php echo form_error('newpassword');?>
								</div>
						</div>
						<div class="form-group row">
								<label class="col-sm-2 form-control-label">Confirm Password</label>
								<div class="col-sm-10">
									<p class="form-control-static">
										<input type="password"  placeholder="Confirm Password" id="confpass" name="confirmpassword" class="form-control">
									</p>
									<?php echo form_error('confirmpassword');?>
								</div>
						</div>
						<div class="form-group row">
								<label class="col-sm-2 form-control-label">User Group</label>
								<div class="col-sm-10">
									<p class="form-control-static">
										 <select id="form_control_1" name="group_id" class="form-control" required="">
			                             <option value="">Select User Group</option>
										 <?php
										 foreach ($groups as $key => $value) { ?>
										 	<option <?php if($user->group_id == $value->group_id){echo 'selected="selected"';} ?>value="<?php echo $value->group_id; ?> "><?php echo $value->name; ?>(No. of users:<?php echo $value->totalusers; ?>)</option>;
										<?php  }
										 ?>
			                            </select>  
									</p>
									<?php echo form_error('group_id');?>
								</div>
						</div>
						<div class="form-group row">
								<label class="col-sm-2 form-control-label">User Type</label>
								<div class="col-sm-10">
									<p class="form-control-static">
										 <select id="form_control_1" name="usertype" class="form-control">
			                                <option value="">Select user type</option>
			                                <option <?php if($user->type == 2){echo 'selected="selected"';} ?> value="2">Internal User</option>
			                                <option <?php if($user->type == 3){echo 'selected="selected"';} ?> value="3">Admin</option>
			                            </select>  
									</p>
									<?php echo form_error('usertype');?>
								</div>
						</div>

				</div>
			</section>

				<p class="text-center margintop40">
				<button type="submit" class="btn btn-rounded btn-inline btn-primary-outline"><i class="fa fa-save"></i> Save</buttonkeyup
				</p>

				</form>
		</div><!--.container-fluid-->
</div><!--.page-content-->
<script type="text/javascript">
	/*$(document).ready(function(){
		$('#newpassword').on('keyup',function(){
			alert($this.val());

		});
	})*/
</script>