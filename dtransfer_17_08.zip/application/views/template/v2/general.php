<div class="page-content" id="composeresponse">
    <div class="container-fluid">
      <section class="card">
        <header class="card-header card-header-lg">
         General Settings
        <small>Configure General settings here</small>
        </header>
        <div class="card-block">
        <?php echo $this->session->flashdata("generalupdate");?>
          <div class="row ">
            <form action="<?php echo base_url();?>settings/updategeneral" method="POST">
                            <div class="form-group form-md-line-input form-md-floating-label">
                                <label for="form_control_1">No.Of days</label>
                                <input type="text" name="days" value="<?php echo $value->no_days;?>" required id="host" autocomplete="off" class="form-control">
                                
                            </div>

                            <div class="form-group form-md-line-input form-md-floating-label">
                                <label for="form_control_1">Domain</label>
                                <input type="text" name="domain" value="<?php echo $value->domain;?>" required id="port" autocomplete="off" class="form-control">
                               
                            </div>

                            <div class="form-group form-md-line-input form-md-floating-label">
                                <label for="form_control_1">Allowed file type</label>
                                <input type="text" name="filetype" value="<?php echo $value->file_type;?>" required id="ldapuser" autocomplete="off" class="form-control">
                                
                            </div>
                             <div class="form-actions noborder">
                            <input type="submit" value="Update" class="btn blue"  >  </input>
                            
                        </div>
                    </form>
          </div>          
        </div>
      </section>
    </div><!--.container-fluid-->
</div><!--.page-content-->
  