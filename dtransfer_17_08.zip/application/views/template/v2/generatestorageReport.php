<div class="page-content" id="composeresponse">
		<div class="container-fluid">
			<section class="card">
				<header class="card-header card-header-lg">
					Storage Report Page 
				</header>
				<div class="card-block">
					<div class="row ">

						<table class="table table-bordered table-hover datatable">
						<thead>
							<th>S No.</th>
							<th>Total Storage</th>
							<th>User Name</th>
							<th>User email</th>
						</thead>
							<?php
							$i=1;
							
							foreach ($details as $value) {
							?>
							<tr>
								<td><?php echo $i++;?></td>
								<td><?php echo formatBytes($value->totalsize);?></td>
								<td><?php echo $value->username;?></td>
								<td>
								<?php 
									echo $value->useremail;
								?>
								</td>
							</tr>
							<?php
							}
							?>							
					</table>
					</div>					
				</div>
			</section>
		</div><!--.container-fluid-->
</div><!--.page-content-->
	