<div class="page-content" id="overlay">
		<div class="container-fluid" >
		<section class="card">
		<?php //echo'<pre>'; 
						$replies = array();
						
						$replies = $allticket->replies;
						//print_r($replies); 
						//die;?>
				<header class="card-header card-header-lg">
					Ticket Id: # <?php echo $allticket->ticket->TK_id;?>
				</header>
				<div class="card-block">
					<table class="table">
							<tr>
								<th>Subject</th>
								<td><?php echo $allticket->ticket->TK_subject;?></td>
								<th>Department</th>
								<td><?php echo $allticket->ticket->TK_department;?></td>
							</tr>
							<tr>
								<th>Priority</th>
								<td><?php echo $allticket->ticket->TK_priority; ?></td>
								<th>Status</th>
								<td><?php echo $allticket->ticket->TK_status; ?></td>
							</tr>
							<tr>
								<th>Description</th>
								<td colspan="3"><?php echo $allticket->ticket->TK_description; ?></td>
							</tr>
						</table>
						<br>
						<br>
						<?php 
							//$replies = $allticket->$replies;
							foreach ($replies as $rp) { ?>							
								 <div class="col-sm-12">
						            <div id="tb-testimonial" class="testimonial testimonial-primary">
						                <div class="testimonial-section">
						                    <?php echo $rp->RP_Description;?>
						                </div>
						                <div class="testimonial-desc">
						                    <img src="https://placeholdit.imgix.net/~text?txtsize=9&txt=100%C3%97100&w=100&h=100" alt="" />
						                    <div class="testimonial-writer">
						                    	<div class="testimonial-writer-name"><?php echo $rp->RP_username; ?></div>
						                    	<div class="testimonial-writer-designation"><?php echo  date('M d,Y H:i a', strtotime($rp->RP_timestamp)); ?></div>
						                    </div>
						                </div>
						            </div>   
								</div>
							<?php
							}
							?>

							<?php $attributes = array("name" => "ticketreply", "data-parsley-validate novalidate");
                        echo form_open_multipart("Support/ticketreply", $attributes);?>
                                    <div class="row">

                                        <div class="form-group col-md-6 col-sm-12">
                                        <label></label>
                                        <input type="hidden" name="ticketid" required class="form-control number" value="<?php echo $allticket->ticket->TK_id; ?>" id="ticketid">
                                           
                                        </div>
                                         
                                        
                                    </div>
                                    
                                    <div class="row">

                                       <div class="form-group col-md-12 col-sm-12">
                                            <label for="description">Reply<span class="text-danger">*</span></label>
                                            <textarea class="form-control" required name="description" parsley-trigger="change" id="description"></textarea>
                                       </div>
                                      
                                    </div>
                                    
                                    <div class="form-group text-right m-b-0">
                                        <button class="btn btn-primary waves-effect waves-light" type="submit">
                                           <i class="fa fa-save"></i> Save
                                        </button>
                                        <button type="reset" class="btn btn-secondary waves-effect m-l-5">
                                            Cancel
                                        </button>
                                    </div>

                               <?php echo form_close(); ?>
					</div>			
				</div>
			</section>


		</div><!--.container-fluid-->
	</div>
