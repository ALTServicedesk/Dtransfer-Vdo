<div class="page-content" id="composeresponse">
		<div class="container-fluid">
			<section class="card">
				<header class="card-header card-header-lg">
					Blank Page 
				</header>
				<div class="card-block">
					<div class="row ">
						
					</div>					
				</div>
			</section>
		</div><!--.container-fluid-->
</div><!--.page-content-->
	