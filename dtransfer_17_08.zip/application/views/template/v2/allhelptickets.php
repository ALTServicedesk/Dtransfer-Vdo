<div class="page-content" id="overlay">
		<div class="container-fluid" >
		<section class="card">
				<header class="card-header card-header-lg">
					All Tickets
				</header>
				<div class="card-block">
					<div class="row ">
						<table id="table-edit" class="table table-bordered table-hover datatable">
							<thead>
							<tr>
								<th>
									#
								</th>
								<th>Department</th>
								<th>Subject</th>
								<th>Priority</th>
								<th>Status</th>
								<?php if($current_user->type == 3){ ?>
								<th>User name</th>
								<th>User Email</th>
								<?php } ?>

								<th>Actions</th>
								</tr>
							</thead>
							<tbody>
								<?php //echo'<pre>';print_r($allticket); 
										$cc = 0;
									foreach ($alltickets->result() as $at) {
										if($current_user->type == 3){ ?>
											<tr id="<?php echo $cc++; ?>">
												<td><span class="tabledit-span tabledit-identifier"><?php echo $cc; ?></a></span></td>
												<td class="tabledit-view-mode"><span class="tabledit-span"><?php echo $at->help_department; ?></span></td>
												<td class="tabledit-span"><?php echo $at->help_subject; ?></td>
												<td class="tabledit-span"><?php echo $at->help_priority; ?></td>
												<td class="tabledit-span"><?php echo $at->help_status; ?></td>
												<td class="tabledit-span"><?php echo $at->name.' '.$at->lname; ?></td>
												<td class="tabledit-span"><?php echo $at->email; ?></td>
												<td><a class="btn btn-success" href="<?php echo base_url();?>help/singleticket/<?php echo $at->help_id; ?>">View</a></td>
						                    </tr>

										<?php }else{
												if($at->help_userid == $current_user->user_id){ ?>
													<tr id="<?php echo $cc++; ?>">
														<td><span class="tabledit-span tabledit-identifier"><?php echo $cc; ?></a></span></td>
														<td class="tabledit-view-mode"><span class="tabledit-span"><?php echo $at->help_department; ?></span></td>
														<td class="tabledit-span"><?php echo $at->help_subject; ?></td>
														<td class="tabledit-span"><?php echo $at->help_priority; ?></td>
														<td class="tabledit-span"><?php echo $at->help_status; ?></td>
														<td><a class="btn btn-success" href="<?php echo base_url();?>help/singleticket/<?php echo $at->help_id; ?>">View</a></td>
								                    </tr>
											<?php	}

										}
								?>
								
			                    <?php 
			                    }
								?>
								
							</tbody>
						</table>

					</div>					
				</div>
			</section>


		</div><!--.container-fluid-->
	</div>