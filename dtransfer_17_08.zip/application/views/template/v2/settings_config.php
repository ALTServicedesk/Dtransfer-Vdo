<div class="page-content" id="overlay">
		<div class="container-fluid" >
			<header class="card-header card-header-lg">
					System Configuration
				</header>
			</pre>
			<form id="config_form">
			<section class="tabs-section">
				<div class="tabs-section-nav tabs-section-nav-icons">
					<div class="tbl">
						<ul role="tablist" class="nav">
							<li class="nav-item">
								<a data-toggle="tab" role="tab" href="#tabs-1-tab-1" class="nav-link active">
									<span class="nav-link-in">
										<i class="font-icon font-icon-cogwheel"></i>
										General
									</span>
								</a>
							</li>

							<li class="nav-item">
								<a data-toggle="tab" role="tab" href="#tabs-1-tab-2" class="nav-link">
									<span class="nav-link-in">
										<i class="font-icon font-icon-cogwheel"></i>
										User
									</span>
								</a>
							</li>

							<li class="nav-item">
								<a data-toggle="tab" role="tab" href="#tabs-1-tab-3" class="nav-link">
									<span class="nav-link-in">
										<i class="font-icon font-icon-cogwheel"></i>
										Logo
									</span>
								</a>
							</li>
							
						</ul>
					</div>
				</div><!--.tabs-section-nav-->

				<div class="tab-content">
					<div id="tabs-1-tab-1" class="tab-pane fade in active" role="tabpanel">

						<?php
						foreach ($config['general'] as $key => $value) {
							?>
							<div class="form-group row">
								<label class="col-sm-4 form-control-label"><?php echo $value->name;?></label>
								<div class="col-sm-8">
									<p class="form-control-static">
										<input name="<?php echo $value->config_id;?>" type="text" class="form-control" value="<?php echo $value->token;?>">
										<small class="text-muted"><?php echo $value->description;?></small>
									</p>
								</div>
							</div>
							<?php
						}
						?>

					</div><!--.tab-pane-->

					<div id="tabs-1-tab-2" class="tab-pane fade in" role="tabpanel">

						<?php
						foreach ($config['user'] as $key => $value) {
							?>
							<div class="form-group row">
								<label class="col-sm-4 form-control-label"><?php echo $value->name;?></label>
								<div class="col-sm-8">
									<p class="form-control-static">
										<?php
										produce_input($value->type,$value->config_id,$value->token,$value->data); 
										?>
										<small class="text-muted"><?php echo $value->description;?></small>
									</p>
								</div>
							</div>
							<?php
						}
						?>

					</div><!--.tab-pane-->

					<div id="tabs-1-tab-3" class="tab-pane fade in" role="tabpanel">

						
							<div class="form-group row">
								<label class="col-sm-4 form-control-label">Logo</label>
								<div class="col-sm-4">
									<p class="form-control-static">
										<input name="logo" type="file" id="imageuploadpreview">
										<small class="text-muted">Upload logo of size 270x100</small>
									</p>
								</div>
								<div class="col-sm-2" >
										<img src="<?php echo asset_url();?>img/logopreview.png" id="previewHolder" width="270" height="100">
								</div>
							</div>
							

					</div><!--.tab-pane-->
					
				</div><!--.tab-content-->
				<p class="text-center margintop40">
				<button class="btn btn-rounded btn-inline btn-primary-outline save_config" type="button"><i class="fa fa-save"></i> Save</button>
				</p>	
				<div role="alert" class="alert alert-info alert-no-border alert-close alert-dismissible fade in">
						<button aria-label="Close" data-dismiss="alert" class="close" type="button">
							<span aria-hidden="true">×</span>
						</button>
						<?php echo $this->lang->line('information_settings_config');?>
				</div>

			</form>
			</section>
		</div><!--.container-fluid-->
	</div>