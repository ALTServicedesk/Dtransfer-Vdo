<div class="page-content" id="composeresponse">
		<div class="container-fluid">
			<section class="card">
				<header class="card-header card-header-lg">
					Add User 
				</header>
				<div class="card-block">
					<?php if(isset($message)) { echo $message; } ?>
					<form action="<?php echo base_url();?>user/adduser" method="post" class="validatetrue">
						<div class="form-group row">
								<label class="col-sm-2 form-control-label">First Name</label>
								<div class="col-sm-10">
									<p class="form-control-static">
										<input type="text" required="" placeholder="First Name" name="name" class="form-control" aria-required="true" aria-invalid="true">
									</p>
									<?php echo form_error('name');?>
								</div>
						</div>
						<div class="form-group row">
								<label class="col-sm-2 form-control-label">Last Name</label>
								<div class="col-sm-10">
									<p class="form-control-static">
										<input type="text" required="" placeholder="Last Name" name="lname" class="form-control" aria-required="true">
									</p>
									<?php echo form_error('lname');?>
								</div>
						</div>
						<div class="form-group row">
								<label class="col-sm-2 form-control-label">Phone</label>
								<div class="col-sm-10">
									<p class="form-control-static">
										<input type="text" required="" placeholder="Phone" name="phone" class="form-control" aria-required="true">
									</p>
									<?php echo form_error('phone');?>
								</div>
						</div>
						<div class="form-group row">
								<label class="col-sm-2 form-control-label">Email</label>
								<div class="col-sm-10">
									<p class="form-control-static">
										<input type="email" required="" placeholder="Email" name="email" class="form-control" aria-required="true">
										<?php echo form_error('email');?>
									</p>
								</div>
						</div>
						<div class="form-group row">
								<label class="col-sm-2 form-control-label">Password</label>
								<div class="col-sm-10">
									<p class="form-control-static">
										<input type="password" required="" placeholder="Password" name="password" class="form-control" aria-required="true">
									</p>
									<?php echo form_error('password');?>
								</div>
						</div>
						<div class="form-group row">
								<label class="col-sm-2 form-control-label">Confirm Password</label>
								<div class="col-sm-10">
									<p class="form-control-static">
										<input type="password" required="" placeholder="Confirm Password" name="confirmpassword" class="form-control" aria-required="true">
									</p>
									<?php echo form_error('confirmpassword');?>
								</div>
						</div>
						<div class="form-group row">
								<label class="col-sm-2 form-control-label">User Group</label>
								<div class="col-sm-10">
									<p class="form-control-static">
										 <select id="form_control_1" name="group_id" class="form-control" required="">
			                             <option value="">Select User Group</option>
										 <?php
										 foreach ($groups as $key => $value) {
										 	echo '<option value="'.$value->group_id.'">'.$value->name.' (No. of users: '.$value->totalusers.')</option>';
										 }
										 ?>
			                            </select>  
									</p>
									<?php echo form_error('group_id');?>
								</div>
						</div>
						<div class="form-group row">
								<label class="col-sm-2 form-control-label">User Type</label>
								<div class="col-sm-10">
									<p class="form-control-static">
										 <select id="form_control_1" name="usertype" class="form-control">
			                                <option value="">Select user type</option>
			                                <option value="2">Internal User</option>
			                                <option value="3">Admin</option>
			                            </select>  
									</p>
									<?php echo form_error('usertype');?>
								</div>
						</div>

				</div>
			</section>

				<p class="text-center margintop40">
				<button type="submit" class="btn btn-rounded btn-inline btn-primary-outline"><i class="fa fa-save"></i> Save</button>
				</p>

				</form>
		</div><!--.container-fluid-->
</div><!--.page-content-->
	