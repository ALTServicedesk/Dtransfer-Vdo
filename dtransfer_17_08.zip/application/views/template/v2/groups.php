<div class="page-content" id="composeresponse">
		<div class="container-fluid">
			<section class="card">
				<header class="card-header card-header-lg">
					All Groups
					<div class="pull-right"><a href="<?php echo base_url();?>user/addgroup" class="btn btn-sm">Add New</a></div>
				</header>
				<div class="card-block">
				<?php echo $this->session->flashdata("defaultgroupmsg");?>

					<div class="row ">

					<table class="table table-bordered table-hover">
						<thead>
							<th>S No.</th>
							<th>Name</th>
							<th>No of users</th>
							<th>Actions</th>
						</thead>
							<?php
							$i=1;
							foreach ($groups as $key => $value) {
							?>
							<tr>
								<td><?php echo $i++;?></td>
								<td><?php echo $value->name;?> <span style="color:#FEBF00"><?php 
								if($value->default==1){ ?><i class="fa fa-star" aria-hidden="true"></i> <?php } ?></span></td>
								<td><?php echo $value->totalusers;?> </td>
								<td>
								<?php 
								if($value->default==0){ ?><a href="<?php echo base_url();?>user/defaultgroup/<?php echo $value->group_id; ?>" class="btn btn-sm btn-success"><i class="fa fa-star" aria-hidden="true"></i></a> <?php } ?>
								<a href="<?php echo base_url();?>user/viewgroup/<?php echo $value->group_id; ?>" class="btn btn-sm btn-warning"><i class="fa fa-eye"></i></a>
								<a href="<?php echo base_url();?>user/editgroup/<?php echo $value->group_id; ?>" class="btn btn-sm btn-info"><i class="fa fa-pencil"></i></a>
								<a href="<?php echo base_url();?>user/deletegroup/<?php echo $value->group_id;?>" class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></a>
								</td>
							</tr>
							<?php
							}
							?>							
					</table>
					</div>					
				</div>
			</section>
		</div><!--.container-fluid-->
</div><!--.page-content-->
	