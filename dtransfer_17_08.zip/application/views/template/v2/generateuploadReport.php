<div class="page-content" id="composeresponse">
		<div class="container-fluid">
			<section class="card">
				<header class="card-header card-header-lg">
					Uploads Report Page 
				</header>
				<div class="card-block">
					<div class="row ">
					

						<table class="table table-bordered table-hover datatable">
						<thead>
							<th>S No.</th>
							<th>From</th>
							<th>To</th>
							<th>Size</th>
							<th>Expiry</th>
							<th>OTP</th>
							<!-- <th>Type</th> -->
						</thead>
							<?php
							$i=1;
							
							foreach ($details as $value) {
							?>
							<tr>
								<td><?php echo $i++;?></td>
								<td><?php echo $value->username.",<br>".$value->useremail;?></td>
								<td><?php echo $value->recivername.",<br>".$value->reciveremail;?></td>
								<td>
								<?php 
									/*$files = explode(',', $value->filename);
									$size = explode(',', $value->filesize);
									//print_r($files);
									foreach($files as $k => $v) {
										echo $v."(".$size[$k].")<br>";
									}*/
									echo formatBytes($value->totalfilesize);
								?>
								</td>
								<td><?php echo generatedatetime($value->expiry);?></td>
								<td><?php echo $value->otp;?></td>
								<!-- <td><?php echo $value->type;?></td> -->
							</tr>
							<?php
							}
							?>							
					</table>
					</div>					
				</div>
			</section>
		</div><!--.container-fluid-->
</div><!--.page-content-->
	