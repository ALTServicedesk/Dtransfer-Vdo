<div class="page-content" id="composeresponse">
		<div class="container-fluid">
			<section class="card">
				<header class="card-header card-header-lg">
					Updates
				</header>
				<div class="card-block">
					<div class="row">
						<div class="col-md-12">
							Curent version: <?php echo $licence->curver;?>
							<?php echo $server_output;?>
						</div>
					</div>					
				</div>
			</section>
		</div><!--.container-fluid-->
</div><!--.page-content-->
	