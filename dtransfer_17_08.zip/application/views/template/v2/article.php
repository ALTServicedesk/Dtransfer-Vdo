	<div class="page-content" id="overlay">
		<div class="container-fluid" >
		<section class="card">
				<header class="card-header card-header-lg">
					Article: <?php echo $allticket[0]->Article_Title;?>					
				</header>
				<div class="card-block">
				<?php $count = 0; ?> 
					<div class="row">
						<div class="col-md-12">
							<strong class="pull-left">Dated: </strong> <?php echo $allticket[0]->Article_Date;?>
							<strong >Category: </strong> <?php echo $allticket[0]->ArticleCat_Name;?>
							<p>
							<br>								
								<?php echo $allticket[0]->Article_Description;?>
							</p>

						</div>
					</div>					
				</div>
			</section>

			<p class="text-center">
							<a href="<?php echo base_url();?>support/catarticle/<?php echo $allticket[0]->Article_Category;?>" class="btn btn-rounded btn-inline btn-primary-outline" type="submit"><i class="fa fa-angle-left"></i> Back</a>
							</p>

		</div><!--.container-fluid-->
	</div>
