 <footer>
<div class="row">
	<div class="col-md-4 copyright"><?php echo $this->config->item('general_copyright'); ?></div>
  <div class="col-md-4 text-center madein">
   <!-- Made with <span id="heart" >
  <img class="bottom" src="https://i.stack.imgur.com/iBCpb.png" width="20px">
</span> in India -->
   
  </div>
	<div class="col-md-4 footermenu">
   <ul class="footer-links">
     <!-- <li><a id="pageview" data-slug="aboutus" data-title="Dtransfer" href="#">Dtransfer</a></li> -->
     <li><a id="pageview" data-slug="terms" data-title="Terms Of Use" href="#">Terms Of Use</a></li>
     <li><a id="pageview" data-slug="policies" data-title="Privacy Policy" href="#">Privacy Policy</a></li>
   </ul> 
  </div>
</div>
</footer>


<div class="transparacy" style="display:none">
      <div class="loader" title="0">
      <svg version="1.1" id="loader-1" xmlns="https://www.w3.org/2000/svg" xmlns:xlink="https://www.w3.org/1999/xlink" x="0px" y="0px"
       width="100px" height="100px" viewBox="0 0 40 40" enable-background="new 0 0 40 40" xml:space="preserve">
      <path opacity="0.2" fill="#000" d="M20.201,5.169c-8.254,0-14.946,6.692-14.946,14.946c0,8.255,6.692,14.946,14.946,14.946
        s14.946-6.691,14.946-14.946C35.146,11.861,28.455,5.169,20.201,5.169z M20.201,31.749c-6.425,0-11.634-5.208-11.634-11.634
        c0-6.425,5.209-11.634,11.634-11.634c6.425,0,11.633,5.209,11.633,11.634C31.834,26.541,26.626,31.749,20.201,31.749z"/>
      <path fill="#000" d="M26.013,10.047l1.654-2.866c-2.198-1.272-4.743-2.012-7.466-2.012h0v3.312h0
        C22.32,8.481,24.301,9.057,26.013,10.047z">
        <animateTransform attributeType="xml"
          attributeName="transform"
          type="rotate"
          from="0 20 20"
          to="360 20 20"
          dur="0.5s"
          repeatCount="indefinite"/>
        </path>
      </svg>
    </div>
  </div>

<div class="modal fade"
           id="ajaxModal"
           tabindex="-1"
           role="dialog"
           aria-labelledby="myModalLabel"
           aria-hidden="true">
          <div class="modal-dialog" role="document">
            <div class="modal-content ">
              <div class="modal-header">
                <button type="button" class="modal-close" data-dismiss="modal" aria-label="Close">
                  <i class="font-icon-close-2"></i>
                </button>
                <h4 class="modal-title" id="ajaxModalLabel"></h4>
              </div>
              <div class="modal-body modal-content-limit" id="ajaxModalbody">
                ...
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-rounded btn-default" data-dismiss="modal">Close</button
              </div>
            </div>
          </div>
        </div><!--.modal-->

<script type="text/javascript"> 
var base_url="<?php echo base_url();?>"; 
var asset_url="<?php echo asset_url();?>"; 
var loader="<?php echo asset_url();?>img/loader.gif"; 
</script>
<script src="<?php echo asset_url();?>js/lib/jquery/jquery.min.js"></script>
<script src="<?php echo asset_url();?>js/lib/jquery/jquery-ui.min.js"></script>
<script src="<?php echo asset_url();?>js/lib/tether/tether.min.js"></script>
<script src="<?php echo asset_url();?>js/lib/bootstrap/bootstrap.min.js"></script>
<script src="<?php echo asset_url();?>js/lib/notie/notie.js"></script>
<script src="<?php echo asset_url();?>js/lib/notie/notie-init.js"></script>
<script src="<?php echo asset_url();?>js/plugins.js"></script>
<script src="<?php echo asset_url();?>js/bootstrap-switch.min.js"></script>
<script src="<?php echo asset_url();?>js/lib/summernote/summernote.min.js"></script>
<script src="<?php echo asset_url();?>js/lib/jquery-tag-editor/jquery.tag-editor.min.js"></script>
<script src="<?php echo asset_url();?>js/app.js"></script>
<script src="<?php echo asset_url();?>js/lib/peity/jquery.peity.min.js"></script>
<script src="<?php echo asset_url();?>js/lib/peity/peity-init.js"></script>
<script src="<?php echo asset_url();?>js/flexcroll.js"></script>
<script src="<?php echo asset_url();?>js/lib/flot/jquery.flot.js"></script>
<script src="<?php echo asset_url();?>js/lib/flot/jquery.flot.time.js"></script>
<script src="<?php echo asset_url();?>js/moment.js"></script>
<script src="<?php echo asset_url();?>js/jquery.mousewheel.js"></script>
<script src="<?php echo asset_url();?>js/jquery.jscrollpane.min.js"></script>
<script src="<?php echo asset_url();?>js/lib/daterangepicker/daterangepicker.js"></script>
<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>
<script src="//cdn.tinymce.com/4/tinymce.min.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.15.0/jquery.validate.min.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.15.0/additional-methods.min.js"></script>
<script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.2.2/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.2.2/js/buttons.bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/2.5.0/jszip.min.js"></script>
<script src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/pdfmake.min.js"></script>
<script src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/1.2.2/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.2.2/js/buttons.print.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.2.2/js/buttons.colVis.min.js"></script>
<script src="<?php echo asset_url();?>js/lib/select2/select2.full.min.js"></script>

<script src="<?php echo asset_url();?>js/lib/d3/d3.min.js"></script>
<script src="<?php echo asset_url();?>js/lib/charts-c3js/c3.min.js"></script>

<script src="<?php echo asset_url();?>js/bootstrap-tagsinput.js"></script>
<script src="<?php echo asset_url();?>js/sweetalert.min.js"></script>

<script src="<?php echo asset_url();?>js/custom.js"></script>


<script src="<?php echo base_url();?>fileuploader/js/vendor/jquery.ui.widget.js"></script>
<!-- The Templates plugin is included to render the upload/download listings -->
<script src="https://blueimp.github.io/JavaScript-Templates/js/tmpl.min.js"></script>
<!-- The Load Image plugin is included for the preview images and image resizing functionality -->
<script src="https://blueimp.github.io/JavaScript-Load-Image/js/load-image.all.min.js"></script>
<!-- The Canvas to Blob plugin is included for image resizing functionality -->
<script src="https://blueimp.github.io/JavaScript-Canvas-to-Blob/js/canvas-to-blob.min.js"></script>
<!-- Bootstrap JS is not required, but included for the responsive demo navigation -->
<script src="https://netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
<!-- blueimp Gallery script -->
<script src="https://blueimp.github.io/Gallery/js/jquery.blueimp-gallery.min.js"></script>
<!-- The Iframe Transport is required for browsers without support for XHR file uploads -->
<script src="<?php echo base_url();?>fileuploader/js/jquery.iframe-transport.js"></script>
<!-- The basic File Upload plugin -->
<script src="<?php echo base_url();?>fileuploader/js/jquery.fileupload.js"></script>
<!-- The File Upload processing plugin -->
<script src="<?php echo base_url();?>fileuploader/js/jquery.fileupload-process.js"></script>
<!-- The File Upload image preview & resize plugin -->
<script src="<?php echo base_url();?>fileuploader/js/jquery.fileupload-image.js"></script>
<!-- The File Upload audio preview plugin -->
<script src="<?php echo base_url();?>fileuploader/js/jquery.fileupload-audio.js"></script>
<!-- The File Upload video preview plugin -->
<script src="<?php echo base_url();?>fileuploader/js/jquery.fileupload-video.js"></script>
<!-- The File Upload validation plugin -->
<script src="<?php echo base_url();?>fileuploader/js/jquery.fileupload-validate.js"></script>
<!-- The File Upload user interface plugin -->
<script src="<?php echo base_url();?>fileuploader/js/jquery.fileupload-ui.js"></script>
<!-- The main application script -->
<script src="<?php echo base_url();?>fileuploader/js/main.js"></script>

 <!-- <script src="<?php echo asset_url();?>js/dashboard.js"></script> 
 -->
 <input type="text" name="name" class="file_type" value="<?php if(isset($conf)){echo $conf->file_type; }  ?>">
 <script type="text/javascript">
   var script   = document.createElement("script");
  script.type  = "text/javascript";
  script.src   = "<?php echo asset_url();?>js/dashboard.js";
  if ($("#dashboardadmin").length > 0){
  document.head.appendChild(script);
  }
 </script>                  
</body></html>