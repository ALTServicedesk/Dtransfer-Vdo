<body class="with-side-menu theme-picton-blue">

	<header class="site-header">
	    <div class="container-fluid">
	        <a href="http://www.altbalaji.com" target="_blank" class="site-logo">
	            <img class="hidden-md-down" src="<?php echo asset_url();?>img/logo-2.png" alt="">
	        </a>
	        <button class="hamburger hamburger--htla">
	            <span>toggle menu</span>
	        </button>
	        <div class="site-header-content">
	            <div class="site-header-content-in">
						<p id="datetime"></p>
	                <div class="site-header-shown">
	                    <div class="dropdown user-menu">
	                        <button class="dropdown-toggle" id="dd-user-menu" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
	                        <?php
                                        if($logged_in_user->image=="")
                                        {
                                        	$src='http://www.placehold.it/200x150/EFEFEF/AAAAAA&amp;text=no+image';
                                        }
                                        else{
                                        	$src=base_url()."uploads/".$logged_in_user->image;
                                        }
                                        ?>

	                            <?php echo $logged_in_user->name;?> <img src="<?php echo $src;?>" alt="">
	                        </button>
	                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dd-user-menu">
	                            <a class="dropdown-item" href="<?php echo base_url();?>user/profile"><span class="font-icon glyphicon glyphicon-user"></span>Profile</a>
	                            <a class="dropdown-item" href="<?php echo base_url();?>user/changepassword"><span class="font-icon fa fa-lock"></span> Change Password</a>
	                            <div class="dropdown-divider"></div>
	                            <a class="dropdown-item" href="<?php echo base_url();?>user/logout"><span class="font-icon glyphicon glyphicon-log-out"></span>Logout</a>
	                        </div>
	                    </div>
	
	                    <button type="button" class="burger-right">
	                        <i class="font-icon-menu-addl"></i>
	                    </button>
	                </div><!--.site-header-shown-->
	
	                <div class="mobile-menu-right-overlay"></div>
	                <div class="site-header-collapsed">
	                    
	                </div><!--.site-header-collapsed-->
	            </div><!--site-header-content-in-->
	        </div>
	    </div><!--.container-fluid-->
	</header><!--.site-header-->

	<div class="mobile-menu-left-overlay"></div>
	<nav class="side-menu">
	    <ul class="side-menu-list">
	        <li class="blue-dirty <?php if($this->router->fetch_class()=='user' && $this->router->fetch_method()=='dashboard') { echo 'active'; }?> ">
	            <a href="<?php echo base_url();?>user/dashboard">
	                <i class="font-icon font-icon-notebook"></i>
	                <span class="lbl">Dashboard</span>
	            </a>
	        </li>

	        <li class="blue-dirty <?php if($this->router->fetch_class()=='user' && $this->router->fetch_method()=='compose') { echo 'active'; }?>">
	            <a href="<?php echo base_url();?>user/compose">
	                <i class="font-icon glyphicon glyphicon-send"></i>
	                <span class="lbl">Compose</span>
	            </a>
	        </li>

	        <li class="blue-dirty <?php if($this->router->fetch_class()=='user' && $this->router->fetch_method()=='mail') { echo 'active'; }?>">
	            <a href="<?php echo base_url();?>user/mail">
	                <i class="fa fa-inbox"></i>
	                <span class="lbl">Inbox</span>
	            </a>
	        </li>

	        <li class="blue-dirty <?php if($this->router->fetch_class()=='user' && $this->router->fetch_method()=='sentmail') { echo 'active'; }?>">
	            <a href="<?php echo base_url();?>user/sentmail">
	                <i class="fa fa-envelope"></i>
	                <span class="lbl">Sent Mail</span>
	            </a>
	        </li>
	        
	        
	        <?php
	        if($logged_in_user->type==3){
	        ?>
	        <li class="orange-red with-sub <?php if($this->router->fetch_class()=='user' && $this->router->fetch_method()=='users' || $this->router->fetch_method()=='adduser' || $this->router->fetch_method()=='groups' || $this->router->fetch_method()=='addgroup' ){ echo "opened"; }?>">
	            <span>
	                <i class="fa fa-users"></i>
	                <span class="lbl">Users & Groups</span>
	            </span>
	            <ul>
	                <li><a href="<?php echo base_url();?>user/users"><span class="lbl">Users</span></a></li>
	                <li><a href="<?php echo base_url();?>user/adduser"><span class="lbl">Add Users</span></a></li>
	                <li><a href="<?php echo base_url();?>user/groups"><span class="lbl">Groups</span></a></li>
	                <li><a href="<?php echo base_url();?>user/addgroup"><span class="lbl">Add Group</span></a></li>	               
	            </ul>
	        </li>
	        <li class="orange-red with-sub <?php if($this->router->fetch_class()=='logs' || $this->router->fetch_class()=='reports'){ echo "opened"; }?>">
	            <span>
	                <i class="fa fa-area-chart"></i>
	                <span class="lbl">Reports</span>
	            </span>
	            <ul>
	               <!--  <li><a href="<?php echo base_url();?>reports/bandwidth"><span class="lbl">Bandwidth</span></a></li> -->
	                <li><a href="<?php echo base_url();?>reports/storage"><span class="lbl">Storage</span></a></li>
	                <li><a href="<?php echo base_url();?>reports/downloads"><span class="lbl">Downloads</span></a></li>
	                <li><a href="<?php echo base_url();?>reports/uploads"><span class="lbl">Uploads</span></a></li>	               
	                <!-- <li><a href="<?php echo base_url();?>reports/suspiciousactivity"><span class="lbl">Suspicious Activity</span></a></li>      
	                <li><a href="<?php echo base_url();?>reports/support"><span class="lbl">Support Reports</span></a></li>	   -->             
	                <li><a href="<?php echo base_url();?>logs/readlogs/user"><span class="lbl">Users Logs</span></a></li>	               
	                <li><a href="<?php echo base_url();?>logs/readlogs/smtp"><span class="lbl">SMTP Logs</span></a></li>	
	                <li><a href="<?php echo base_url();?>logs/readlogs/system"><span class="lbl">System Logs</span></a></li>
	                <li class="current"><a href="<?php echo base_url();?>upload/view_current_update"><span class="lbl">Current Upload</span></a></li>	   	

	            </ul>
	        </li>

	        <?php
	    	}
	    	?>
	        

	        <li class="orange-red with-sub"  <?php if($this->router->fetch_class()=='help'){ echo "opened"; }?>>
	        	<span>
	                <i class="fa fa-question"></i>
	                <span class="lbl">Help</span>
	            </span>
	            <ul>
	                <li><a href="<?php echo base_url();?>help/submitticket"><span class="lbl">Open a Ticket</span></a></li>
	                <li><a href="<?php echo base_url();?>help/alltickets"><span class="lbl">All Tickets</span></a></li>        
	            </ul>
	        	
	        </li>

	        <?php
	        if($logged_in_user->type==3){
	        ?>
	         <li class="orange-red with-sub  <?php if($this->router->fetch_class()=='support'){ echo "opened"; }?>">
	            <span>
	                <i class="fa fa-life-ring"></i>
	                <span class="lbl">Support</span>
	            </span>
	            <ul>
	                <li><a href="<?php echo base_url();?>support/submitticket"><span class="lbl">Open a Ticket</span></a></li>
	                <li><a href="<?php echo base_url();?>support/alltickets"><span class="lbl">All Tickets</span></a></li>
	                <li><a href="<?php echo base_url();?>support/faq"><span class="lbl">F.A.Q</span></a></li>	               
	                <li><a href="<?php echo base_url();?>support/knowledgebase"><span class="lbl">Knowledgebase</span></a></li>	               
	            </ul>
	        </li>

	         <li class="orange-red with-sub  <?php if($this->router->fetch_class()=='settings'){ echo "opened"; }?>">
	            <span>
	                <i class="fa fa-gear"></i>
	                <span class="lbl">System</span>
	            </span>
	            <ul>
	                <li><a href="<?php echo base_url();?>settings/siteconfig"><span class="lbl">Configuration</span></a></li>
	                <li><a href="<?php echo base_url();?>settings/smtpsettings"><span class="lbl">SMTP Settings</span></a></li>
	                <li><a href="<?php echo base_url();?>settings/messages"><span class="lbl">System Messages</span></a></li>
	                 <li><a href="<?php echo base_url();?>settings/ldap"><span class="lbl">LDAP</span></a></li>
	                 <li><a href="<?php echo base_url();?>settings/General"><span class="lbl">General</span></a></li>
	                <!--<li><a href="<?php echo base_url();?>settings/smsgateway"><span class="lbl">SMS Gateway</span></a></li>	   -->             
	                <li><a href="<?php echo base_url();?>settings/updates"><span class="lbl">Updates</span></a></li>	               
	                <li><a href="<?php echo base_url();?>settings/backup"><span class="lbl">Backups</span></a></li>       
	                <li><a href="<?php echo base_url();?>settings/licence"><span class="lbl">Licence</span></a></li>	 	               
	            </ul>
	        </li>
	        
	         <?php
	    	}
	    	?>

	        <li class="blue-dirty">
	            <a href="<?php echo base_url();?>user/logout">
	                <i class="fa fa-lock"></i>
	                <span class="lbl">Logout</span>
	            </a>
	        </li>
	    </ul>
	</nav><!--.side-menu-->