<div class="page-content" id="composeresponse">
		<div class="container-fluid">
			<section class="card">
				<header class="card-header card-header-lg">
					Backup & Restore 
				</header>
				<div class="card-block">
					<div class="row ">
					<?php echo $this->session->flashdata("backupmsg");?>
						<form action="<?php echo base_url();?>settings/createbackup" method="post">
							<input type="submit" name="submit" value="Create Backup" class="btn btn-success">
						</form>
						<div class="col-md-12">
						<br>
						<br>
							<table class="table table-striped">
							<tr>
								<th>S.No.</th>
								<th>Name</th>
								<th>Timestamp</th>
								<th>Restore</th>
							</tr>
								<?php
								$i=1;
								foreach ($files as $key => $value) {
									?>
									<tr>
									<td><?php echo $i++;?><td>
									<td><?php echo $value;?><td>
									<td><?php echo date($this->config->item('general_datetimeformat'),filemtime("./backups/".$value));?><td>
									<td><a href="<?php echo base_url();?>settings/restorebackup/<?php echo $value;?>">Restore Backup</a><td>
									</tr>
									<?php
								}
								?>
							</table>
							
						</div>
					</div>					
				</div>
			</section>
		</div><!--.container-fluid-->
</div><!--.page-content-->
	