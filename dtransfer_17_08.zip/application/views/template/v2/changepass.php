<div class="page-content" id="composeresponse">
		<div class="container-fluid">
			<section class="card">
				<header class="card-header card-header-lg">
					Change Password
				</header>
				<div class="card-block">
                    <div class="row">
					   <div class="col-md-6">
    						<form action="#">
                            <div class="form-group form-md-line-input form-md-floating-label">
                                <label for="oldpass" class="control-label">Current Password</label>
                                <input type="password" class="form-control" id="oldpass" required> </div>
                            <div class="form-group form-md-line-input form-md-floating-label">
                                <label for="newpassword" class="control-label">New Password</label>
                                <input type="password" class="form-control" id="newpassword" required> </div>
                            <div class="form-group form-md-line-input form-md-floating-label">
                                <label for="repeatpassword" class="control-label">Re-type New Password</label>
                                <input type="password" class="form-control" id="repeatpassword" required> </div>
                            <div class="margin-top-10">
                                <button class="btn green" id="change_password" type="submit"> Change Password </button>
                               </div>
                               <br>
                               <br>
                               <span id="password_result" ></span>
                        </form>
					</div>					
				</div>
			</section>
		</div><!--.container-fluid-->
</div><!--.page-content-->
	