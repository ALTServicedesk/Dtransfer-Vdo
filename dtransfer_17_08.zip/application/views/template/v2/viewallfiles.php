<div class="page-center" id="homepage">
        <div class="page-center-in">
            <div class="container">
                <section class="card">
                    <header class="card-header card-header-lg">
                        All Files
                    </header>
                    <div class="card-block">
                        <?php
                         $filesname=explode(",",$files->filename);
                         //var_dump($files);
                         ?>
                         <table class="table">
                        <tr>
                              <th>S No.</th>
                              <th>File Name</th>
                              <th>File Size</th>
                              <th>Download Link</th>
                        </tr>
                        <?php
                            $i=1;
                            $j=0;
                            foreach ($filesname as $key => $value) {
                              ?>
                              <tr>
                                <td><?php echo $i; ?></td>
                                <td><?php echo $value; ?></td>
                                <td><?php echo file_size($value); ?></td>
                                <td>
                                <?php
                                if($onetime->onetime==1){
                                        if(checkdownload(trim($value),$user_id,$mailid)==false){
                                            ?>
                                                <span id="link_<?php echo $i;?>" > <a id="link_<?php echo $i;?>" href="<?php echo base_url();?>files/download/<?php echo $user_id;?>?filename=<?php echo trim($value);?>" class="btn btn-primary">Download</a> </span>
                                        <?php
                                        }
                                        else{
                                            ?>
                                                Already Downloaded
                                            <?php
                                        }                                                        
                                }
                                else
                                {
                                    ?>
                                                <span id="link_<?php echo $i;?>" ><a  href="<?php echo base_url();?>files/download/<?php echo $user_id;?>?filename=<?php echo trim($value);?>" class="btn btn-primary">Download</a>
                                                </span>
                                    
                                    <?php
                                }
                                    ?>

                            </td>
                              </tr>
                              <?php
                              $j++;
                              $i++;
                            }
                            ?>
                    </table>
                    <!-- <button class="btn btn-primary" id="downloadselected">Download Selected</button>

                <a class="yourlinks"></a> -->
                    </div>
            </section>
            </div>
        </div>
    </div><!--.page-center-->