<div class="page-content" id="composeresponse">
		<div class="container-fluid">
			<section class="card">
				<header class="card-header card-header-lg">
					<?php echo $heading;?>
				</header>
				<div class="card-block">
					<div class="row">
						<div class="col-md-12 reportfileview">
							<?php
							foreach ($errorlogs as $key => $value) {
								?>
									<div class="fm-file loadlogfile" data-logfilename="<?php echo $value['filename'];?>">
										<div class="fm-file-icon">
											<i class="fa fa-file fa-4x"></i>
										</div>
										<div class="fm-file-name"><?php echo $value['filename'];?></div>
										<div class="fm-file-size">
										<?php echo date($this->config->item('general_datetimeformat'),$value['filemtime']);;?>					
										</div>
									</div>
							<?php
							}
							?>
						</div>					
					</div>					
				</div>
			</section>
		</div><!--.container-fluid-->
</div><!--.page-content-->
	