<div class="page-content" id="composeresponse">
		<div class="container-fluid">
			<section class="card">
				<header class="card-header card-header-lg">
					Licence
				</header>
				<div class="card-block">
					<div class="row ">
						<table class="table">
							<tr>
								<th>
									Licence ID
								</th>
								<td>
									<?php echo $licence->licence_id;?>
								</td>
								<th>
									Licence Key
								</th>
								<td>
									<?php echo $licence->key;?>
								</td>
							</tr>
							<tr>
								<th>
									Validity
								</th>
								<td>
									<?php echo $licence->startdate;?> - <?php echo $licence->enddate;?>
								</td>
								<th>
									Status
								</th>
								<td>
									<?php echo ucfirst($licence->status);?>
								</td>
							</tr>
						</table>
					</div>					
				</div>
			</section>
		</div><!--.container-fluid-->
</div><!--.page-content-->
	