<div class="page-content" id="overlay">
		<div class="container-fluid" >
		<section class="card">
				<header class="card-header card-header-lg">
					All Tickets
				</header>
				<div class="card-block">
					<div class="row ">
						<table id="table-edit" class="table table-bordered table-hover datatable">
							<thead>
							<tr>
								<th>
									#
								</th>
								<th>Department</th>
								<th>Subject</th>
								<th>Priority</th>
								<th>Status</th>
								<th>Actions</th>
								</tr>
							</thead>
							<tbody>
								<?php //echo'<pre>';print_r($allticket); 
										$cc = 1;
									foreach ($allticket as $at) {
								?>
								<tr id="<?php echo $cc++; ?>">
									<td><span class="tabledit-span tabledit-identifier"><?php echo $cc; ?></a></span></td>
									<td class="tabledit-view-mode"><span class="tabledit-span"><?php echo $at->TK_department; ?></span></td>
									<td class="tabledit-span"><?php echo $at->TK_subject; ?></td>
									<td class="tabledit-span"><?php echo $at->TK_priority; ?></td>
									<td class="tabledit-span"><?php echo $at->TK_status; ?></td>
									<td><a class="btn btn-success" href="<?php echo base_url();?>support/singleticket/<?php echo $at->TK_id; ?>">View</a></td>
			                    </tr>
			                    <?php 
			                    }
								?>
								
							</tbody>
						</table>

					</div>					
				</div>
			</section>


		</div><!--.container-fluid-->
	</div>