<div class="page-content" id="dashboardadmin">
		<div class="container-fluid">
				<div class="row">
	                    <div class="col-md-6">
	                        <article class="statistic-box purple">
	                            <div>
	                                <div class="number"><?php echo $download=formatBytes($dashboarddata['totalfiledownload']==NULL?"0":$dashboarddata['totalfiledownload']);?></div>
	                                <div class="caption"><div>Download Bandwidth</div></div>
	                                <div class="percent">
	                                </div>
	                            </div>
	                        </article>
	                    </div><!--.col-->
	                    <div class="col-md-6">
	                        <article class="statistic-box yellow">
	                            <div>
	                                <div class="number"><?php echo $upload=formatBytes($dashboarddata['totalfilesizeupload']==NULL?"0":$dashboarddata['totalfilesizeupload']);?></div>
	                                <div class="caption"><div>Upload Bandwidth</div></div>
	                                <div class="percent">
	                                </div>
	                            </div>
	                        </article>
	                    </div><!--.col-->
	                    
	                </div>
		</div><!--.container-fluid-->
</div><!--.page-content-->
	