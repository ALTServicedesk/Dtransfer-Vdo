<div class="page-center" id="homepage">
        <div class="page-center-in">
            <div class="container-fluid">
                <form action="<?php echo base_url();?>user/login" method="post" class="sign-box">
                    <div class="sign-avatar">
                        <img src="<?php echo asset_url();?>img/avatar-sign.png" alt="">
                    </div>

                    <header class="sign-title">Sign In</header>
                    <?php echo $this->session->flashdata("forgotpassmsg");?>
            		<?php echo $this->session->flashdata("messageverify");?>
            		<?php if(isset($messagelogin)) { echo $messagelogin; } ?>
                    
                    <div class="form-group">
                        <input type="email" name="emaillogin" class="form-control" value="<?php echo set_value('emaillogin');?>" placeholder="E-Mail" autocomplete="off" requried>
                        <?php echo form_error('emaillogin');?>
                    </div>
                    <div class="form-group">
                        <input type="password" name="passwordlogin" class="form-control" placeholder="Password"/ requried>
                        <?php echo form_error('passwordlogin');?> 
                    </div>
                    <div class="form-group">
                        <!-- <div class="checkbox float-left">
                            <input type="checkbox" id="signed-in"/>
                            <label for="signed-in">Keep me signed in</label>
                        </div> -->
                        <div class="float-right reset">
                            <a href="<?php echo base_url();?>user/forgotpass">Reset Password</a>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-rounded">Sign in</button>
                    <p class="sign-note">New to our website? <a href="<?php echo base_url();?>user/register">Sign up</a></p>
                    <!--<button type="button" class="close">
                        <span aria-hidden="true">&times;</span>
                    </button>-->
                </form>
            </div>
        </div>
    </div><!--.page-center-->