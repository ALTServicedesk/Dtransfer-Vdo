
					<div class="row ">
						<?php 
						//cal center
						if($this->config->item("user_allow_otp_phone")=="yes" && $this->config->item("user_allow_otp_email")=="yes"){
							$va=2;
							$la=0;
						}
						else{
							$va=4;							
							$la=4;							
						}

						if($this->config->item("user_allow_otp_phone")=="yes")
						{
							?>
								<a id="otp-sentitem" data-sentto="phone" data-mailid="<?php echo $this->input->post('mailid');?>" href="#" class="request_otp">
									<div class="col-md-4 col-md-offset-<?php echo $va;?> col-sm-12 ">
										<section class="widget widget-simple-sm-fill">
											<div class="widget-simple-sm-icon">
												<i class="fa fa-mobile"></i>
											</div>
											<div class="widget-simple-sm-fill-caption">OTP on Mobile</div>
										</section>
									</div><!--.widget-simple-sm-fill-->
								</a>
							<?php
						}
						?>

						<?php 
						if($this->config->item("user_allow_otp_email")=="yes")
						{
							?>
								<a id="otp-sentitem" data-sentto="email" data-mailid="<?php echo $this->input->post('mailid');?>"  href="#" class="request_otp">
									<div class="col-md-4 col-sm-12 col-md-offset-<?php echo $la;?>">
										<section class="widget widget-simple-sm-fill">
											<div class="widget-simple-sm-icon">
												<i class="fa fa-envelope"></i>
											</div>
											<div class="widget-simple-sm-fill-caption">OTP on Email</div>
										</section>
									</div><!--.widget-simple-sm-fill-->
								</a>
							<?php
						}
						?>
					</div>	
			<?php echo $this->session->flashdata('messageotp'); ?>
			<section class="card">
				<header class="card-header card-header-lg">
					Already have OTP?
				</header>
				<form action="#" method="post">
				<div class="card-block">
					<div class="row">
						<div class="col-md-10">
							<input type="text" id="otp" placeholder="OTP" name="otp" class="form-control" autocomplete="off" autofocus="" required>
						</div>
						<div class="col-md-2">
							<input type="submit" data-mailid="<?php echo $this->input->post('mailid');?>" id="checkotpformailview" class="btn btn-success" value="Go">							
						</div>
					</div>
				</div>
				</form>
			</section>