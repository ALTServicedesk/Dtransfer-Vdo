<table class="table table-bordered table-hover">
						<thead>
							<th>S No.</th>
							<th>Sender</th>
							<th>Receiver</th>
							<th>Progress</th>
							<th>Started</th>
							<th>Last Activity</th>
						</thead>
							<?php
							$i=1;
							if (count($uploads)>0) {
							foreach ($uploads as $key => $value) {
							?>
							<tr>
								<td><?php echo $i++;?></td>
								<td><?php echo $value->sender;?></td>
								<td>To : <?php echo $value->email;?><br>
									CC : <?php echo $value->cc_email;?></td>
								<td><span style="color: green"><?php echo $value->percentage;?></span>  | <?php echo $value->current_file_size;?>/<?php echo $value->total_file_size;?></td>
								<td><?php echo date('d-M-Y', strtotime($value->created_at));?><br>
									<?php echo date('h:i:s a', strtotime($value->created_at));?></td>
								<td><?php echo date('d-M-Y', strtotime($value->modified_at));?><br>
								<?php echo date(' h:i:s a', strtotime($value->modified_at));?> </td>
							</tr>
							<?php
							}
						}
						else{
							?>
							<tr>
								<td colspan="6" style="text-align: center">No ongoing uploads.</td>
							</tr>
							<?php
						}
							?>							
						
					</table>