<?php
$image=$maildata->image==""?"assets/img/avatar-2-64.png":"uploads/".$maildata->image;
?>
					<div class="mail-box-work-area-in">
						<header class="mail-box-work-area-header">
							<div class="tbl">
								<div class="tbl-row">
									<div class="tbl-cell">
										<div class="user-card-row">
											<div class="tbl-row">
												<div class="tbl-cell tbl-cell-photo">
													<a href="#">
														<img src="<?php echo base_url().$image;?>" alt="">
													</a>
												</div>
												<div class="tbl-cell">
													<div class="user-card-row-name"><?php echo $maildata->name;?> <?php echo $maildata->lname;?> ( <?php echo $maildata->email;?> )</div>
													<span class="letters-num"><?php echo generatedatetime($maildata->timestamp);?></span>													
												</div>
											</div>
										</div>
									</div>

									<div class="tbl-cell tbl-cell-btns">
										<a href="<?php echo base_url();?>files/trash/<?php echo $maildata->files_id;?>/<?php echo $this->input->post("type");?>" class="btn-icon"><i class="fa fa-trash" aria-hidden="true"></i></a>
										
										<a href="<?php echo base_url();?>user/forward/<?php echo $maildata->files_id;?>/<?php echo $this->input->post("type");?>" class="btn-icon"><i class="fa fa-share" aria-hidden="true"></i></a>
									</div>
								</div>
							</div>
						</header><!--.mail-box-work-area-header-->
						<div class="summernote-theme-1">
									<table class="table table-bordered ">
										<thead>
											<th>Validity</th>
											<td><?php echo $maildata->validity;?> Days</td>
											<th>One Time Download</th>
											<td><?php echo $maildata->onetime==1?'<i class="fa fa-check" aria-hidden="true"></i>':'<i class="fa fa-times" aria-hidden="true"></i>'?></td>
										</thead>
									</table>
								</div>
							<div class="mail-box-letter-opened mail-box-work-area-cont scroll-pane">
								<div class="text-block text-block-typical maildescriptionview">
									<p>
										<?php
										//var_dump($maildata);
										echo $maildata->description;
										?>
									</p>
								</div>

								<div class="mail-box-letter-files">
									<?php
									//files
									$filesizedata=explode(",", $maildata->filesize);
									$files=explode(",", $maildata->filename);
									$jn=0;
									foreach ($files as $key => $value) {
										$ext=explode('.', $value);
										//if($type=="sentmail"){

									?>
										<div class="mail-file <?php echo strtolower($ext[1]);?>">
											<p><a id="downloadfile" data-filename='<?php echo $value;?>' href="#"><?php echo $value;?></a></p>
											<p><?php echo formatBytes($filesizedata[$jn]);?> Kb</p>
										</div>
									<?php
										//}
										//else{
										//}
									$jn++;
									}
									?>
								</div><!--.mail-box-letter-files-->

								
								
							</div><!--.mail-box-letter-opened-->
						</div><!--.mail-box-work-area-cont-->
					</div><!--.main-box-work-area-in-->
