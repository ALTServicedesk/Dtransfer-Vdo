<div class="page-content" id="dashboardadmin">
		<div class="container-fluid">
				<div class="row">
	                    <div class="col-md-4">
	                        <article class="statistic-box red">
	                            <div>
	                                <div class="number"><?php echo $diskspace=formatBytes($dashboarddata['totaldiskspace']);?></div>
	                                <div class="caption"><div>Total Space</div></div>
	                                <div class="percent">
	                                </div>
	                            </div>
	                        </article>
	                    </div><!--.col-->
	                    <div class="col-md-4">
	                        <article class="statistic-box green">
	                            <div>
	                                <div class="number"><?php echo $diskspace=formatBytes($dashboarddata['totalfreespace']);?></div>
	                                <div class="caption"><div>Free Space</div></div>
	                                <div class="percent">
	                                </div>
	                            </div>
	                        </article>
	                    </div><!--.col-->
	                    <div class="col-md-4">
	                        <article class="statistic-box yellow">
	                            <div>
	                                <div class="number"><?php echo $diskspace=formatBytes($dashboarddata['totaldiskspace']-$dashboarddata['totalfreespace']);?></div>
	                                <div class="caption"><div>Used Space</div></div>
	                                <div class="percent">
	                                </div>
	                            </div>
	                        </article>
	                    </div><!--.col-->
	                    <div class="col-md-4">
	                        <article class="statistic-box purple">
	                            <div>
	                                <div class="number"><?php echo $download=formatBytes($dashboarddata['totalfiledownload']==NULL?"0":$dashboarddata['totalfiledownload']);?></div>
	                                <div class="caption"><div>Download Bandwidth</div></div>
	                                <div class="percent">
	                                </div>
	                            </div>
	                        </article>
	                    </div><!--.col-->
	                    <div class="col-md-4">
	                        <article class="statistic-box yellow">
	                            <div>
	                                <div class="number"><?php echo $upload=formatBytes($dashboarddata['totalfilesizeupload']==NULL?"0":$dashboarddata['totalfilesizeupload']);?></div>
	                                <div class="caption"><div>Upload Bandwidth</div></div>
	                                <div class="percent">
	                                </div>
	                            </div>
	                        </article>
	                    </div><!--.col-->
	                    <div class="col-md-4">
	                        <article class="statistic-box green">
	                            <div>
	                                <div class="number"><?php echo $users=$dashboarddata['totalusers'];?></div>
	                                <div class="caption"><div>Total Users</div></div>
	                                <div class="percent">
	                                </div>
	                            </div>
	                        </article>
	                    </div><!--.col-->
	                </div>
	                <div class="row">	                	
						<div class="col-md-6">
			                <section class="card">
			                    <header class="card-header">
			                        Bandwidth Distribution 
			                    </header>
			                    <div class="card-block">
			                        <div id="donut-downloadupload"></div>
			                    </div>
			                </section>
			            </div>
			            <div class="col-md-6">
			                <section class="card">
			                    <header class="card-header">
			                        Disk Space
			                    </header>
			                    <div class="card-block">
			                        <div id="donut-diskspace"></div>
			                        
			                    </div>
			                </section>
			            </div>
			            <!-- <div class="col-md-4">
			                <section class="card">
			                    <header class="card-header">
			                        User Distribution
			                    </header>
			                    <div class="card-block">
			                    <?php var_dump($dashboarddata['groups']);?>
			                        <div id="donut-users"></div>
			                        
			                    </div>
			                </section>
			            </div> -->
			            
						<div class="col-md-6 log-block">
			                <section class="card">
								<header class="card-header card-header-lg">
									User Logs
								</header>
								<div class="card-block">
									<ul class="log-list">
						                        <?php
						                        $trimmedArray = array_map('trim', $userslogs);
						                        foreach ($trimmedArray as $key => $value) {
						                        	
						                        	$explode=explode("-", $value);
													$str1=$explode[0];
													$str2=$explode[1];
													$str3=$explode[3];
													?>
													<li class="log-item">
														<span class="log-type"><?php echo $str1;?></span>
														<span class="log"><?php echo str_replace(">", "", $str3);?></span>
														<span class="log-time"><?php echo generatedatetime(str_replace("/", "-", $str2));?></span>
													</li>
												<?php
						                        	
						                        }
						                        ?>
									</ul>
								</div>
							</section>						
						</div>
						<div class="col-md-6 log-block">
			                <section class="card">
								<header class="card-header card-header-lg">
									SMTP Logs
								</header>
								<div class="card-block">
									<ul class="log-list">
						                        <?php
						                        $trimmedArray = array_map('trim', $smtplogs);
						                        foreach ($trimmedArray as $key => $value) {
						                        	
						                        	$explode=explode("-", $value);
													$str1=$explode[0];
													$str2=$explode[1];
													$str3=$explode[3];
													?>
													<li class="log-item">
														<span class="log-type"><?php echo $str1;?></span>
														<span class="log"><?php echo str_replace(">", "", $str3);?></span>
														<span class="log-time"><?php echo generatedatetime(str_replace("/", "-", $str2));?></span>
													</li>
												<?php
						                        	
						                        }
						                        ?>
									</ul>
								</div>
							</section>						
						</div>
					</div>
		</div><!--.container-fluid-->
</div><!--.page-content-->
	
<!--.script params-->
<?php //echo formatBytesboth($dashboarddata['totalfiledownload']);?>
<?php echo $spaceper=round($dashboarddata['totalfreespace']/$dashboarddata['totaldiskspace']*100,1)?>
	<script type="text/javascript">
			var dashboard_download="<?php echo $dashboarddata['totalfiledownload'];?>";
			var dashboard_upload="<?php echo $dashboarddata['totalfilesizeupload'];?>";
			var dashboard_spaceper="<?php echo $spaceper;?>";
	</script>