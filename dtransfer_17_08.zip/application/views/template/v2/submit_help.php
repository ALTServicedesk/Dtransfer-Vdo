<div class="page-content" id="overlay">
		<div class="container-fluid" >
        <section class="card">
                <header class="card-header card-header-lg">
                    Submit Ticket
                </header>
                <div class="card-block">
                    <?php echo $this->session->flashdata('msg'); ?>
                            <?php if(validation_errors() || isset($error)) : ?>
                                         <div class="alert alert-danger" role="alert" align="center">
                                            <?=validation_errors()?>
                                            <?=(isset($error)?$error:'')?>
                                         </div>
                                      <?php endif; ?>
                                      <?php $attributes = array("name" => "submitticket", "data-parsley-validate novalidate");
                        echo form_open_multipart("help/submitticket", $attributes);?>
                                    <div class="row">

                                        <div class="form-group col-md-6 col-sm-12">
                                       
                                        
                                            <label for="department">Department<span class="text-danger">*</span></label>
                                            <select required name="department" class="form-control" id="department">
                                                 <option value="">Select</option>
                                                 <option value="sales">sales</option>
                                                 <option value="support">support</option>
                                                 <option value="general">general</option>
                                            </select>
                                        </div>
                                         <div class="form-group col-md-6 col-sm-12">
                                              <label for="subject">Subject<span class="text-danger">*</span></label>
                                             
                                              <input type="text" name="subject" required class="form-control number" id="subject">
                                           
                                        </div>
                                        
                                    </div>
                                    <div class="row">
                                        <div class="form-group col-md-6 col-sm-12">
                                            <label for="priority">Priority<span class="text-danger">*</span></label>
                                                  <select required name="priority" class="form-control" id="priority">
                                                       <option value="">Select</option>
                                                       <option value="normal">Normal</option>
                                                       <option value="high">High</option>
                                                       <option value="urgent">Urgent</option>
                                                  </select>
                                        </div>
                                        
                                       <div class="form-group col-md-6 col-sm-12">
                                            
                                             <?php if($user->type == 3){ ?>
                                             <label for="user">User<span class="text-danger">*</span></label>
                                             <select required name="userid" class="form-control" id="user">
                                                 <option value="">Select</option>
                                                <?php foreach($allusers  as $all){ ?>
                                                 <option value="<?php echo $all->user_id; ?>"><?php echo $all->name.' '.$all->lname; ?></option>
                                                 <?php } ?>
                                                  </select>
                                            
                                                <?php }else{ ?>

                                                <input type="hidden" name="userid" required class="form-control number" value="<?php echo $user->user_id; ?>" id="user">

                                                <?php } ?>
                                             
                                            
                                        </div> 
                                        

                                    </div>
                                    <div class="row">
                                         
                                    </div>
                                    <div class="row">

                                       <div class="form-group col-md-12 col-sm-12">
                                            <label for="description">Description<span class="text-danger">*</span></label>
                                            <textarea class="form-control" name="description" parsley-trigger="change" id="description"></textarea>
                                       </div>
                                      
                                    </div>
                                    
                                    <div class="form-group text-right m-b-0">
                                        <button class="btn btn-primary waves-effect waves-light" type="submit">
                                           <i class="fa fa-save"></i> Save
                                        </button>
                                        <button type="reset" class="btn btn-secondary waves-effect m-l-5">
                                            Cancel
                                        </button>
                                    </div>

                               <?php echo form_close(); ?>

                </div>
            </section>

        
		</div><!--.container-fluid-->
	</div>