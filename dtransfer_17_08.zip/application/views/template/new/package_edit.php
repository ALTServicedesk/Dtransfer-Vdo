<div class="page-content">
                    <!-- BEGIN PAGE HEAD-->
                    
<div class="col-md-12 ">
                            <!-- BEGIN SAMPLE FORM PORTLET-->
                            <div class="portlet box green">
                                <div class="portlet-title">
                                    <div class="caption">
                                        <i class="fa fa-gear"></i>Package Add</div>
                                    <div class="tools"> </div>
                                </div>
                                <div class="portlet-body form">
                                        <div class="form-body">
                                        <?php if(isset($message)) { echo $message; } ?>

                                          <form action="<?php echo base_url();?>packages/edit/<?php echo $package->package_id;?>" method="POST">
                                            <input type="hidden" name="package_id" value="<?php echo $package->package_id;?>">
                              
                                            <div class="form-group form-md-line-input form-md-floating-label">
                                                <input type="text" name="name" value="<?php echo $package->name;?>"  id="form_control_1" autocomplete="off" class="form-control">
                                                <label for="form_control_1">Package Name</label>
                                                <?php echo form_error("name");?>
                                            </div>

                                            <div class="form-group form-md-line-input form-md-floating-label">
                                                <input type="text" name="price" value="<?php echo $package->price;?>"  id="form_control_1" autocomplete="off" class="form-control">
                                                <label for="form_control_1">Package Price</label>
                                                <?php echo form_error("price");?>
                                            </div>

                                             <div class="form-group form-md-line-input form-md-floating-label">
                                                <input type="text" name="size" value="<?php echo $package->size;?>"  id="form_control_1" autocomplete="off" class="form-control">
                                                <label for="form_control_1">Disk Size(MB)</label>
                                                <?php echo form_error("size");?>
                                            </div>

                                            <div class="form-group form-md-line-input form-md-floating-label">
                                                <input type="text" name="bandwidth" value="<?php echo $package->bandwidth;?>"  id="form_control_1" autocomplete="off" class="form-control">
                                                <label for="form_control_1">Bandwidth</label>
                                                <?php echo form_error("bandwidth");?>
                                            </div>
                                            <div class="form-group form-md-line-input form-md-floating-label">
                                            
                                              <select class="form-control" name="validity">
                                                <option <?php if($package->validity=="3") { echo "selected"; } ?> value='3'>3 Months</option>
                                                <option <?php if($package->validity=="6") { echo "selected"; } ?> value='6'>6 Months</option>
                                                <option <?php if($package->validity=="9") { echo "selected"; } ?> value='9'>9 Months</option>
                                                <option <?php if($package->validity=="12") { echo "selected"; } ?> value='12'>12 Months</option>
                                              
                                              </select>
                                            <label for="form_control_1">Validity</label>
                                            <?php echo form_error("validity");?>
                                            
                                          </div>

                                          <div class="form-group form-md-line-input form-md-floating-label">
                                            
                                              <select class="form-control" name="status">
                                                <option <?php if($package->status=="0") { echo "selected"; } ?> value='0'>Active</option>
                                                <option <?php if($package->status=="1") { echo "selected"; } ?> value='1'>Inactive</option>
                                                
                                              </select>
                                            <label for="form_control_1">Status</label>
                                            <?php echo form_error("status");?>
                                            
                                          </div>

                                          <div class="form-group form-md-line-input form-md-floating-label">
                                                <input type="text" name="packageorder" value="<?php echo $package->packageorder;?>"  id="form_control_1" autocomplete="off" class="form-control">
                                                <label for="form_control_1">Package Order</label>
                                                <?php echo form_error("packageorder");?>
                                            </div>
                                           
                                           
                                        <div class="form-actions noborder">
                                            <button class="btn blue" type="submit">Update</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                            <!-- END SAMPLE FORM PORTLET-->
                            <!-- BEGIN SAMPLE FORM PORTLET-->
                            
                        </div> 

</div>