<div class="page-content">

               <!-- BEGIN EXAMPLE TABLE PORTLET-->
                            <div class="portlet box green">
                                <div class="portlet-title">
                                    <div class="caption">
                                        <i class="fa fa-cubes"></i>Packages </div>
                                    <div class="tools"> </div>
                                </div>
                                <div class="portlet-body pricing-content-1">
                                    <?php if(isset($message)){ echo "<p class='alert alert-success'>".$message."</p>"; } ?>
        
                                    <div class="row">
                                        <?php
                                        $i=1;
                                            foreach ($packages as $key => $value) {
                                                if($i==1){ $color="blue"; }
                                                if($i==2){ $color="red"; }
                                                if($i==3){ $color="green"; }
                                                if($i==4){ $color="purple"; }
                                                //else{ $color="blue"; }
                                            ?>
                                            <div class="col-md-3">
                                            <div class="price-column-container border-active">
                                                <div class="price-table-head bg-<?php echo $color;?>">
                                                    <h2 class="no-margin"><?php echo $value->name; ?></h2>
                                                </div>
                                                <div class="arrow-down border-top-blue"></div>
                                                <div class="price-table-pricing">
                                                    <h3>
                                                        <span class="price-sign"><i class="fa fa-inr"></i></span><?php echo $value->price; ?></h3>
                                                    <p><?php echo $value->validity; ?> months</p>
                                                </div>
                                                <div class="price-table-content">
                                                    <div class="row mobile-padding">
                                                        <div class="col-xs-3 text-right mobile-padding">
                                                            <i class="icon-drawer"></i>
                                                        </div>
                                                        <div class="col-xs-9 text-left mobile-padding"><?php echo $value->size; ?>MB Storage</div>
                                                    </div>
                                                    <div class="row mobile-padding">
                                                        <div class="col-xs-3 text-right mobile-padding">
                                                            <i class="icon-screen-smartphone"></i>
                                                        </div>
                                                        <div class="col-xs-9 text-left mobile-padding"><?php echo $value->bandwidth; ?>MB Bandwidth</div>
                                                    </div>
                                                    <div class="row mobile-padding">
                                                        <div class="col-xs-3 text-right mobile-padding">
                                                            <i class="icon-refresh"></i>
                                                        </div>
                                                        <div class="col-xs-9 text-left mobile-padding">Vaild For <?php echo $value->validity; ?> months</div>
                                                    </div>
                                                </div>
                                                <div class="arrow-down arrow-grey"></div>
                                                <div class="price-table-footer">
                                                    <button class="btn grey-salsa btn-outline sbold uppercase price-button requestupgradebtn" type="button" data-name="<?php echo $value->name;?>" data-id="<?php echo $value->package_id;?>" >REQUEST UPGRADE</button>
                                                </div>
                                            </div>
                                        </div>
                                        <?php
                                        $i++;
                                        }
                                        ?>
                                    </div>
                                </div>
                            </div>
                            <!-- END EXAMPLE TABLE PORTLET-->
</div>