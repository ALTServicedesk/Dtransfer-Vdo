<div class="page-content">
                    <!-- BEGIN PAGE HEAD-->
                    
<div class="col-md-12 ">
                            <!-- BEGIN SAMPLE FORM PORTLET-->
                            <div class="portlet box green">
                                <div class="portlet-title">
                                    <div class="caption">
                                        <i class="fa fa-gear"></i>Package Add</div>
                                    <div class="tools"> </div>
                                </div>
                                <div class="portlet-body form">
                                        <div class="form-body">
                                        <?php if(isset($message)) { echo $message; } ?>

                                          <form action="<?php echo base_url();?>packages/add" method="POST">
                                            
                                            <div class="form-group form-md-line-input form-md-floating-label">
                                                <input type="text" name="name" value="<?php echo set_value('name');?>"  id="form_control_1" autocomplete="off" class="form-control">
                                                <label for="form_control_1">Package Name</label>
                                                <?php echo form_error("name");?>
                                            </div>

                                            <div class="form-group form-md-line-input form-md-floating-label">
                                                <input type="text" name="price" value="<?php echo set_value('price');?>"  id="form_control_1" autocomplete="off" class="form-control">
                                                <label for="form_control_1">Package Price</label>
                                                <?php echo form_error("price");?>
                                            </div>

                                             <div class="form-group form-md-line-input form-md-floating-label">
                                                <input type="text" name="size" value="<?php echo set_value('size');?>"  id="form_control_1" autocomplete="off" class="form-control">
                                                <label for="form_control_1">Disk Size(MB)</label>
                                                <?php echo form_error("size");?>
                                            </div>

                                            <div class="form-group form-md-line-input form-md-floating-label">
                                                <input type="text" name="bandwidth" value="<?php echo set_value('bandwidth');?>"  id="form_control_1" autocomplete="off" class="form-control">
                                                <label for="form_control_1">Bandwidth</label>
                                                <?php echo form_error("bandwidth");?>
                                            </div>
                                            <div class="form-group form-md-line-input form-md-floating-label">
                                            
                                              <select class="form-control" name="validity">
                                                <option value='3'>3 Months</option>
                                                <option value='6'>6 Months</option>
                                                <option value='9'>9 Months</option>
                                                <option value='10'>10 Months</option>
                                                <option value='12'>12 Months</option>
                                              </select>
                                            <label for="form_control_1">Bandwidth</label>
                                            <?php echo form_error("validity");?>
                                            
                                          </div>

                                          <div class="form-group form-md-line-input form-md-floating-label">
                                                <input type="text" name="packageorder" value="<?php echo set_value('packageorder');?>"  id="form_control_1" autocomplete="off" class="form-control">
                                                <label for="form_control_1">Package Order</label>
                                                <?php echo form_error("packageorder");?>
                                            </div>
                                           
                                           
                                        <div class="form-actions noborder">
                                            <button class="btn blue" type="submit">Add</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                            <!-- END SAMPLE FORM PORTLET-->
                            <!-- BEGIN SAMPLE FORM PORTLET-->
                            
                        </div> 

</div>