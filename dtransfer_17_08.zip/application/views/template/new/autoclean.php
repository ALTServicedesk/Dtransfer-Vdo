<div class="page-content">
                    <!-- BEGIN PAGE HEAD-->
                    <div class="page-head">
                        <!-- BEGIN PAGE TITLE -->
                        <div class="page-title">
                            <h1>Dasboard
                                <small>all information gathered here</small>
                            </h1>
                        </div>
                        <!-- END PAGE TITLE -->
                    </div>
                    <!-- END PAGE HEAD-->
                    <!-- BEGIN PAGE BREADCRUMB -->
                    
                    <!-- END PAGE BREADCRUMB -->
                    <!-- BEGIN PAGE BASE CONTENT -->
                       <p class="alert alert-warning"> It cleans all the files whose timeperiod has expired. It cleans automatically, but you can do it manually also.</p>
                        
                       <p class="alert alert-success"> Autoclean run successful.....</p>
                 
                </div>