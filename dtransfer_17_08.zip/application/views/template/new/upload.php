<style type="text/css">
    .foo {
   position : relative;
}
.foo .wrapperfile {
    background: rgba(0,0,0,.5);
    z-index : 10;
    position : absolute;
    top : 0;
    left : 0;
}
</style>
<div class="page-content">
                    <!-- BEGIN PAGE HEAD-->
                    <div class="page-head">
                    </div>
                    <div class="col-md-12 ">
                        <?php if(isset($message)) { echo "<p class='alert alert-success'>".$message."</p>" ; } ?>
                                <div class="portlet box green">
                                            <div class="portlet-title">
                                                <div class="caption">
                                                    <i class="fa fa-share"></i>Send Files </div>
                                                <div class="tools">
                                                    <a class="collapse" href="javascript:;" data-original-title="" title=""> </a>
                                                    <a class="config" data-toggle="modal" href="#portlet-config" data-original-title="" title=""> </a>
                                                    <a class="reload" href="javascript:;" data-original-title="" title=""> </a>
                                                    <a class="remove" href="javascript:;" data-original-title="" title=""> </a>
                                                </div>
                                            </div>
                                            <div class="portlet-body form foo">
                                                <div class="form-body" id="filecontainer">
                                                            <!-- BEGIN FORM-->
                                                           <form id="fileupload" action="<?php echo base_url();?>user/uploadfile" method="POST" enctype="multipart/form-data">
                                                           
                                                           <input type="hidden" id="staff" class="form-control" name="staff[]">
                                                           <input type="hidden" name="session_id" value="<?php echo $session_id;?>">
								                            <input type="hidden" name="userid" value="<?php echo $user->user_id;?>">
                                                           
                                                               <div class="row form-group form-md-line-input form-md-floating-label">
                                                                    <label for="form_control_1" class="col-sm-3">Enter Email
                                                                        <br>
                                                                        <span style="color:#32C5D2;font-size:11px;">Use space or enter to vailidate email</span>
                                                                    </label>
                                                                    <span class="help-block">Use space to vailidate email...</span>
                                                                    <div class="col-sm-9">
                                                                        <div class="multiple-val-input">
                                                                            <ul>
                                                                                <input type="text" class="form-control" id="emailchangeinput" autofocus="true">
                                                                                <span class="input_hidden"></span>
                                                                            </ul>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            
                                                            <div class="row form-group form-md-line-input form-md-floating-label">
                                                                <label class="col-sm-3 form-control-label" for="inputEmail3">Description</label>
                                                                <div class="col-sm-9">
                                                                  <textarea class="form-control" name="description" required></textarea>
                                                                </div>
                                                            </div>
                                                            <div class="form-group row  form-md-line-input form-md-floating-label">
                                                                <label class="col-sm-3 form-control-label" for="inputEmail3">Validity</label>
                                                                <div class="col-sm-9">
                                                                    <div class="md-radio-inline">
                                                                        <div class="md-radio">
                                                                            <input type="radio" class="md-radiobtn" checked="" name="validity" value="1" id="radio1">
                                                                            <label for="radio1">
                                                                                <span class="inc"></span>
                                                                                <span class="check"></span>
                                                                                <span class="box"></span> 1 Day </label>
                                                                        </div>
                                                                        <div class="md-radio">
                                                                            <input type="radio"  class="md-radiobtn" value="3" name="validity" id="radio2">
                                                                            <label for="radio2">
                                                                                <span class="inc"></span>
                                                                                <span class="check"></span>
                                                                                <span class="box"></span> 3 Days </label>
                                                                        </div>
                                                                        <div class="md-radio">
                                                                            <input type="radio" class="md-radiobtn" name="validity" value="7" id="radio3">
                                                                            <label for="radio3">
                                                                                <span class="inc"></span>
                                                                                <span class="check"></span>
                                                                                <span class="box"></span> 7 Days </label>
                                                                        </div>                                                                 
                                                                    </div>
                                                                </div>
                                                            </div>

                                                            <div class="form-group row  form-md-line-input form-md-floating-label">
                                                                <label class="col-sm-3 form-control-label" for="inputEmail3">One Time Download</label>
                                                                <div class="col-sm-9">
                                                                    <div class="md-radio-inline">
                                                                        <div class="md-radio">
                                                                            <input type="radio" class="md-radiobtn" checked="" name="onetime" value="1" id="yes1">
                                                                            <label for="yes1">
                                                                                <span class="inc"></span>
                                                                                <span class="check"></span>
                                                                                <span class="box"></span> Yes</label>
                                                                        </div>
                                                                        <div class="md-radio">
                                                                            <input type="radio"  class="md-radiobtn" value="0" name="onetime" id="no2">
                                                                            <label for="no2">
                                                                                <span class="inc"></span>
                                                                                <span class="check"></span>
                                                                                <span class="box"></span> NO </label>
                                                                        </div>                                                               
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            
                                                            <div class="row form-group form-md-line-input form-md-floating-label">
                                                                            <label class="col-sm-3">Select Files</label>
                                                                            <div class="col-sm-9">
                                                                                        <table role="presentation" class="table table-striped"><tbody class="files"></tbody></table>
                                                                                        <div class="checkbox">
                                                                                        <div >
                                                                                       <!-- Redirect browsers with JavaScript disabled to the origin page -->
                                                                                        <noscript><input type="hidden" name="redirect" value="https://blueimp.github.io/jQuery-File-Upload/"></noscript>
                                                                                        <!-- The fileupload-buttonbar contains buttons to add/delete files and start/cancel the upload -->
                                                                                        <div class="row fileupload-buttonbar">
                                                                                            <div class="col-lg-12">
                                                                                                <!-- The fileinput-button span is used to style the file input field as button -->
                                                                                                <div data-provides="fileinput" class="fileinput fileinput-new">
                                                                                                    <span class="btn green btn-file">
                                                                                                        <span class="fileinput-new"> <i class="fa fa-file"></i> Select files </span>
                                                                                                        <span class="fileinput-exists"> <i class="fa fa-file"></i> Add More </span>
                                                                                                        <input type="hidden"><input type="file" id="file" name="files[]" multiple> </span>
                                                                                                   <!--  <span class="fileinput-filename"> </span> &nbsp; -->
                                                                                                    <a data-dismiss="fileinput" class="close fileinput-exists" href="javascript:;"> </a>
                                                                                                </div>
                                                                                                
                                                                                                <button type="submit" class="btn btn-primary start">
                                                                                                    <i class="fa fa-upload"></i>
                                                                                                    <span>Upload Files & Send</span>
                                                                                                </button>
                                                                                                <button type="reset" class="btn btn-warning cancel">
                                                                                                    <i class="fa fa-times"></i>
                                                                                                    <span>Cancel upload</span>
                                                                                                </button>
                                                                                                <button type="button" class="btn btn-info cancel">
                                                                                                    <i class="fa fa-upload"></i>
                                                                                                    <span>Upload Manually</span>
                                                                                                </button>
                                                                                                <button type="button" class="btn btn-danger delete">
                                                                                                    <i class="fa fa-trash"></i>
                                                                                                    <span>Delete</span>
                                                                                                </button>
                                                                                                <input type="checkbox" class="toggle">
                                                                                                <!-- The global file processing state -->
                                                                                                <span class="fileupload-process"></span>
                                                                                            </div>
                                                                                            <br>
                                                                                            <br>
                                                                                            <!-- The global progress state -->
                                                                                            <div class="col-lg-12 fileupload-progress fade">
                                                                                                <!-- The global progress bar -->
                                                                                                <div class="progress progress-striped active" role="progressbar" aria-valuemin="0" aria-valuemax="100">
                                                                                                    <div class="progress-bar progress-bar-success" style="width:0%;"></div>
                                                                                                </div>
                                                                                                <!-- The extended global progress state -->
                                                                                                <div class="progress-extended">&nbsp;</div>
                                                                                            </div>
                                                                                        </div>
                                                                    <!-- The table listing the files available for upload/download -->
                                                               </div>
                                                            </div>
                                                        </form>
                                                <!-- END FORM-->

                                                <div id="response"></div>
                                            </div>
                                        </div> 
                                                <p class="alert alert-warning" style="background: #ed6b75;color: #fff;" id="messagewarning">Please do not leave the page until message is sent, In case of network issue please stay on the page to resume the upload after network is back.</p>
                    </div> 

</div>
<script>
 window.onbeforeunload = function(){
  return 'Are you sure you want to leave?';
};
</script>
<script id="template-upload" type="text/x-tmpl">
{% for (var i=0, file; file=o.files[i]; i++) { %}
    <tr class="template-upload fade">
        <td>
            <span class=""></span>
        </td>
        <td>
            <p class="name">{%=file.name%}</p>
            <strong class="error text-danger"></strong>
        </td>
        <td>
            <p class="size">Processing...</p>
            <div class="progress progress-striped active" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><div class="progress-bar progress-bar-success" style="width:0%;"></div></div>
        </td>
        <td>
            {% if (!i && !o.options.autoUpload) { %}
                <button class="btn btn-primary start" style="display:none;" disabled>
                    <i class="glyphicon glyphicon-upload"></i>
                    <span></span>
                </button>
            {% } %}
            {% if (!i) { %}
                <button class="btn btn-warning cancel">
                    <i class="glyphicon glyphicon-ban-circle"></i>
                    <span>Cancel</span>
                </button>
            {% } %}
        </td>
    </tr>
{% } %}
</script>
<!-- The template to display files available for download -->
<script id="template-download" type="text/x-tmpl">
{% for (var i=0, file; file=o.files[i]; i++) { %}
    <tr class="template-download fade">
        <td>
            <span class="">
                {% if (file.thumbnailUrl) { %}
                    <img src="{%=file.thumbnailUrl%}">
                {% } %}
            </span>
        </td>
        <td>
            <p class="name">
                {% if (file.url) { %}
                    {%=file.name%}
                    <input type="hidden" value="{%=file.name%}" name="filename[]">
                    <input type="hidden" value="{%=file.size%}" name="filesize[]">
                {% } else { %}
                    <span>{%=file.name%}</span>
                {% } %}
            </p>
            {% if (file.error) { %}
                <div><span class="label label-danger">Error</span> {%=file.error%}</div>
            {% } %}
        </td>
        <td>
            <span class="size">{%=o.formatFileSize(file.size)%}</span>
        </td>
        <td>
            {% if (file.deleteUrl) { %}
                <button class="btn btn-danger delete" data-type="{%=file.deleteType%}" data-url="{%=file.deleteUrl%}"{% if (file.deleteWithCredentials) { %} data-xhr-fields='{"withCredentials":true}'{% } %}>
                    <i class="glyphicon glyphicon-trash"></i>
                    <span>Delete</span>
                </button>
                <input type="checkbox" name="delete" value="1" class="toggle">
            {% } else { %}
                <button class="btn btn-warning cancel">
                    <i class="glyphicon glyphicon-ban-circle"></i>
                    <span>Cancel</span>
                </button>
            {% } %}
        </td>
    </tr>
{% } %}
</script>
