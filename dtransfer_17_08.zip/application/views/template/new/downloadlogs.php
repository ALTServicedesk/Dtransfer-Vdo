<div class="page-content">

               <!-- BEGIN EXAMPLE TABLE PORTLET-->
                            <div class="portlet box green">
                                <div class="portlet-title">
                                    <div class="caption">
                                        <i class="fa fa-globe"></i>Download Logs </div>
                                    <div class="tools"> </div>
                                </div>
                                <div class="portlet-body">
                                    <table class="table table-striped table-bordered table-hover owndatatable" id="sample_2">
                                        <thead>
                                            <th>Sr. No.</th>
                                            <th>Name</th>
                                            <th>Filename</th>
                                            <th>File Size</th>
                                            <th>IP</th>
                                            <th>Time</th>
                                        </thead>
                                        <tbody>
                                           <?php
                                            $i=1;
                                            if($downloadlogs!=NULL)
                                            {
                                                foreach ($downloadlogs as $key => $value) {
                                                    # code...
                                                ?>
                                                <tr>
                                                    <td><?php echo $i++;?></td>
                                                    <td><?php
                                                        echo $value->name." ( ".$value->email.") <br>";
                                                    ?>
                                                    </td>
                                                    <td><?php echo $value->filename;?></td>
                                                    <td><?php echo formatBytes($value->filesize); ?></td>
                                                    <td><?php echo $value->ip;?></td>
                                                    <td><?php echo date("d-m-Y H:m A",strtotime($value->timestamp));?></td>
                                                  
                                                <?php
                                                }
                                                ?>
                                            <?php    
                                            }
                                            else
                                            {
                                                echo "<tr><td colspan='6'>No Data found</td></tr>";
                                            }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <!-- END EXAMPLE TABLE PORTLET-->
</div>