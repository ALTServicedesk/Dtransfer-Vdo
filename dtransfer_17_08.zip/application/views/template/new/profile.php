<?php
 if($user->image=="")
 $imgurl=base_url()."assetsnew/images/icon-user-default.png";
 else
  $imgurl=base_url()."uploads/".$user->image;
?>

<div class="page-content">
                    <!-- BEGIN PAGE HEAD-->
                    <div class="page-head">
                        <!-- BEGIN PAGE TITLE -->
                        <div class="page-title">
                            <h1>Profile
                            </h1>
                        </div>
                        <!-- END PAGE TITLE -->
                    </div>
                    <div class="col-md-12">
                            <!-- BEGIN PROFILE SIDEBAR -->
                            <div class="profile-sidebar">
                                <!-- PORTLET MAIN -->
                                <div class="portlet light profile-sidebar-portlet bordered">
                                    <!-- SIDEBAR USERPIC -->
                                    <div class="profile-userpic">
                                        <img alt="" class="img-responsive" src="<?php echo $imgurl;?>"> </div>
                                    <!-- END SIDEBAR USERPIC -->
                                    <!-- SIDEBAR USER TITLE -->
                                    <div class="profile-usertitle">
                                        <div class="profile-usertitle-name"> <?php echo $user->name;?> <?php echo $user->lname;?></div>
                                        <div class="profile-usertitle-job"> <a href="mailto:<?php echo $user->email;?>"> <?php echo $user->email;?> </a></div>
                                    </div>
                                    <!-- END SIDEBAR USER TITLE -->
                                    <!-- SIDEBAR BUTTONS 
                                    <div class="profile-userbuttons">
                                        <button class="btn btn-circle green btn-sm" type="button">Follow</button>
                                        <button class="btn btn-circle red btn-sm" type="button">Message</button>
                                    </div>
                                     END SIDEBAR BUTTONS -->
                                    <!-- SIDEBAR MENU -->
                                   
                                    <!-- END MENU -->
                                </div>
                                <!-- END PORTLET MAIN -->
                                <!-- PORTLET MAIN -->
                                
                                <!-- END PORTLET MAIN -->
                            </div>
                            <!-- END BEGIN PROFILE SIDEBAR -->
                            <!-- BEGIN PROFILE CONTENT -->
                            <div class="profile-content">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="portlet light bordered">
                                            <div class="portlet-title tabbable-line">
                                                <div class="caption caption-md">
                                                    <i class="icon-globe theme-font hide"></i>
                                                    <span class="caption-subject font-blue-madison bold uppercase">Profile Account</span>
                                                </div>
                                                <ul class="nav nav-tabs">
                                                    <li class="active">
                                                        <a data-toggle="tab" href="#tab_1_1">Personal Info</a>
                                                    </li>
                                                    <li>
                                                        <a data-toggle="tab" href="#tab_1_2">Change Avatar</a>
                                                    </li>
                                                    <li>
                                                        <a data-toggle="tab" href="#tab_1_3">Change Password</a>
                                                    </li>
                                                </ul>
                                            </div>
                                            <div class="portlet-body">
                                                <div class="tab-content">
                                                    <!-- PERSONAL INFO TAB -->
                                                    <div id="tab_1_1" class="tab-pane active">
                                                        <?php if(isset($message)) { echo "<p class='alert alert-success'>".$message."</p>" ; } ?>
                                                        <form action="<?php echo base_url();?>user/profile" method="POST">
                                                        <div class="form-group form-md-line-input form-md-floating-label">
                                                                <label class="control-label">First Name</label>
                                                                <input type="text" class="form-control" name="name" value="<?php echo $user->name;?>"> </div>
                                                            <div class="form-group form-md-line-input form-md-floating-label">
                                                                <label class="control-label">Last Name</label>
                                                                <input type="text" class="form-control" name="lname" value="<?php echo $user->lname;?>"> </div>
                                                            <div class="form-group form-md-line-input form-md-floating-label">
                                                                <label class="control-label">Mobile Number</label>
                                                                <input type="text" class="form-control" name="phone" value="<?php echo $user->phone;?>"> </div>
                                                            
                                                            <div class="margiv-top-10">
                                                                <button class="btn green" type="submit"> Save Changes </button>
                                                              </div>
                                                        </form>
                                                    </div>
                                                    <!-- END PERSONAL INFO TAB -->
                                                    <!-- CHANGE AVATAR TAB -->
                                                    <div id="tab_1_2" class="tab-pane">
                                                            <?php echo form_open_multipart('user/profileimage');?>
                                                            <div class="form-group">
                                                                <div data-provides="fileinput" class="fileinput fileinput-new">
                                                                    <div style="width: 200px; height: 150px;" class="fileinput-new thumbnail">
                                                                        <img alt="" src="http://www.placehold.it/200x150/EFEFEF/AAAAAA&amp;text=no+image"> </div>
                                                                    <div style="max-width: 200px; max-height: 150px;" class="fileinput-preview fileinput-exists thumbnail"> </div>
                                                                    <div>
                                                                        <span class="btn default btn-file">
                                                                            <span class="fileinput-new"> Select image </span>
                                                                            <span class="fileinput-exists"> Change </span>
                                                                            <input type="file" name="profileimage"> </span>
                                                                        <a data-dismiss="fileinput" class="btn default fileinput-exists" href="javascript:;"> Remove </a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="margin-top-10">
                                                                <button class="btn green" type="submit"> Submit </button>
                                                            </div>
                                                        </form>
                                                    </div>
                                                    <!-- END CHANGE AVATAR TAB -->
                                                    <!-- CHANGE PASSWORD TAB -->
                                                    <div id="tab_1_3" class="tab-pane">
                                                        <form action="#">
                                                            <div class="form-group form-md-line-input form-md-floating-label">
                                                                <label for="oldpass" class="control-label">Current Password</label>
                                                                <input type="password" class="form-control" id="oldpass" required> </div>
                                                            <div class="form-group form-md-line-input form-md-floating-label">
                                                                <label for="newpassword" class="control-label">New Password</label>
                                                                <input type="password" class="form-control" id="newpassword" required> </div>
                                                            <div class="form-group form-md-line-input form-md-floating-label">
                                                                <label for="repeatpassword" class="control-label">Re-type New Password</label>
                                                                <input type="password" class="form-control" id="repeatpassword" required> </div>
                                                            <div class="margin-top-10">
                                                                <button class="btn green" id="change_password" type="submit"> Change Password </button>
                                                               </div>
                                                               <span id="password_result" ></span>
                                                        </form>
                                                    </div>
                                                    <!-- END CHANGE PASSWORD TAB -->
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- END PROFILE CONTENT -->
                        </div>

</div>