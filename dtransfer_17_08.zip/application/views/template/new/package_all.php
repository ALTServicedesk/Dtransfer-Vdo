<div class="page-content">
                    <!-- BEGIN PAGE HEAD-->

               <!-- BEGIN EXAMPLE TABLE PORTLET-->
                            <div class="portlet box green">
                                <div class="portlet-title">
                                    <div class="caption">
                                        <i class="fa fa-globe"></i>Packages </div>
                                    <div class="tools"> </div>
                                </div>
                                <div class="portlet-body">
                                    <table class="table table-striped table-bordered table-hover owndatatable" id="sample_2">
                                        <thead>
                                            <td>Sr. No.</td>
                                            <td>Name</td>
                                            <td>Validity</td>
                                            <td>Disk Size</td>
                                            <td>Bandwidth</td>
                                            <td>Shown Order</td>
                                            <td>Price</td>
                                            <td>Status</td>
                                            <td>Actions</td>
                                        </thead>
                                        <tbody>
                                           <?php
                                            $i=1;
                                                foreach ($packages as $key => $value) {
                                                    
                                                ?>
                                                    <tr>
                                                        <td><?php echo $i++;?></td>
                                                        <td><?php echo $value->name;?></td>
                                                        <td><?php echo $value->validity;?> Months</td>
                                                        <td><?php echo $value->size;?> MB</td>
                                                        <td><?php echo $value->bandwidth;?> MB</td>
                                                        <td><?php echo $value->packageorder;?> </td>
                                                        <td><?php if($value->status==0){ echo "<p class='btn btn-success'>Active</p>"; } else { echo "<p class='btn btn-danger'>Inactive</p>"; } $value->packageorder;?> </td>
                                                        <td><i class="fa fa-inr"></i> <?php echo $value->price;?></td>
                                                        <td><a class="btn btn-success" href="<?php echo base_url();?>packages/edit/<?php echo $value->package_id;?>">Edit</a></td>
                                                    </tr>
                                                <?php
                                                }
                                                ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <!-- END EXAMPLE TABLE PORTLET-->
</div>