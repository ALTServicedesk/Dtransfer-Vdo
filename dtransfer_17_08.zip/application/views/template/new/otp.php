<div class="page-content">
                    <!-- BEGIN PAGE HEAD-->
                    <div class="page-head">
                        <!-- BEGIN PAGE TITLE -->
                        <div class="page-title">
                            <h1>Request Access
                                <small>all information gathered here</small>
                            </h1>
                        </div>
                        <!-- END PAGE TITLE -->
                    </div>
<div class="col-md-12 ">
                            <!-- BEGIN SAMPLE FORM PORTLET-->
                            <div class="portlet light bordered">
                                <div class="portlet-title">
                                    <div class="caption font-green">
                                        <i class="icon-pin font-green"></i>
                                        <span class="caption-subject bold"> We have sent an OTP over email to <?php echo $user->email;?></span>
                                    </div>
                                </div>
                                <div class="portlet-body form">
                                        <div class="form-body">
                                         <?php if(isset($error)) { echo "<p class='alert alert-danger'>".$error."</p>" ; } ?>
                                        <form id="fileupload" action="<?php echo base_url();?>user/upload" method="POST" enctype="multipart/form-data">
               
                                            <div class="form-group form-md-line-input form-md-floating-label">
                                                <input type="text" name="otp" id="form_control_1" autocomplete="off" class="form-control">
                                                <label for="form_control_1">Enter OTP</label>
                                                <span class="help-block">Please enter otp received on email if not received yet request it again...</span>
                                            </div>
                                            
                                        </div>
                                        <div class="form-actions noborder">
                                            <button class="btn blue" type="submit">Submit</button>
                                            <a class="btn default" href="<?php echo base_url();?>user/requestotp/upload/<?php echo $user->user_id;?>">Request OTP Again</a>
                                            
                                        </div>
                                    </form>
                                </div>
                            </div>
                            <!-- END SAMPLE FORM PORTLET-->
                            <!-- BEGIN SAMPLE FORM PORTLET-->
                            
                        </div> 

</div>