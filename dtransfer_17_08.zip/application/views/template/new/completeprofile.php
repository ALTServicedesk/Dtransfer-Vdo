<!DOCTYPE html>

<!--[if IE 8]> <html lang="en" class="ie8 no-js"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9 no-js"> <![endif]-->
<!--[if !IE]><!-->
<html lang="en">
    <!--<![endif]-->
<head>
        <meta charset="utf-8" />
        <title><?php echo $site_settings->title;?></title>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta content="width=device-width, initial-scale=1" name="viewport" />
        <meta content="" name="description" />
        <meta content="" name="author" />
        <!-- BEGIN GLOBAL MANDATORY STYLES -->
        <link href="<?php echo base_url();?>assetsnew/cssbc32.css?family=Open+Sans:400,300,600,700&amp;subset=all" rel="stylesheet" type="text/css" />
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.1/css/font-awesome.min.css">
        <link href="<?php echo base_url();?>assetsnew/global/plugins/simple-line-icons/simple-line-icons.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url();?>assetsnew/global/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url();?>assetsnew/global/plugins/uniform/css/uniform.default.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url();?>assetsnew/global/plugins/bootstrap-switch/css/bootstrap-switch.min.css" rel="stylesheet" type="text/css" />
        <!-- END GLOBAL MANDATORY STYLES -->
        <!-- BEGIN PAGE LEVEL PLUGINS -->
        <link href="<?php echo base_url();?>assetsnew/global/plugins/bootstrap-daterangepicker/daterangepicker.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url();?>assetsnew/global/plugins/morris/morris.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url();?>assetsnew/global/plugins/fullcalendar/fullcalendar.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url();?>assetsnew/global/plugins/jqvmap/jqvmap/jqvmap.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url();?>assetsnew/pages/css/profile.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url();?>assetsnew/global/plugins/bootstrap-fileinput/bootstrap-fileinput.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url();?>assetsnew/pages/css/pricing.min.css" rel="stylesheet" type="text/css" />
        <!-- END PAGE LEVEL PLUGINS -->
        <!-- BEGIN THEME GLOBAL STYLES -->
        <link href="<?php echo base_url();?>assetsnew/global/css/components-rounded.min.css" rel="stylesheet" id="style_components" type="text/css" />
        <link href="<?php echo base_url();?>assetsnew/global/css/plugins.min.css" rel="stylesheet" type="text/css" />
        <!-- END THEME GLOBAL STYLES -->
        <!-- BEGIN THEME LAYOUT STYLES -->
        <link href="<?php echo base_url();?>assetsnew/layouts/layout4/css/layout.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url();?>assetsnew/layouts/layout4/css/themes/light.min.css" rel="stylesheet" type="text/css" id="style_color" />
        <link href="<?php echo base_url();?>assetsnew/layouts/layout4/css/custom.min.css" rel="stylesheet" type="text/css" />
        <!-- END THEME LAYOUT STYLES -->
        <link rel="shortcut icon" href="favicon.ico" /> </head>
    <!-- END HEAD -->
 <body class="page-container-bg-solid page-header-fixed page-sidebar-closed-hide-logo">
        <!-- BEGIN HEADER -->
        <div class="page-header navbar navbar-fixed-top">
            <!-- BEGIN HEADER INNER -->
            <div class="page-header-inner ">
                <!-- BEGIN LOGO -->
                <div class="page-logo">
                    <a href="<?php echo base_url();?>">
                        <img src="<?php echo base_url();?>/assetsnew/img/LOGORGB.png">
                      <?php echo $site_settings->title;?>
                        <div class="menu-toggler sidebar-toggler">
                        <!-- DOC: Remove the above "hide" to enable the sidebar toggler button on header -->
                    </div>
                </div>
                <!-- END LOGO -->
                <!-- BEGIN RESPONSIVE MENU TOGGLER -->
                <a href="javascript:;" class="menu-toggler responsive-toggler" data-toggle="collapse" data-target=".navbar-collapse"> </a>
                <!-- END RESPONSIVE MENU TOGGLER -->
                <!-- BEGIN PAGE ACTIONS -->
                <!-- DOC: Remove "hide" class to enable the page header actions -->
                <div class="page-actions">
                    <div class="btn-group">
                       
                    </div>
                </div>
                <!-- END PAGE ACTIONS -->
                <!-- BEGIN PAGE TOP -->
                <div class="page-top">
                    <!-- BEGIN HEADER SEARCH BOX -->
                    <!-- DOC: Apply "search-form-expanded" right after the "search-form" class to have half expanded search box -->
                   <!--  <form class="search-form" action="http://www.keenthemes.com/preview/metronic/theme/admin_4_rounded/page_general_search_2.html" method="GET">
                        <div class="input-group">
                            <input type="text" class="form-control input-sm" placeholder="Search..." name="query">
                            <span class="input-group-btn">
                                <a href="javascript:;" class="btn submit">
                                    <i class="icon-magnifier"></i>
                                </a>
                            </span>
                        </div>
                    </form> -->
                    <!-- END HEADER SEARCH BOX -->
                    <!-- BEGIN TOP NAVIGATION MENU -->
                    <div class="top-menu">
                        <ul class="nav navbar-nav pull-right">
                            
                        </ul>
                    </div>
                    <!-- END TOP NAVIGATION MENU -->
                </div>
                <!-- END PAGE TOP -->
            </div>
            <!-- END HEADER INNER -->
        </div>
        <!-- END HEADER -->
        <!-- BEGIN HEADER & CONTENT DIVIDER -->
        <div class="clearfix"> </div>
        <!-- END HEADER & CONTENT DIVIDER -->
        <div class="page-container">
            <div class='alert alert-success' style="background: #ed6b75;color: #fff;" id="messagewarning">Complete your profile first to start the download.</div>
<?php
 if($user->image=="")
 $imgurl=base_url()."assetsnew/images/icon-user-default.png";
 else
  $imgurl=base_url()."uploads/".$user->image;
?>

<div class="page-content">
                    <!-- BEGIN PAGE HEAD-->
                    <div class="page-head">
                        <!-- BEGIN PAGE TITLE -->
                        <div class="page-title">
                            <h1>Profile
                            </h1>
                        </div>
                        <!-- END PAGE TITLE -->
                    </div>
                    <div class="col-md-12">
                            <!-- BEGIN PROFILE SIDEBAR -->
                            <div class="profile-sidebar">
                                <!-- PORTLET MAIN -->
                                <div class="portlet light profile-sidebar-portlet bordered">
                                    <!-- SIDEBAR USERPIC -->
                                    <div class="profile-userpic">
                                        <img alt="" class="img-responsive" src="<?php echo $imgurl;?>"> </div>
                                    <!-- END SIDEBAR USERPIC -->
                                    <!-- SIDEBAR USER TITLE -->
                                    <div class="profile-usertitle">
                                        <div class="profile-usertitle-name"> <?php echo $user->name;?> <?php echo $user->lname;?></div>
                                        <div class="profile-usertitle-job"> <a href="mailto:<?php echo $user->email;?>"> <?php echo $user->email;?> </a></div>
                                    </div>
                                    <!-- END SIDEBAR USER TITLE -->
                                    <!-- SIDEBAR BUTTONS 
                                    <div class="profile-userbuttons">
                                        <button class="btn btn-circle green btn-sm" type="button">Follow</button>
                                        <button class="btn btn-circle red btn-sm" type="button">Message</button>
                                    </div>
                                     END SIDEBAR BUTTONS -->
                                    <!-- SIDEBAR MENU -->
                                   
                                    <!-- END MENU -->
                                </div>
                                <!-- END PORTLET MAIN -->
                                <!-- PORTLET MAIN -->
                                
                                <!-- END PORTLET MAIN -->
                            </div>
                            <!-- END BEGIN PROFILE SIDEBAR -->
                            <!-- BEGIN PROFILE CONTENT -->
                            <div class="profile-content">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="portlet light bordered">
                                            <div class="portlet-title tabbable-line">
                                                <div class="caption caption-md">
                                                    <i class="icon-globe theme-font hide"></i>
                                                    <span class="caption-subject font-blue-madison bold uppercase">Profile Account</span>
                                                </div>
                                                <ul class="nav nav-tabs">
                                                    <li class="active">
                                                        <a data-toggle="tab" href="#tab_1_1">Personal Info</a>
                                                    </li>
                                                    <li>
                                                        <a data-toggle="tab" href="#tab_1_2">Change Avatar</a>
                                                    </li>
                                                </ul>
                                            </div>
                                            <div class="portlet-body">
                                                <div class="tab-content">
                                                    <!-- PERSONAL INFO TAB -->
                                                    <div id="tab_1_1" class="tab-pane active">
                                                        <?php if(isset($message)) { echo "<p class='alert alert-success'>".$message."</p>" ; } ?>
                                                        <form action="<?php echo base_url();?>user/completeprofile/<?php echo $user->user_id;?>" method="POST">
                                                        <div class="form-group form-md-line-input form-md-floating-label">
                                                                <label class="control-label">First Name</label>
                                                                <input type="text" class="form-control" name="name" value="<?php echo set_value('name');?>"> </div>
                                                                <?php echo form_error("name");?>
                                                            <div class="form-group form-md-line-input form-md-floating-label">
                                                                <label class="control-label">Last Name</label>
                                                                <input type="text" class="form-control" name="lname" value="<?php echo set_value('lname');?>"> </div>
                                                                <?php echo form_error("lname");?>
                                                            <div class="form-group form-md-line-input form-md-floating-label">
                                                                <label class="control-label">Mobile Number</label>
                                                                <input type="text" class="form-control" name="phone" value="<?php echo set_value('phone');?>"> </div>
                                                                <?php echo form_error("phone");?>
                                                            <div class="form-group form-md-line-input form-md-floating-label">
                                                                <label class="control-label">Set Password</label>
                                                                <input type="password" class="form-control" name="pass" value=""> </div>
                                                                <?php echo form_error("pass");?>
                                                             <div class="form-group form-md-line-input form-md-floating-label">
                                                                <label class="control-label">Confirm Password</label>
                                                                <input type="password" class="form-control" name="confirmpass" value=""> </div>
                                                                <?php echo form_error("confirmpass");?>
                                                            
                                                            <div class="margiv-top-10">
                                                                <button class="btn green" type="submit"> Save Changes </button>
                                                              </div>
                                                        </form>
                                                    </div>
                                                    <!-- END PERSONAL INFO TAB -->
                                                    <!-- CHANGE AVATAR TAB -->
                                                    <div id="tab_1_2" class="tab-pane">
                                                            <?php echo form_open_multipart('user/profileimage');?>
                                                            <div class="form-group">
                                                                <div data-provides="fileinput" class="fileinput fileinput-new">
                                                                    <div style="width: 200px; height: 150px;" class="fileinput-new thumbnail">
                                                                        <img alt="" src="http://www.placehold.it/200x150/EFEFEF/AAAAAA&amp;text=no+image"> </div>
                                                                    <div style="max-width: 200px; max-height: 150px;" class="fileinput-preview fileinput-exists thumbnail"> </div>
                                                                    <div>
                                                                        <span class="btn default btn-file">
                                                                            <span class="fileinput-new"> Select image </span>
                                                                            <span class="fileinput-exists"> Change </span>
                                                                            <input type="file" name="profileimage"> </span>
                                                                        <a data-dismiss="fileinput" class="btn default fileinput-exists" href="javascript:;"> Remove </a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="margin-top-10">
                                                                <button class="btn green" type="submit"> Submit </button>
                                                            </div>
                                                        </form>
                                                    </div>
                                                    <!-- END CHANGE AVATAR TAB -->
                                                    <!-- CHANGE PASSWORD TAB -->
                                                    <div id="tab_1_3" class="tab-pane">
                                                        <form action="#">
                                                            <div class="form-group form-md-line-input form-md-floating-label">
                                                                <label for="oldpass" class="control-label">Current Password</label>
                                                                <input type="password" class="form-control" id="oldpass" required> </div>
                                                            <div class="form-group form-md-line-input form-md-floating-label">
                                                                <label for="newpassword" class="control-label">New Password</label>
                                                                <input type="password" class="form-control" id="newpassword" required> </div>
                                                            <div class="form-group form-md-line-input form-md-floating-label">
                                                                <label for="repeatpassword" class="control-label">Re-type New Password</label>
                                                                <input type="password" class="form-control" id="repeatpassword" required> </div>
                                                            <div class="margin-top-10">
                                                                <button class="btn green" id="change_password" type="submit"> Change Password </button>
                                                               </div>
                                                               <span id="password_result" ></span>
                                                        </form>
                                                    </div>
                                                    <!-- END CHANGE PASSWORD TAB -->
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- END PROFILE CONTENT -->
                        </div>

</div>
<!-- BEGIN CORE PLUGINS -->
        <script type="text/javascript">
        var base_url="<?php echo base_url();?>";
        </script>
        <script src="<?php echo base_url();?>assetsnew/global/plugins/jquery.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assetsnew/global/plugins/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assetsnew/global/plugins/js.cookie.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assetsnew/global/plugins/bootstrap-hover-dropdown/bootstrap-hover-dropdown.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assetsnew/global/plugins/jquery-slimscroll/jquery.slimscroll.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assetsnew/global/plugins/jquery.blockui.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assetsnew/global/plugins/uniform/jquery.uniform.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assetsnew/global/plugins/bootstrap-switch/js/bootstrap-switch.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assetsnew/jquery.media.js" type="text/javascript"></script>
        <!-- END CORE PLUGINS -->
        <!-- BEGIN PAGE LEVEL PLUGINS -->
       <!-- END PAGE LEVEL PLUGINS -->
        <!-- BEGIN THEME GLOBAL SCRIPTS -->
        <script src="<?php echo base_url();?>assetsnew/jquery-ui.min.js"></script>

        <link rel="stylesheet" href="<?php echo base_url();?>assetsnew/jquery-ui.theme.min.css" />

        <script src="<?php echo base_url();?>assetsnew/global/scripts/app.min.js" type="text/javascript"></script>
       <!-- <script src="<?php echo base_url();?>assetsnew/pages/scripts/dashboard.min.js" type="text/javascript"></script>
         END THEME GLOBAL SCRIPTS -->
        <script src="<?php echo base_url();?>assetsnew/pages/scripts/table-datatables-buttons.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assetsnew/pages/scripts/profile.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assetsnew/global/plugins/bootstrap-fileinput/bootstrap-fileinput.js" type="text/javascript"></script>

        <!-- BEGIN THEME LAYOUT SCRIPTS -->
        <script src="<?php echo base_url();?>assetsnew/layouts/layout4/scripts/layout.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assetsnew/layouts/layout4/scripts/demo.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assetsnew/layouts/global/scripts/quick-sidebar.min.js" type="text/javascript"></script>
        <!-- END THEME LAYOUT SCRIPTS -->
        <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assetsnew/datatables.min.css"/>
 
<script type="text/javascript" src="<?php echo base_url();?>assetsnew/datatables.min.js"></script>

 <script src="<?php echo base_url();?>fileuploader/js/vendor/jquery.ui.widget.js"></script>
<!-- The Templates plugin is included to render the upload/download listings -->
<script src="http://blueimp.github.io/JavaScript-Templates/js/tmpl.min.js"></script>
<!-- The Load Image plugin is included for the preview images and image resizing functionality -->
<script src="http://blueimp.github.io/JavaScript-Load-Image/js/load-image.all.min.js"></script>
<!-- The Canvas to Blob plugin is included for image resizing functionality -->
<script src="http://blueimp.github.io/JavaScript-Canvas-to-Blob/js/canvas-to-blob.min.js"></script>
<!-- Bootstrap JS is not required, but included for the responsive demo navigation -->
<script src="http://netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
<!-- blueimp Gallery script -->
<script src="http://blueimp.github.io/Gallery/js/jquery.blueimp-gallery.min.js"></script>
<!-- The Iframe Transport is required for browsers without support for XHR file uploads -->
<script src="<?php echo base_url();?>fileuploader/js/jquery.iframe-transport.js"></script>
<!-- The basic File Upload plugin -->
<script src="<?php echo base_url();?>fileuploader/js/jquery.fileupload.js"></script>
<!-- The File Upload processing plugin -->
<script src="<?php echo base_url();?>fileuploader/js/jquery.fileupload-process.js"></script>
<!-- The File Upload image preview & resize plugin -->
<script src="<?php echo base_url();?>fileuploader/js/jquery.fileupload-image.js"></script>
<!-- The File Upload audio preview plugin -->
<script src="<?php echo base_url();?>fileuploader/js/jquery.fileupload-audio.js"></script>
<!-- The File Upload video preview plugin -->
<script src="<?php echo base_url();?>fileuploader/js/jquery.fileupload-video.js"></script>
<!-- The File Upload validation plugin -->
<script src="<?php echo base_url();?>fileuploader/js/jquery.fileupload-validate.js"></script>
<!-- The File Upload user interface plugin -->
<script src="<?php echo base_url();?>fileuploader/js/jquery.fileupload-ui.js"></script>
<!-- The main application script -->
<script src="<?php echo base_url();?>fileuploader/js/main.js"></script>
     

</body></html>
