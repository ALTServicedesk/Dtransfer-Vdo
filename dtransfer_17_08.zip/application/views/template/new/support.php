<div class="page-content">
                    <!-- BEGIN PAGE HEAD-->
                    <div class="page-head">
                    </div>
                    <div class="col-md-12 ">
                        <?php if(isset($message)) { echo $message ; } ?>
                                
                                <div class="portlet box green">
                                            <div class="portlet-title">
                                                <div class="caption">
                                                    <i class="fa fa-share"></i>Send Support/Feedback </div>
                                                
                                            </div>
                                            <div class="portlet-body form">
                                                <div class="form-body">
                                                            <!-- BEGIN FORM-->
                                                           <form  action="<?php echo base_url();?>user/support" method="POST" enctype="multipart/form-data">
                                                            <input type="hidden" name="user_id" value="<?php echo $user->user_id;?>">
                                                            <div class="row form-group form-md-line-input form-md-floating-label">
                                                                <label class="col-sm-3 form-control-label" for="inputEmail3">To</label>
                                                                <div class="col-sm-9">
                                                                  <input type="text" class="form-control" name="subject" readonly value="<?php echo $site_settings->email;?>">
                                                                <?php echo form_error("ewad"); ?>
                                                                </div>
                                                            </div>

                                                            <div class="row form-group form-md-line-input form-md-floating-label">
                                                                <label class="col-sm-3 form-control-label" for="inputEmail3">Subject</label>
                                                                <div class="col-sm-9">
                                                                  <input type="text" class="form-control" name="subject">
                                                                <?php echo form_error("subject"); ?>
                                                                </div>
                                                            </div>

                                                            <div class="row form-group form-md-line-input form-md-floating-label">
                                                                <label class="col-sm-3 form-control-label" for="inputEmail3">Message</label>
                                                                <div class="col-sm-9">
                                                                  <textarea class="form-control" name="msg"></textarea>
                                                                <?php echo form_error("msg"); ?>
                                                                </div>
                                                            </div>

                                                            <div class="row form-group form-md-line-input form-md-floating-label">
                                                                <div class="col-sm-3"></div>
                                                                <div class="col-sm-9">
                                                                  <input type="submit" class="btn btn-success" value="Send">
                                                                </div>
                                                            </div>

                                                        </form>
                                                <!-- END FORM-->
                                            </div>
                                        </div> 
                    </div> 

</div>
