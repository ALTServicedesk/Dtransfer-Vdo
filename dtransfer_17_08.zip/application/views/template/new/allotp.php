<div class="page-content">

               <!-- BEGIN EXAMPLE TABLE PORTLET-->
                            <div class="portlet box green">
                                <div class="portlet-title">
                                    <div class="caption">
                                        <i class="fa fa-globe"></i>OTP Transactions </div>
                                    <div class="tools"> </div>
                                </div>
                                <div class="portlet-body">
                                    <table class="table table-striped table-bordered table-hover owndatatable" id="sample_2">
                                        <thead>
                                            <th>S No</th>
                                            <th>Used By</th>
                                            <th>Sent to</th>
                                            <th>OTP</th>
                                            <th>Type</th>
                                            <th>Status</th>
                                            <th>Time</th>
                                        </thead>
                                        <tbody>
                                           <?php
                                            $i=1;
                                            if($allotp!=NULL)
                                            {
                                                foreach ($allotp as $key => $value) {
                                                    # code...
                                                ?>
                                                <tr>
                                                    <td><?php echo $i++;?></td>
                                                    <td><?php echo  $value->email." <br>"; ?></td>
                                                    <td><?php echo  $value->sentemail." <br>"; ?></td>
                                                    <td><?php echo $value->otp;?></td>
                                                    <td><?php if($value->type=="download"){ echo "<a class='btn btn-success'><i class='fa fa-download'></i></a>"; } else { echo "<a class='btn btn-warning'><i class='fa fa-upload'></i></a>"; }?></td>
                                                    <td><?php if($value->status==1){ echo "<p class='btn btn-success'> <i class='fa fa-check'></i></p>"; } else{ echo "<p class='btn btn-danger'> <i class='fa fa-times'></i></p>"; } ?></td>
                                                    <td><?php echo date("d-m-Y H:m A",strtotime($value->timestamp));?></td>
                                                  
                                                <?php
                                                }
                                                ?>
                                            <?php    
                                            }
                                            else
                                            {
                                                echo "<tr><td colspan='5'>No Data found</td></tr>";
                                            }
                                            ?>
                                        </tbody>
                                    </table>
                                    <h4>Legends</h4>
                                    Used: <p class='btn btn-success'> <i class='fa fa-check'></i></p>
                                    Un-used: <p class='btn btn-danger'> <i class='fa fa-times'></i></p>
                                    Download: <a class='btn btn-success'><i class='fa fa-download'></i></a>
                                    Upload:  <a class='btn btn-warning'><i class='fa fa-upload'></i></a>
                                </div>
                            </div>
                            <!-- END EXAMPLE TABLE PORTLET-->
</div>