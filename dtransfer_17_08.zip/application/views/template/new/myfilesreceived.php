<div class="page-content">
                    <!-- BEGIN PAGE HEAD-->
                    <div class="page-head">
                        <!-- BEGIN PAGE TITLE -->
                        <div class="page-title">
                           
                        </div>
                        <!-- END PAGE TITLE -->
                    </div>

               <!-- BEGIN EXAMPLE TABLE PORTLET-->
                            <div class="portlet box green">
                                <div class="portlet-title">
                                    <div class="caption">
                                        <i class="fa fa-globe"></i>Inbox </div>
                                    <div class="tools"> </div>
                                </div>
                                <div class="portlet-body">
                                    <table class="table table-striped table-bordered table-hover owndatatable" id="sample_2">
                                        <thead>
                                            <th class="col-md-2">Sr. No.</th>
                                            <th class="col-md-2">Received From</th>
                                            <th class="col-md-2">Description</th>
                                            <th class="col-md-2">Validity</th>
                                            <th class="col-md-2">Time</th>
                                            <th class="col-md-2">Download</th>                                            
                                            <th>Actions</th>
                                        </thead>
                                        <tbody>
                                            <?php
                                                $i=1;
                                                //var_dump($myfiles);
                                                if($myfiles!=NULL)
                                                {
                                                    foreach ($myfiles as $key => $value) {
                                                        # code...
                                                    ?>
                                                    <tr>
                                                        <td><?php echo $i++;?></td>
                                                        <td><?php 
                                                        foreach ($value->staff as $key2 => $value2) {
                                                            echo $value2['email']."<br>";
                                                            # code...
                                                        }
                                                        ?>
                                                        </td>
                                                        <td><?php echo $value->description;?></td>
                                                        <td><?php echo $value->validity;?></td>
                                                        <td><?php echo date("d-m-Y H:s A",strtotime($value->timestamp));?></td>
                                                        
                                                        <td>
                                                            <a href="#" class="viewfilesdetails btn btn-success" data-id="<?php echo $value->files_id;?>">View Files</a>
                                                            
                                                            <!-- MODEL FOR VIEW -->

                                                            <div class="modal fade" id="files_<?php echo $value->files_id;?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
                                                              <div class="modal-dialog" role="document">
                                                                <div class="modal-content">
                                                                  <div class="modal-header">
                                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                                                    <h4 class="modal-title" id="exampleModalLabel">Files Details</h4>
                                                                  </div>
                                                                  <div class="modal-body">
                                                                            <table>   
                                                                                <tr>
                                                                                    <table class="table">
                                                                                    <th width="20%">Sr. No.</th>
                                                                                    <th width="60%">Name</th>
                                                                                    <th width="20%">Size</th>
                                                                                    <th width="20%">Download</th>
                                                                                </tr>                    
                                                                                <?php
                                                                                $j=1;
                                                                                 $file=explode(',', $value->filesarray->filename);
                                                                                 foreach ($file as $key => $value2) {
                                                                                    ?>
                                                                                    <tr>
                                                                                        <td><?php echo $j++;?></td>                               
                                                                                        <td><?php echo trim($value2);?> </td>
                                                                                        <td><?php echo file_size($value2);?></td>
                                                                                        <td>
                                                                                           
                                                                                                <!-- <a class="btn btn-success" href="<?php echo base_url();?>files/download/<?php echo $user->user_id;?>?filename=<?php echo trim($value2);?>" >Download Now -->
                                                                                                <a class="btn btn-success" href="<?php echo base_url();?>files/accessfiles/<?php echo $user->user_id;?>/<?php echo base64_encode($value->session_id);?>/<?php echo trim($value2);?>" >Download Now
                                                                                               
                                                                                                </td>

                                                                                               

                                                                                    </tr>
                                                                                    <?php
                                                                                 }
                                                                                 ?>
                                                                                 </table>
                                                                  </div>
                                                                  <div class="modal-footer">
                                                                  </div>
                                                                </div>
                                                              </div>
                                                            </div>
                                                        </td>
                                                        <td><a class="btn btn-success" href="<?php echo base_url();?>files/delete/<?php echo  $value->files_id;?>/myfilesreceived" ><i class="fa fa-trash"></i> Delete</td>

                                                    </tr>
                                                    <?php
                                                    }
                                                    ?>
                                                <?php    
                                                }
                                                else
                                                {
                                                    echo "<tr><td colspan='7'>No Data found</td></tr>";
                                                }
                                                ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <!-- END EXAMPLE TABLE PORTLET-->
</div>