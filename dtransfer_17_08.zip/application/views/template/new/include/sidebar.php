
            <!-- BEGIN SIDEBAR -->  <?php
                    if($user->name==""){ echo "<p class='alert alert-danger'>Your profile is not completed. Complete profile first.</p>" ;}
                    ?>
            <div class="page-sidebar-wrapper">
                <!-- BEGIN SIDEBAR -->
                <!-- DOC: Set data-auto-scroll="false" to disable the sidebar from auto scrolling/focusing -->
                <!-- DOC: Change data-auto-speed="200" to adjust the sub menu slide up/down speed -->
                <div class="page-sidebar navbar-collapse collapse">
                    <!-- BEGIN SIDEBAR MENU -->
                    <!-- DOC: Apply "page-sidebar-menu-light" class right after "page-sidebar-menu" to enable light sidebar menu style(without borders) -->
                    <!-- DOC: Apply "page-sidebar-menu-hover-submenu" class right after "page-sidebar-menu" to enable hoverable(hover vs accordion) sub menu mode -->
                    <!-- DOC: Apply "page-sidebar-menu-closed" class right after "page-sidebar-menu" to collapse("page-sidebar-closed" class must be applied to the body element) the sidebar sub menu mode -->
                    <!-- DOC: Set data-auto-scroll="false" to disable the sidebar from auto scrolling/focusing -->
                    <!-- DOC: Set data-keep-expand="true" to keep the submenues expanded -->
                    <!-- DOC: Set data-auto-speed="200" to adjust the sub menu slide up/down speed -->
                    <ul class="page-sidebar-menu   " data-keep-expanded="false" data-auto-scroll="true" data-slide-speed="200">
                        <li class="nav-item start  <?php if($this->router->fetch_method()=="dashboard"){ echo ' active open'; } ?>">
                            <a href="<?php echo base_url();?>user/dashboard" class="nav-link nav-toggle">
                                <i class="fa fa-dashboard"></i>
                                <span class="title">Dashboard</span>
                               
                            </a>
                            
                        </li>
                        <li class="nav-item  <?php if($this->router->fetch_method()=="upload"){ echo ' active open'; } ?>">
                            <a href="<?php echo base_url();?>user/upload" class="nav-link nav-toggle" target="_blank">
                                <i class="fa fa-send"></i>
                                <span class="title">Compose</span>                               
                            </a>                            
                        </li>
                         <li class="nav-item  <?php if($this->router->fetch_method()=="myfilesreceived"){ echo ' active open'; } ?>">
                            <a href="<?php echo base_url();?>user/myfilesreceived" class="nav-link nav-toggle">
                                <i class="icon-envelope"></i>
                                <span class="title">Inbox</span>                               
                            </a>                            
                        </li>
                        <li class="nav-item  <?php if($this->router->fetch_method()=="myfilessent"){ echo ' active open'; } ?>">
                            <a href="<?php echo base_url();?>user/myfilessent" class="nav-link nav-toggle">
                                <i class="icon-share"></i>
                                <span class="title">Sent Items</span>                               
                            </a>                            
                        </li>
                         <li class="nav-item  <?php if($this->router->fetch_method()=="profile"){ echo ' active open'; } ?>">
                            <a href="<?php echo base_url();?>user/profile" class="nav-link nav-toggle">
                                <i class="icon-user"></i>
                                <span class="title">Profile</span>                               
                            </a>                            
                        </li>
                        <?php 
                        if( $logged_in_user->type==3)     
                        {
                        ?>
                        <li class="nav-item">
                            <a class="nav-link nav-toggle" href="javascript:;">
                                <i class="icon-users"></i>
                                <span class="title">Users</span>
                                <span class="arrow"></span>
                            </a>
                            <ul class="sub-menu" style="display: none;">
                                <li class="nav-item  ">
                                    <a class="nav-link " href="<?php echo base_url();?>user/allusers">
                                        <span class="title">All Users</span>
                                    </a>
                                </li>
                                <li class="nav-item  ">
                                    <a class="nav-link " href="<?php echo base_url();?>user/addstaff">
                                        <span class="title">Add User/Admin</span>
                                    </a>
                                </li>
                                
                            </ul>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link nav-toggle" href="javascript:;">
                                <i class="icon-settings"></i>
                                <span class="title">Configuration</span>
                                <span class="arrow"></span>
                            </a>
                            <ul class="sub-menu" style="display: none;">
                                <li class="nav-item  ">
                                    <a class="nav-link " href="<?php echo base_url();?>user/configuration">
                                        <span class="title">Configuration</span>
                                    </a>
                                </li>
                                <li class="nav-item  ">
                                    <a class="nav-link " href="<?php echo base_url();?>user/smtpsettings">
                                        <span class="title">SMTP Settings</span>
                                    </a>
                                </li>
                                
                            </ul>
                        </li>
                        <!--
                        <li class="nav-item">
                            <a class="nav-link nav-toggle" href="javascript:;">
                                <i class="icon-settings"></i>
                                <span class="title">Package</span>
                                <span class="arrow"></span>
                            </a>
                            <ul class="sub-menu" style="display: none;">
                                <li class="nav-item">
                                    <a class="nav-link " href="<?php echo base_url();?>packages/add">
                                        <span class="title">Add New</span>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link " href="<?php echo base_url();?>packages/all">
                                        <span class="title">All Packages</span>
                                    </a>
                                </li>
                                  <li class="nav-item">
                                    <a class="nav-link " href="<?php echo base_url();?>packages/requestall/0">
                                        <span class="title">Pending Package Request</span>
                                    </a>
                                </li>
                                 <li class="nav-item">
                                    <a class="nav-link " href="<?php echo base_url();?>packages/requestall/1">
                                        <span class="title">Accepted Package Request</span>
                                    </a>
                                </li> -->
                                 <!-- <li class="nav-item">
                                    <a class="nav-link " href="<?php echo base_url();?>packages/requestall/2">
                                        <span class="title">Cancelled Package Request</span>
                                    </a>
                                </li> 

                            </ul>
                        </li>
                        -->
                        <li class="nav-item">
                            <a class="nav-link nav-toggle" href="javascript:;">
                                <i class="fa fa-files-o"></i>
                                <span class="title">Logs</span>
                                <span class="arrow"></span>
                            </a>
                            <ul class="sub-menu" style="display: none;">
                                <li class="nav-item">
                                    <a class="nav-link " href="<?php echo base_url();?>logs/otp">
                                        <span class="title">OTP Transactions</span>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link " href="<?php echo base_url();?>logs/download">
                                        <span class="title">Download Usage</span>
                                    </a>
                                </li>

                            </ul>
                        </li>
                        <li class="nav-item  ">
                            <a href="<?php echo base_url();?>files/autoclean" class="nav-link nav-toggle">
                                <i class="fa fa-magic"></i>
                                <span class="title">Autoclean</span>                               
                            </a>                            
                        </li>
                        <?php
                        }
                        ?>
                         <li class="nav-item  ">
                            <a href="<?php echo base_url();?>user/support" class="nav-link nav-toggle">
                                <i class="fa fa-ticket"></i>
                                <span class="title">Support</span>                               
                            </a>                            
                        </li>
                        <li class="nav-item  ">
                            <a href="<?php echo base_url();?>user/Logout" class="nav-link nav-toggle">
                                <i class="fa fa-sign-out"></i>
                                <span class="title">Logout</span>                               
                            </a>                            
                        </li>
                        
                    </ul>
                    <!-- END SIDEBAR MENU -->
                </div>
                <!-- END SIDEBAR -->
            </div>
            <!-- END SIDEBAR -->
            <div class="page-content-wrapper">
           