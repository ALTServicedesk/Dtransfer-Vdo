 </div>
        <!-- END CONTAINER -->
 <!-- BEGIN FOOTER -->
        <div class="page-footer">
            <div class="page-footer-inner"> <?php echo date("Y");?> &copy; <?php echo $site_settings->title;?>
            <div style="text-align:left">
            Powered by <a href="#">Munchers Media Pvt. Ltd.</a>
               </div>
            </div>
            <div class="scroll-to-top">
                <i class="icon-arrow-up"></i>
            </div>
        </div>
        <!-- END FOOTER -->
<div class="modal fade" id="requestupgrade" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="exampleModalLabel">Package Update request</h4>
      </div>
      <div class="modal-body">
        <form action="<?php echo base_url();?>packages/request" method="post">
          <div class="form-group">
            <label for="recipient-name" class="control-label">Package Name:</label>
            <input type="text" class="form-control"  id="packagename" readonly="">
            <input type="hidden" class="form-control" name="packageid" id="packageid" readonly="">
            <input type="hidden" class="form-control" name="userid" id="userid" value="<?php echo $user->user_id;?>" readonly="">
          </div>
          <div class="form-group">
            <label for="message-text" class="control-label">Addition Requirements:</label>
            <textarea class="form-control" name="message"></textarea>
          </div>
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Request</button>
      </form>
        
      </div>
      <div class="modal-footer">
      </div>
    </div>
  </div>
</div>

<div id="dialog-confirm" hidden title="Empty the recycle bin?">
  <p>
    <span class="ui-icon ui-icon-alert" style="float:left; margin:0 7px 20px 0;"></span>
    These items will be permanently deleted and cannot be recovered. Are you sure?
  </p>
</div>
        <!--[if lt IE 9]>
<script src="../assets/global/plugins/respond.min.js"></script>
<script src="../assets/global/plugins/excanvas.min.js"></script> 
<![endif]-->
        <!-- BEGIN CORE PLUGINS -->
        <script type="text/javascript">
        var base_url="<?php echo base_url();?>";
        </script>
        <script src="<?php echo base_url();?>assetsnew/global/plugins/jquery.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assetsnew/global/plugins/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assetsnew/global/plugins/js.cookie.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assetsnew/global/plugins/bootstrap-hover-dropdown/bootstrap-hover-dropdown.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assetsnew/global/plugins/jquery-slimscroll/jquery.slimscroll.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assetsnew/global/plugins/jquery.blockui.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assetsnew/global/plugins/uniform/jquery.uniform.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assetsnew/global/plugins/bootstrap-switch/js/bootstrap-switch.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assetsnew/jquery.media.js" type="text/javascript"></script>
        <!-- END CORE PLUGINS -->
        <!-- BEGIN PAGE LEVEL PLUGINS -->
       <!-- END PAGE LEVEL PLUGINS -->
        <!-- BEGIN THEME GLOBAL SCRIPTS -->
        <script src="<?php echo base_url();?>assetsnew/jquery-ui.min.js"></script>

        <link rel="stylesheet" href="<?php echo base_url();?>assetsnew/jquery-ui.theme.min.css" />

        <script src="<?php echo base_url();?>assetsnew/global/scripts/app.min.js" type="text/javascript"></script>
       <!-- <script src="<?php echo base_url();?>assetsnew/pages/scripts/dashboard.min.js" type="text/javascript"></script>
         END THEME GLOBAL SCRIPTS -->
        <script src="<?php echo base_url();?>assetsnew/pages/scripts/table-datatables-buttons.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assetsnew/pages/scripts/profile.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assetsnew/global/plugins/bootstrap-fileinput/bootstrap-fileinput.js" type="text/javascript"></script>

        <!-- BEGIN THEME LAYOUT SCRIPTS -->
        <script src="<?php echo base_url();?>assetsnew/layouts/layout4/scripts/layout.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assetsnew/layouts/layout4/scripts/demo.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assetsnew/layouts/global/scripts/quick-sidebar.min.js" type="text/javascript"></script>
        <!-- END THEME LAYOUT SCRIPTS -->
        <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assetsnew/datatables.min.css"/>
 
<script type="text/javascript" src="<?php echo base_url();?>assetsnew/datatables.min.js"></script>

<script type="text/javascript">
  function isValidEmailAddress(emailAddress) {
    var pattern = /^([a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+(\.[a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+)*|"((([ \t]*\r\n)?[ \t]+)?([\x01-\x08\x0b\x0c\x0e-\x1f\x7f\x21\x23-\x5b\x5d-\x7e\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|\\[\x01-\x09\x0b\x0c\x0d-\x7f\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))*(([ \t]*\r\n)?[ \t]+)?")@(([a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.)+([a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.?$/i;
    return pattern.test(emailAddress);
};

</script>

        <script type="text/javascript">
        $('.owndatatable').DataTable( {
             dom: 'Bfrtip',
                buttons: [
                    'copy', 'excel', 'pdf','csv','print'
                ]
        } );
        </script>
    <script type="text/javascript">
  $(document).ready(function (){

    var loader="processing";
    $("body").on('click','#change_password',function(e){
        e.preventDefault();
        $("#password_result").html(loader);
        var oldpass=$("#oldpass").val();
        var newpassword=$("#newpassword").val();
        var repeatpassword=$("#repeatpassword").val();
        var user_id=$("#user_id").val();
        if(oldpass==""){ 
            $("#password_result").html("<p class='alert alert-danger'> Old Password is required</p>"); 
        }
        else{
            if(newpassword==""){ 
                $("#password_result").html("<p class='alert alert-danger'> Password is required</p>"); 
            }
            else if(repeatpassword==""){ 
                $("#password_result").html("<p class='alert alert-danger'> Confirm Password is required</p>"); 
            }
            else{

                    if(newpassword!=repeatpassword)
                    {
                        $("#password_result").html("<p class='alert alert-danger'> New paswords not matached.</p>");
                    }
                    else
                    {
                        $.ajax({
                            url: "<?php echo base_url();?>user/changepass",
                            method: "post",
                            data: {oldpass:oldpass,newpassword:newpassword,repeatpassword:repeatpassword} ,
                            success: function(result){
                                $("#password_result").html(result);
                            }
                        });
                    }

            }
            
        }

    });

 $( document ).on( 'focus', ':input', function(){
        $( this ).attr( 'autocomplete', 'off' );
    });
 

$("body").on('click','.confirmonce',function(e){
 
        e.preventDefault();
        var data = $(this).data('userid');
 $( "#dialog-confirm" ).dialog({
      resizable: false,
      height:140,
      modal: true,
      buttons: {
        "Delete": function() {
          $( this ).dialog( "close" );
          window.location.href=base_url+"/user/delete/"+data;
         return true;
        },
        Cancel: function() {
          $( this ).dialog( "close" );
        }
      },
       create:function () {
        $(this).closest(".ui-dialog").find(".ui-button").addClass("btn btn-danger");
      }
    });

 });

  $("#emailchangeinput").focusout(function (e){
    //e.preventDefault();
    if($(".multiple-val-input ul li").length == 0){
      alert("Please add atleast one email..");
      setTimeout(function(){
            $("#emailchangeinput").focus();
        }, 1);
    }
  });

$(".changerequest").click(function (e){
      e.preventDefault();
      var packageid= $(this).data("packageid");
      var type= $(this).data("type");
      $.ajax({
            url: "<?php echo base_url();?>packages/requestupdate",
            method: "post",
            data: {packageid:packageid,type:type} ,
            success: function(result){
              window.location="";
            }
        });
    });
    
    

     $('.download_change').change(function() {
      var sThisVal="";
      var aurl="";
         var sThisVal = $('input:checkbox:checked').map(function() {
              aurl=aurl+","+this.value;
              return "<li>"+this.value+"</li>";
          }).get();
          $("#selected>span").html(sThisVal);
          $("#downloadlink").attr("href","<?php echo base_url();?>files/downloadmultiple?filename="+aurl);
          
     });

     $(".requestupgradebtn").click(function (){
      $('#requestupgrade').modal("show");
      $("#packagename").val($(this).data("name"));
      $("#packageid").val($(this).data("id"));
    });

      $(".viewfilesdetails").click(function (){
      var files_id=$(this).data("id");
      $('#files_'+files_id).modal("show");
    });

   


      $('.uploadfileclass').on('click', function(e){
            var staff = $("#staff").val();
            if(staff==""){
              alert("Enter Email address to send files");
              e.preventDefault();
            }
        });

      $('.multiple-val-input').on('click', function(){
            $(this).find('input:text').focus();
        });
        $('.multiple-val-input ul input:text').on('input propertychange', function(){
            $(this).siblings('span.input_hidden').text($(this).val());
            var inputWidth = $(this).siblings('span.input_hidden').width();
            //$(this).width(inputWidth);
        });
        $('.multiple-val-input ul input:text').on('keypress focusout', function(event){
            if(event.which == 32 || event.which == 44 || event.which == 13){

                var toAppend = $(this).val();
                if(isValidEmailAddress(toAppend))
                {
                  if(toAppend!=''){
                      $('<li><a href="#">×</a><div>'+toAppend+'</div></li>').insertBefore($(this));
                      $(this).val('');
                      $("#staff").val($("#staff").val()+","+toAppend);
                  } else {
                      return false;
                  }                  
                }
                else{
                         alert("Not vailid email");
                         }
                return false;
            };
        });
        $(document).on('click','.multiple-val-input ul li a', function(e){
            e.preventDefault();
            $(this).parents('li').remove();
        });


  })
  </script>
  <script src="<?php echo base_url();?>fileuploader/js/vendor/jquery.ui.widget.js"></script>
<!-- The Templates plugin is included to render the upload/download listings -->
<script src="http://blueimp.github.io/JavaScript-Templates/js/tmpl.min.js"></script>
<!-- The Load Image plugin is included for the preview images and image resizing functionality -->
<script src="http://blueimp.github.io/JavaScript-Load-Image/js/load-image.all.min.js"></script>
<!-- The Canvas to Blob plugin is included for image resizing functionality -->
<script src="http://blueimp.github.io/JavaScript-Canvas-to-Blob/js/canvas-to-blob.min.js"></script>
<!-- Bootstrap JS is not required, but included for the responsive demo navigation -->
<script src="http://netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
<!-- blueimp Gallery script -->
<script src="http://blueimp.github.io/Gallery/js/jquery.blueimp-gallery.min.js"></script>
<!-- The Iframe Transport is required for browsers without support for XHR file uploads -->
<script src="<?php echo base_url();?>fileuploader/js/jquery.iframe-transport.js"></script>
<!-- The basic File Upload plugin -->
<script src="<?php echo base_url();?>fileuploader/js/jquery.fileupload.js"></script>
<!-- The File Upload processing plugin -->
<script src="<?php echo base_url();?>fileuploader/js/jquery.fileupload-process.js"></script>
<!-- The File Upload image preview & resize plugin -->
<script src="<?php echo base_url();?>fileuploader/js/jquery.fileupload-image.js"></script>
<!-- The File Upload audio preview plugin -->
<script src="<?php echo base_url();?>fileuploader/js/jquery.fileupload-audio.js"></script>
<!-- The File Upload video preview plugin -->
<script src="<?php echo base_url();?>fileuploader/js/jquery.fileupload-video.js"></script>
<!-- The File Upload validation plugin -->
<script src="<?php echo base_url();?>fileuploader/js/jquery.fileupload-validate.js"></script>
<!-- The File Upload user interface plugin -->
<script src="<?php echo base_url();?>fileuploader/js/jquery.fileupload-ui.js"></script>
<!-- The main application script -->
<script src="<?php echo base_url();?>fileuploader/js/main.js"></script>
     

</body></html>
