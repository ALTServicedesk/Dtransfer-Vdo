<div class="page-content">
                    <!-- BEGIN PAGE HEAD-->
                    
<div class="col-md-12 ">
                            <!-- BEGIN SAMPLE FORM PORTLET-->
                            <div class="portlet box green">
                                <div class="portlet-title">
                                    <div class="caption">
                                        <i class="fa fa-user"></i>Add User</div>
                                    <div class="tools"> </div>
                                </div>
                                <div class="portlet-body form">
                                        <div class="form-body">
                                        <?php if(isset($message)) { echo $message; } ?>

                                          <form action="<?php echo base_url();?>user/addstaff" method="post">
            
                                            <div class="form-group form-md-line-input form-md-floating-label">
                                                <input type="text" name="name" id="form_control_1" autocomplete="off" class="form-control">
                                                <label for="form_control_1">First Name</label>
                                                <?php echo form_error('name');?>
                                            </div>

                                            <div class="form-group form-md-line-input form-md-floating-label">
                                                <input type="text" name="lname" id="form_control_1" autocomplete="off" class="form-control">
                                                <label for="form_control_1">Last Name</label>
                                                <?php echo form_error('lname');?>
                                            </div>

                                            <div class="form-group form-md-line-input form-md-floating-label">
                                                <input type="text" name="phone" id="form_control_1" autocomplete="off" class="form-control">
                                                <label for="form_control_1">Phone</label>
                                                <?php echo form_error('phone');?>
                                            </div>

                                            <div class="form-group form-md-line-input form-md-floating-label">
                                                <input type="text" name="email" id="form_control_1" autocomplete="off" class="form-control">
                                                <label for="form_control_1">Email</label>
                                                <?php echo form_error('email');?>
                                            </div>

                                            <div class="form-group form-md-line-input form-md-floating-label">
                                                <input type="password" name="password" id="form_control_1" autocomplete="off" class="form-control">
                                                <label for="form_control_1">Password</label>
                                                <?php echo form_error('password');?>
                                            </div>

                                            <div class="form-group form-md-line-input form-md-floating-label">
                                                <input type="password" name="confirmpassword" id="form_control_1" autocomplete="off" class="form-control">
                                                <label for="form_control_1">Confirm Password</label>
                                                <?php echo form_error('confirmpassword');?>
                                            
                                            </div>

                                            <div class="form-group form-md-line-input form-md-floating-label">
                                                <select id="form_control_1" name="usertype" class="form-control">
                                                    <option value="2">Internal User</option>
                                                    <option value="3">Admin</option>
                                                </select>                                               
                                            
                                            </div>

                                        <div class="form-actions noborder">
                                            <button class="btn blue" type="submit">Submit</button>
                                            
                                        </div>
                                    </form>
                                </div>
                            </div>
                            <!-- END SAMPLE FORM PORTLET-->
                            <!-- BEGIN SAMPLE FORM PORTLET-->
                            
                        </div> 

</div>