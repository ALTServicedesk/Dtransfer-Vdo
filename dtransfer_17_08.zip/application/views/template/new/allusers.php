<div class="page-content">
                    <!-- BEGIN PAGE HEAD-->
                   

               <!-- BEGIN EXAMPLE TABLE PORTLET-->
                            <div class="portlet box green">
                                <div class="portlet-title">
                                    <div class="caption">
                                        <i class="fa fa-users"></i>All Users </div>
                                    <div class="tools"> </div>
                                </div>
                                <div class="portlet-body">
                                    <table class="table table-striped table-bordered table-hover owndatatable" id="sample_2">
                                        <thead>
                                            <th>Sr. No.</th>
                                            <th>Full Name</th>
                                            <th>Phone</th>
                                            <th>Email</th>
                                            <th>Date</th>
                                            <th>Type</th>
                                            <th>Actions</th>
                                        </thead>
                                        <tbody>
                                           <?php
                                            $i=1;
                                            if($users!=NULL)
                                            {
                                                foreach ($users as $key => $value) {
                                                    # code...
                                                ?>
                                                <tr <?php if($value->status=="3") { echo "style='color:red;'"; }?>>
                                                    <td><?php echo $i++;?></td>
                                                    <td><?php echo $value->name;?> <?php echo $value->lname;?></td>
                                                    <td><?php if($value->phone!=0) { echo $value->phone;} else { echo "N/A"; } ?></td>
                                                    <td><?php echo $value->email;?></td>
                                                    <td><?php echo date("d-m-Y H:m A",strtotime($value->timestamp));?></td>
                                                    <td><a class="btn btn-info"><?php if($value->type==1) { echo "External User";} else { echo "Internal User"; } ?></a></td>
                                                    <td>
                                                        <?php if($value->status=="3") { ?>
                                                        <a href="<?php echo base_url();?>user/changestatus/<?php echo $value->user_id;?>/1" class="btn btn-success"><i class="fa fa-check"></i> Mark Active</a>
                                                        <?php
                                                        }
                                                        else{
                                                            ?>
                                                        <a href="<?php echo base_url();?>user/changestatus/<?php echo $value->user_id;?>/3" class="btn btn-info"><i class="fa fa-times"></i> Mark Inactive</a>

                                                            <?php
                                                        }
                                                        ?>
                                                        <a href="<?php echo base_url();?>user/delete/<?php echo $value->user_id;?>" data-userid="<?php echo $value->user_id;?>" class="btn btn-danger" onclick="return confirm('You will not be able to revert the this. Are you sure ? ');"><i class="fa fa-times"></i> Delete User</a>

                                                    </td>

                                                    
                                                    </tr>
                                                <?php
                                                }
                                                ?>
                                            <?php    
                                            }
                                            else
                                            {
                                                echo "<tr><td colspan='7'>No Data found</td></tr>";
                                            }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <!-- END EXAMPLE TABLE PORTLET-->
</div>