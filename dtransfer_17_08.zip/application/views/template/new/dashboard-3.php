<div class="page-content">
                    <!-- BEGIN PAGE HEAD-->
                    <div class="page-head">
                        <!-- BEGIN PAGE TITLE -->
                        <div class="page-title">
                            <h1>Dasboard
                                <small>all information gathered here</small>
                            </h1>
                        </div>
                        <!-- END PAGE TITLE -->
                    </div>
                    <!-- END PAGE HEAD-->
                    <!-- BEGIN PAGE BREADCRUMB -->
                    
                    <!-- END PAGE BREADCRUMB -->
                    <!-- BEGIN PAGE BASE CONTENT -->
                    <div class="note note-info">
                        <p> View your account summary and your activity.</p>
                    </div>
                    <!-- END PAGE BASE CONTENT -->
                    <?php
                    $total=disk_total_space("/");
                    $totalfree=disk_free_space("/");
                    $per=round($totalfree/$total*100);
                    ?>
                    <div class="row">
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                            <div class="dashboard-stat2 bordered">
                                <div class="display">
                                    <div class="number">
                                        <h3 class="font-red-haze">
                                            <span data-value="1349" data-counter="counterup">Disk Space </span>
                                        </h3>
                                        <small>Your Account Expires on <?php echo date("F, d Y",strtotime($logged_in_user->package_validity));?></small>
                                    </div>
                                    <div class="icon">
                                        <i class="fa fa-cubes"></i>
                                    </div>
                                </div>
                                <div class="progress-info">
                                    <div class="progress">
                                        <span class="progress-bar progress-bar-success red-haze" style="width: <?php echo 100-$per;?>%;">
                                            <span class="sr-only"><?php echo 100-$per;?>% change</span>
                                        </span>
                                    </div>
                                    <div class="status">
                                        <div class="status-title">Free Space: <?php echo formatBytes($totalfree);?></div>
                                        <div class="status-number">  Total Space: <?php echo formatBytes($total);?></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                            <div class="col-md-6">
                                <div class="widget-thumb widget-bg-color-white text-uppercase margin-bottom-20 bordered">
                                    <h4 class="widget-thumb-heading">Download</h4>
                                    <div class="widget-thumb-wrap">
                                        <div class="widget-thumb-body">
                                            <span data-value="815" data-counter="counterup" class="widget-thumb-body-stat"><?php echo formatBytes($summarydownload);?></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                 <div class="widget-thumb widget-bg-color-white text-uppercase margin-bottom-20 bordered">
                                    <h4 class="widget-thumb-heading">Upload</h4>
                                    <div class="widget-thumb-wrap">
                                        <div class="widget-thumb-body">
                                            <span data-value="815" data-counter="counterup" class="widget-thumb-body-stat"><?php echo formatBytes($summaryupload['size']);?></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>