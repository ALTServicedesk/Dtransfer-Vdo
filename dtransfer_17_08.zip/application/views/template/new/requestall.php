<div class="page-content">

               <!-- BEGIN EXAMPLE TABLE PORTLET-->
                            <div class="portlet box green">
                                <div class="portlet-title">
                                    <div class="caption">
                                        <i class="fa fa-globe"></i>Packages Requests </div>
                                    <div class="tools"> </div>
                                </div>
                                <div class="portlet-body">
                                    <table class="table table-striped table-bordered table-hover owndatatable" id="sample_2">
                                        <thead>
                                            <td>S No</td>
                                            <td>Name</td>
                                            <td>Email</td>
                                            <td>Package Name</td>
                                            <td>Additional Requirements</td>
                                            <td>Timestamp</td>
                                            <td>Actions</td>
                                        </thead>
                                        <tbody>
                                           <?php
                                            $i=1;
                                            if($request!=NULL)
                                            {

                                                foreach ($request as $key => $value) {
                                                    
                                                ?>
                                                    <tr>
                                                        <td><?php echo $i++;?></td>
                                                        <td><?php echo $value->name;?></td>
                                                        <td><?php echo $value->email;?></td>
                                                        <td><?php echo $value->packagename;?></td>
                                                        <td><?php echo $value->message;?></td>
                                                        <td><?php echo date("d-m-Y H:s A",strtotime($value->timestamp));?></td>
                                                        <td><a class="btn btn-success changerequest" href="#" data-type="1" data-packageid="<?php echo $value->package_request_id;?>">Approve</a>
                                                       <!--  <a class="btn btn-danger changerequest" href="#" data-type="2" data-packageid="<?php echo $value->package_request_id;?>">Cancel</a></td> -->
                                                    </tr>
                                                <?php
                                                }

                                            }
                                            else{
                                                echo "<tr><td colspan='7'>No data yet.</tr>";
                                            }

                                                ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <!-- END EXAMPLE TABLE PORTLET-->
</div>