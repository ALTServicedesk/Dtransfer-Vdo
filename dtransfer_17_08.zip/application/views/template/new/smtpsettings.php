<div class="page-content">
                    <!-- BEGIN PAGE HEAD-->
                    
<div class="col-md-12 ">
                            <!-- BEGIN SAMPLE FORM PORTLET-->
                            <div class="portlet box green">
                                <div class="portlet-title">
                                    <div class="caption">
                                        <i class="fa fa-gear"></i>SMTP Settings</div>
                                    <div class="tools"> </div>
                                </div>
                                <div class="portlet-body form">
                                        <div class="form-body">
                                        <?php if(isset($message)) { echo $message; } ?>

                                          <form action="<?php echo base_url();?>user/smtpsettings" method="POST">
                                            <div class="form-group form-md-line-input form-md-floating-label">
                                                <input type="text" name="smtphost" value="<?php echo $settings->smtphost;?>" required id="form_control_1" autocomplete="off" class="form-control">
                                                <label for="form_control_1">SMTP Host</label>
                                                <?php echo form_error("smtphost");?>
                                            </div>

                                            <div class="form-group form-md-line-input form-md-floating-label">
                                                <input type="text" name="smtpport" value="<?php echo $settings->smtpport;?>" required id="form_control_1" autocomplete="off" class="form-control">
                                                <label for="form_control_1">SMTP Port</label>
                                                <?php echo form_error("smtpport");?>
                                            </div>

                                            <div class="form-group form-md-line-input form-md-floating-label">
                                                <input type="text" name="smtpuser" value="<?php echo $settings->smtpuser;?>" required id="form_control_1" autocomplete="off" class="form-control">
                                                <label for="form_control_1">SMTP User</label>
                                                <?php echo form_error("smtpuser");?>
                                            </div>

                                            <div class="form-group form-md-line-input form-md-floating-label">
                                                <input type="password" name="smtppass" value="<?php echo $settings->smtppass;?>" required id="form_control_1" autocomplete="off" class="form-control">
                                                <label for="form_control_1">SMTP Pass</label>
                                                <?php echo form_error("smtppass");?>
                                            </div>

                                           
                                        <div class="form-actions noborder">
                                            <button class="btn blue" type="submit">Update</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                            <!-- END SAMPLE FORM PORTLET-->
                            <!-- BEGIN SAMPLE FORM PORTLET-->
                            
                        </div> 

</div>