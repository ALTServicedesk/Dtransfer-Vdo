<div class="page-content">
                    <!-- BEGIN PAGE HEAD-->
                    
<div class="col-md-12 ">
                            <!-- BEGIN SAMPLE FORM PORTLET-->
                            <div class="portlet box green">
                                <div class="portlet-title">
                                    <div class="caption">
                                        <i class="fa fa-gear"></i>Configuration</div>
                                    <div class="tools"> </div>
                                </div>
                                <div class="portlet-body form">
                                        <div class="form-body">
                                        <?php if(isset($message)) { echo $message; } ?>

                                          <form action="<?php echo base_url();?>user/configuration" method="POST">
                                            <div class="form-group form-md-line-input form-md-floating-label">
                                                <input type="text" name="title" value="<?php echo $settings->title;?>" required id="form_control_1" autocomplete="off" class="form-control">
                                                <label for="form_control_1">Title</label>
                                                <?php echo form_error("title");?>
                                            </div>

                                            <div class="form-group form-md-line-input form-md-floating-label">
                                                <input type="text" name="email" value="<?php echo $settings->email;?>" required id="form_control_1" autocomplete="off" class="form-control">
                                                <label for="form_control_1">Email</label>
                                                <?php echo form_error("email");?>
                                            </div>

                                            <div class="form-group form-md-line-input form-md-floating-label">
                                                <input type="text" name="phone" value="<?php echo $settings->phone;?>" required id="form_control_1" autocomplete="off" class="form-control">
                                                <label for="form_control_1">Phone</label>
                                                <?php echo form_error("phone");?>
                                            </div>

                                            <div class="form-group form-md-line-input form-md-floating-label">
                                                <input type="text" name="address" value="<?php echo $settings->address;?>" required id="form_control_1" autocomplete="off" class="form-control">
                                                <label for="form_control_1">Address</label>
                                                <?php echo form_error("address");?>
                                            </div>

                                           
                                        <div class="form-actions noborder">
                                            <button class="btn blue" type="submit">Update</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                            <!-- END SAMPLE FORM PORTLET-->
                            <!-- BEGIN SAMPLE FORM PORTLET-->
                            
                        </div> 

</div>