
  
    <div class="content-wrapper">
    
    <div class="row">
      
      <ol class="breadcrumb m-b-0">      
      </ol>
      <div class="col-md-12">
      <h3>Packages Requests</h3>
        <div class="card">
        <table class="table table-striped table-hover table-sm datatable">
        	<thead>
        		<td>S No</td>
                <td>Name</td>
        		<td>Email</td>
        		<td>Package Name</td>
                <td>Additional Requirements</td>
        		<td>Timestamp</td>
                <td>Actions</td>
        	</thead>
        	<?php
        	$i=1;
            if($request!=NULL)
            {

        		foreach ($request as $key => $value) {
        			
        		?>
        			<tr>
                        <td><?php echo $i++;?></td>
                        <td><?php echo $value->name;?></td>
                        <td><?php echo $value->email;?></td>
                        <td><?php echo $value->packagename;?></td>
        				<td><?php echo $value->message;?></td>
                        <td><?php echo date("d-m-Y H:s A",strtotime($value->timestamp));?></td>
                        <td><a class="btn btn-success changerequest" href="" data-type="1" data-packageid="<?php echo $value->package_request_id;?>">Approve</a>
        				<a class="btn btn-danger changerequest" href="" data-type="2" data-packageid="<?php echo $value->package_request_id;?>">Cancel</a></td>
        			</tr>
        		<?php
        		}

            }
            else{
                echo "<tr><td colspan='7'>No data yet.</tr>";
            }

        		?>

        </table>
        </div>

      </div>
    </div>

  </div>