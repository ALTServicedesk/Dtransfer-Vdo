 
    <div class="row ">
        <div class="col-sm-10 col-sm-push-1 col-md-6 col-md-push-3 col-lg-6 col-lg-push-3">
            <div class="homelogo">
            <img src="<?php echo base_url();?>uploads/<?php echo $site_settings->logo;?>" class="img-circle">
            <h6 class="text-primary center m-a-2">
             <?php if(isset($messageverify)) { echo $messageverify; } ?>
            </h6>
            </div>
            <div class="card-group box-shadow-white">
                <div class="card bg-transparent">
                    <div class="card-block">
                        <div class="center">
                            <h4 class="m-b-0"><span class="icon-text"><i class="fa fa-sign-in "></i> Login</span></h4>
                            <p class="text-muted">Access your account</p>
                        </div>
                        <form action="<?php echo base_url();?>user/login" method="post">
                            <?php if(isset($messagelogin)) { echo $messagelogin; } ?>
                            <div class="form-group">
                                <input type="email" class="form-control" name="emaillogin" placeholder="Email Address" value="<?php echo set_value('emaillogin');?>">
                                <?php echo form_error('emaillogin');?>
                                
                            </div>
                            <div class="form-group">
                                <input type="password" class="form-control" name="passwordlogin" placeholder="Password">
                                <?php echo form_error('passwordlogin');?>
                                
                                <a href="#" class="pull-xs-right">
                                    <small>Forgot?</small>
                                </a>
                                <div class="clearfix"></div>
                            </div>
                            <div class="center">
                                <button type="submit" class="btn  btn-primary-outline btn-circle-large">
                                  <i class="material-icons">lock</i>
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="card bg-transparent">
                    <div class="card-block center">
                        <h4 class="m-b-0">
                          <span class="icon-text"><i class="fa fa-user-plus"></i> Sign Up</span>
                        </h4>
                        <p class="text-muted">Create a new account</p>
                        <?php if(isset($message)) { echo $message; } ?>
                        <form action="<?php echo base_url();?>user/register" method="post">
                            <div class="form-group">
                                <input type="text" class="form-control" name="name" placeholder="First Name" value="<?php echo set_value('name');?>">
                                <?php echo form_error('name');?>
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control" name="lname" placeholder="Last Name" value="<?php echo set_value('lname');?>">
                                <?php echo form_error('lname');?>
                            </div>
                             <div class="form-group">
                                <input type="text" class="form-control" name="phone" placeholder="Phone" value="<?php echo set_value('phone');?>">
                                <?php echo form_error('phone');?>
                            </div>
                            <div class="form-group">
                                <input type="email" class="form-control" name="email" placeholder="Email" value="<?php echo set_value('email');?>">
                                <?php echo form_error('email');?>
                            </div>
                            <div class="form-group">
                                <input type="password" class="form-control" name="password" placeholder="Password">
                                <?php echo form_error('password'); ?>
                            </div>
                            <div class="form-group">
                                <input type="password" class="form-control" name="confirmpassword" placeholder="Confirm Password">
                                <?php echo form_error('confirmpassword');?>
                            </div>
                            <button type="submit" class="btn  btn-primary-outline btn-circle-large">
                          <i class="fa fa-registered"></i></button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

