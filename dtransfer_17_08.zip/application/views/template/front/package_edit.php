
  
    <div class="content-wrapper">
   
    <div class="row">
    <h3>Edit Package</h3>
    	<div class="card">
    	<?php

    	?>
    		<div class="card-block">
    				<form action="<?php echo base_url();?>packages/edit/<?php echo $package->package_id;?>" method="POST">
    				<input type="hidden" name="package_id" value="<?php echo $package->package_id;?>">
             		 <div class="form-group row">
		                <label class="col-sm-3 form-control-label" for="inputEmail3">Package Name</label>
		                <div class="col-sm-9">
		                  <input class="form-control" name="name" value="<?php echo $package->name;?>" >
		                <?php echo form_error("name");?>
		                </div>
		              </div>
		              <div class="form-group row">
		                <label class="col-sm-3 form-control-label" for="inputEmail3">Package Price</label>
		                <div class="col-sm-9">
		                  <input class="form-control" name="price" value="<?php echo $package->price;?>" >
		                <?php echo form_error("price");?>
		                </div>
		              </div>

		              <div class="form-group row">
		                <label class="col-sm-3 form-control-label" for="inputEmail3">Disk Size</label>
		                <div class="col-sm-9">
		                  <input class="form-control" name="size" value="<?php echo $package->size;?>" >
		                <?php echo form_error("size");?>
		                </div>
		              </div>

		              <div class="form-group row">
		                <label class="col-sm-3 form-control-label" for="inputEmail3">Bandwidth</label>
		                <div class="col-sm-9">
		                  <input class="form-control" name="bandwidth" value="<?php echo $package->bandwidth;?>" >
		                <?php echo form_error("bandwidth");?>
		                </div>
		              </div>

		              <div class="form-group row">
		                <label class="col-sm-3 form-control-label" for="inputEmail3">Validity</label>
		                <div class="col-sm-9">
		                  <select class="form-control" name="validity">
		                  	<option <?php if($package->validity=="3") { echo "selected"; } ?> value='3'>3 Months</option>
		                  	<option <?php if($package->validity=="6") { echo "selected"; } ?> value='6'>6 Months</option>
		                  	<option <?php if($package->validity=="9") { echo "selected"; } ?> value='9'>9 Months</option>
		                  	<option <?php if($package->validity=="12") { echo "selected"; } ?> value='12'>12 Months</option>
		                  </select>
		                <?php echo form_error("validity");?>
		                </div>
		              </div>

		               <div class="form-group row">
		                <label class="col-sm-3 form-control-label" for="inputEmail3">Package Order</label>
		                <div class="col-sm-9">
		                  <input class="form-control" name="packageorder" value="<?php echo $package->packageorder;?>" >
		                <?php echo form_error("packageorder");?>
		                </div>
		              </div>
		            
		              
		              <div class="form-group row">
		                <label class="col-sm-3 form-control-label" for="inputEmail3"></label>
		                <div class="col-sm-9">
		                  <input type="submit" class="btn btn-primary"  value="Update" >
		                </div>
		              </div>
             		</form>
             		


                                                       
    		</div>
    	</div>
    </div>

  </div>