
  
    <div class="content-wrapper">
    
    <div class="row">
      
      <ol class="breadcrumb m-b-0">      
      </ol>
      <div class="col-md-12">
      <h3>Upload Files</h3>
        <div class="card">
          <div class="card-block">
            <h5>Send Files</h5>
            <?php if(isset($message)) { echo "<p class='alert alert-success'>".$message."</p>" ; } ?>
             <form id="fileupload" action="<?php echo base_url();?>user/uploadfile" method="POST" enctype="multipart/form-data">
              <input type="hidden" name="session_id" value="<?php echo $session_id;?>">
              <div class="form-group row">
                <label class="col-sm-3 form-control-label" for="inputEmail3">Select Email</label>
                <div class="col-sm-9">
                  <select name="staff[]" required class="chosen-select form-control" data-placeholder="Choose staff members to send files..." style="width:350px;" multiple tabindex="3">
            
                        <?php
                        foreach ($staff as $key => $value) {
                             echo "<option value='".$value->user_id."'>".$value->email." (".$value->name.") </option>";
                        }
                        ?>
                  </select>
                </div>
              </div>

              <div class="form-group row">
                <label class="col-sm-3 form-control-label" for="inputEmail3">Description</label>
                <div class="col-sm-9">
                  <textarea class="form-control" name="description" required></textarea>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-sm-3 form-control-label" for="inputPassword3">Select Validity</label>
                <div class="col-sm-9">
                 <div class="c-inputs-stacked">
                    <label class="c-input c-radio">
                      <input type="radio" name="validity" value="1" id="validity1" required>
                       <span class="c-indicator"></span> 
                      1 Day
                    </label>
                    <label class="c-input c-radio">
                      <input type="radio" name="validity" value="5" id="validity5" required>
                       <span class="c-indicator"></span> 
                      5 Days
                    </label>
                    <label class="c-input c-radio">
                      <input type="radio" name="validity" value="10" id="validity10" required>
                       <span class="c-indicator"></span> 
                      10 Days
                    </label>
                    <label class="c-input c-radio">
                      <input type="radio" name="validity" value="15" id="validity15" required>
                       <span class="c-indicator"></span> 
                      15 Days
                    </label>
                  </div>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-sm-3">Select Files</label>
                <div class="col-sm-9">
                  <div class="checkbox">
<div >
       <!-- Redirect browsers with JavaScript disabled to the origin page -->
        <noscript><input type="hidden" name="redirect" value="https://blueimp.github.io/jQuery-File-Upload/"></noscript>
        <!-- The fileupload-buttonbar contains buttons to add/delete files and start/cancel the upload -->
        <div class="row fileupload-buttonbar">
            <div class="col-lg-7">
                <!-- The fileinput-button span is used to style the file input field as button -->
                <span class="btn btn-success fileinput-button">
                    <i class="glyphicon glyphicon-plus"></i>
                    <span>Add files...</span>
                    <input type="file" name="files[]" multiple >
                </span>
                <button type="submit" class="btn btn-primary start">
                    <i class="glyphicon glyphicon-upload"></i>
                    <span>Start upload</span>
                </button>
                <button type="reset" class="btn btn-warning cancel">
                    <i class="glyphicon glyphicon-ban-circle"></i>
                    <span>Cancel upload</span>
                </button>
                <button type="button" class="btn btn-danger delete">
                    <i class="glyphicon glyphicon-trash"></i>
                    <span>Delete</span>
                </button>
                <input type="checkbox" class="toggle">
                <!-- The global file processing state -->
                <span class="fileupload-process"></span>
            </div>
            <!-- The global progress state -->
            <div class="col-lg-5 fileupload-progress fade">
                <!-- The global progress bar -->
                <div class="progress progress-striped active" role="progressbar" aria-valuemin="0" aria-valuemax="100">
                    <div class="progress-bar progress-bar-success" style="width:0%;"></div>
                </div>
                <!-- The extended global progress state -->
                <div class="progress-extended">&nbsp;</div>
            </div>
        </div>
        <!-- The table listing the files available for upload/download -->
        <table role="presentation" class="table table-striped"><tbody class="files"></tbody></table>
   
       
</div>
                </div>
              </div>
              <div class="form-group row">
                <div class="col-sm-offset-3 col-sm-9">
                  <button class="btn btn-primary" type="submit">Send Files</button>
                </div>
              </div>
            </form>
          </div>
        </div>

      </div>
    </div>

  </div>

  <script id="template-upload" type="text/x-tmpl">
{% for (var i=0, file; file=o.files[i]; i++) { %}
    <tr class="template-upload fade">
        <td>
            <span class="preview"></span>
        </td>
        <td>
            <p class="name">{%=file.name%}</p>
            <strong class="error text-danger"></strong>
        </td>
        <td>
            <p class="size">Processing...</p>
            <div class="progress progress-striped active" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><div class="progress-bar progress-bar-success" style="width:0%;"></div></div>
        </td>
        <td>
            {% if (!i && !o.options.autoUpload) { %}
                <button class="btn btn-primary start" disabled>
                    <i class="glyphicon glyphicon-upload"></i>
                    <span>Start</span>
                </button>
            {% } %}
            {% if (!i) { %}
                <button class="btn btn-warning cancel">
                    <i class="glyphicon glyphicon-ban-circle"></i>
                    <span>Cancel</span>
                </button>
            {% } %}
        </td>
    </tr>
{% } %}
</script>
<!-- The template to display files available for download -->
<script id="template-download" type="text/x-tmpl">
{% for (var i=0, file; file=o.files[i]; i++) { %}
    <tr class="template-download fade">
        <td>
            <span class="preview">
                {% if (file.thumbnailUrl) { %}
                    <img src="{%=file.thumbnailUrl%}">
                {% } %}
            </span>
        </td>
        <td>
            <p class="name">
                {% if (file.url) { %}
                    {%=file.name%}
                    <input type="hidden" value="{%=file.name%}" name="filename[]">
                {% } else { %}
                    <span>{%=file.name%}</span>
                {% } %}
            </p>
            {% if (file.error) { %}
                <div><span class="label label-danger">Error</span> {%=file.error%}</div>
            {% } %}
        </td>
        <td>
            <span class="size">{%=o.formatFileSize(file.size)%}</span>
        </td>
        <td>
            {% if (file.deleteUrl) { %}
                <button class="btn btn-danger delete" data-type="{%=file.deleteType%}" data-url="{%=file.deleteUrl%}"{% if (file.deleteWithCredentials) { %} data-xhr-fields='{"withCredentials":true}'{% } %}>
                    <i class="glyphicon glyphicon-trash"></i>
                    <span>Delete</span>
                </button>
                <input type="checkbox" name="delete" value="1" class="toggle">
            {% } else { %}
                <button class="btn btn-warning cancel">
                    <i class="glyphicon glyphicon-ban-circle"></i>
                    <span>Cancel</span>
                </button>
            {% } %}
        </td>
    </tr>
{% } %}
</script>