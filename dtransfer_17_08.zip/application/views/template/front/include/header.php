<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  
  <title><?php echo $site_settings->title;?></title>

  <!-- Google Font & Material Icons  -->
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Roboto:regular,bold,italic,thin,light,bolditalic,black,medium&amp;lang=en" rel="stylesheet">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
  <!-- App CSS -->
  <link type="text/css" href="<?php echo base_url();?>assets/css/style.min.css" rel="stylesheet">
  <link type="text/css" href="<?php echo base_url();?>assets/css/chosen.min.css" rel="stylesheet">
  <link type="text/css" href="<?php echo base_url();?>assets/css/own.css" rel="stylesheet">
  <link type="text/css" href="https://cdn.datatables.net/buttons/1.1.2/css/buttons.dataTables.min.css" rel="stylesheet">
  <!-- Jquery -->
  <link rel="stylesheet" href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.9/themes/base/jquery-ui.css" id="theme">
  <link rel="stylesheet" href="<?php echo base_url(); ?>fileuploader/css/jquery.fileupload-ui.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/css/jquery.dataTables.min.css">
   
</head>
<body class="login">