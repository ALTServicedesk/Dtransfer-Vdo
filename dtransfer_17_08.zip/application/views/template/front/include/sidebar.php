<!-- Navbar -->

  <nav class="navbar navbar-light bg-primary navbar-full navbar-fixed-top left-md-sidebar">
    <button class="navbar-toggler pull-xs-left hidden-md-up" type="button" data-toggle="sidebar" data-target="#sidebarLeft" data-transition="false">
      <span class="material-icons">menu</span>
    </button>
    <div class="pull-xs-left hidden-sm-down">
     <table class="table">
      <tr>
        <td>Package Name:</td>
        <td><?php echo $package_data->name;?></td>
      </tr>
      <tr>
        <td>Availabe Disk Size:</td>
        <td><?php echo $package_data->name;?></td>
      </tr>
      <tr>
        <td>Expiry:</td>
        <td><?php echo $logged_in_user->package_validity;?></td>
      </tr>
     </table>
    </div>
    <!-- <div class="pull-xs-right hidden-sm-down">
        <ul class="nav navbar-nav">
            <li class="nav-item dropdown">
                <a class="nav-link active dropdown-toggle p-a-0" data-toggle="dropdown" href="#" role="button" aria-haspopup="false" >
                  <?php
                      if($user->image=="")
                        $imgurl=base_url()."assetsnew/images/icon-user-default.png";
                      else
                        $imgurl=base_url()."uploads/".$user->image;
                      ?>
                      <img src="<?php echo $imgurl;?>" class="img-circle" width="40">
                    </a>
                <div class="dropdown-menu dropdown-menu-right dropdown-menu-list" aria-labelledby="Preview">
                    <a class="dropdown-item" href="<?php echo base_url();?>user/profile">Profile</span></a>
                    <a class="dropdown-item" href="<?php echo base_url();?>user/logout">Logout</a>
                </div>
            </li>
        </ul>
    </div> -->
  </nav>
  <!-- Sidebar -->

  <div class="sidebar sidebar-left sidebar-dark bg-primary show-desktop" id="sidebarLeft">
    <a href="<?php echo base_url();?>" class="sidebar-brand">
        <span class="icon-text"><img src="<?php echo base_url();?>uploads/<?php echo $site_settings->logo;?>" width="100px" height="40px"></span>
    </a>
    <a href="<?php echo base_url();?>" class="sidebar-user">
      <?php
                      
                      if($user->image=="")
                        $imgurl=base_url()."assetsnew/images/icon-user-default.png";
                      else
                        $imgurl=base_url()."uploads/".$user->image;

                      ?>
                      <img src="<?php echo $imgurl;?>" class="img-circle" width="40">
                      
                    
      <?php echo $logged_in_user->name;?>
    </a>
    <ul class="nav" id="mainMenu">
      <li class="nav-item">
          <a class="nav-link" href="<?php echo base_url();?>user/dashboard"><i class="fa fa-tachometer"></i> Dashboard</span></a> 
      </li>

     
        <li class="nav-item">
            <a class="nav-link" href="<?php echo base_url();?>user/upload"><i class="fa fa-paper-plane"></i> Compose</span></a> 
        </li>
       
      <li class="nav-item">
            <a class="nav-link" href="<?php echo base_url();?>user/myfilesreceived"><i class="fa fa-envelope"></i> Inbox</span></a> 
      </li>
       <li class="nav-item">
           <a class="nav-link" href="<?php echo base_url();?>user/myfilessent"><i class="fa fa-share"></i> Sent</span></a> 
      </li>
      <?php 
      if( $logged_in_user->type!=3)     
      {
        ?>
       <li class="nav-item">
           <a class="nav-link" href="<?php echo base_url();?>packages/viewall"><i class="fa fa-share"></i> Package Upgrade</span></a> 
      </li>
      <?php
      }
      ?>
      <?php 
      if( $logged_in_user->type==3)     
      {
        ?>
        <li class="nav-item">
        </li> 
        <li class="nav-item">
          <a class="nav-link" href="#">
              <i class="fa fa-users"></i> Users</span>
          </a>
          <ul>
              <li><a href="<?php echo base_url();?>user/allusers">All Users</a></li>
              <li><a href="<?php echo base_url();?>user/addstaff">Add User</a></li>
          </ul>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">
              <i class="fa fa-gear"></i>  Settings</span>
          </a>
          <ul>
              <li><a href="<?php echo base_url();?>user/configuration">Configuration</a></li>
              <li><a href="<?php echo base_url();?>user/smtpsettings">SMTP Settings</a></li>
          </ul>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="#">
              <i class="fa fa-cubes"></i>  Packages</span>
          </a>
          <ul>
              <li><a href="<?php echo base_url();?>packages/add">Add New</a></li>
              <li><a href="<?php echo base_url();?>packages/all">All Packages</a></li>
              <li><a href="<?php echo base_url();?>packages/requestall/0">Pending Package Request</a></li>
              <li><a href="<?php echo base_url();?>packages/requestall/1">Accepted Package Request</a></li>
              <li><a href="<?php echo base_url();?>packages/requestall/2">Canceled Package Request</a></li>
          </ul>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="#">
              <i class="fa fa-bar-chart"></i>  Logs</span>
          </a>
          <ul>
              <li><a href="<?php echo base_url();?>logs/otp">OTP Transactions</a></li>
              <li><a href="<?php echo base_url();?>logs/download">Download Usage</a></li>
          </ul>
        </li>

        
        <?php
      }
      ?>
      
      <li class="nav-item">
          <a class="nav-link" href="<?php echo base_url();?>user/profile"><i class="fa fa-user"></i>  Profile</span></a> 
      </li>
      <li class="nav-item">
          <a class="nav-link" href="<?php echo base_url();?>user/logout"><i class="fa fa-sign-out"></i>  Log Out</span></a> 
      </li>
    </ul>
  </div>