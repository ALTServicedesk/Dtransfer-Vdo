<div class="modal fade" id="requestupgrade" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="exampleModalLabel">Package Update request</h4>
      </div>
      <div class="modal-body">
        <form action="<?php echo base_url();?>packages/request" method="post">
          <div class="form-group">
            <label for="recipient-name" class="control-label">Package Name:</label>
            <input type="text" class="form-control"  id="packagename" readonly="">
            <input type="hidden" class="form-control" name="packageid" id="packageid" readonly="">
            <input type="hidden" class="form-control" name="userid" id="userid" value="<?php echo $user->user_id;?>" readonly="">
          </div>
          <div class="form-group">
            <label for="message-text" class="control-label">Addition Requirements:</label>
            <textarea class="form-control" name="message"></textarea>
          </div>
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Request</button>
      </form>
        
      </div>
      <div class="modal-footer">
      </div>
    </div>
  </div>
</div>

<!-- App JS -->
<script type="text/javascript">
var base_url="<?php echo base_url();?>";
</script>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.1/jquery.min.js"></script>
  <script src="<?php echo base_url();?>assets/js/sidebar.min.js"></script> <!-- // APP Sidebar -->
  <!-- // END App JS -->
  
  <!-- Bootstrap JS -->
  <script src="<?php echo base_url();?>assets/js/tether.min.js"></script> <!-- // Tooltips in BS4 -->
  <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script> <!-- // BS4 -->
  <!-- // END Bootstrap -->
  
  <script src="<?php echo base_url();?>assets/js/chosen.jquery.min.js"></script> <!-- // BS4 -->
 
  <!-- Vendor JS -->
     <!-- // END Vendor Scripts -->
  <script src="http://cdn.datatables.net/1.10.11/js/jquery.dataTables.min.js"></script> <!-- // BS4 -->
  <script src="https://cdn.datatables.net/1.10.11/js/dataTables.bootstrap.min.js"></script> <!-- // BS4 -->
  <script src="https://cdn.datatables.net/buttons/1.1.2/js/dataTables.buttons.min.js"></script>
  <script src="//cdn.datatables.net/buttons/1.1.2/js/buttons.flash.min.js"></script>
  <script src="//cdnjs.cloudflare.com/ajax/libs/jszip/2.5.0/jszip.min.js"></script>
  <script src="//cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/pdfmake.min.js"></script>
  <script src="//cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/vfs_fonts.js"></script>
  <script src="//cdn.datatables.net/buttons/1.1.2/js/buttons.html5.min.js"></script>
  <script src="//cdn.datatables.net/buttons/1.1.2/js/buttons.print.min.js"></script>

<!-- Example of Vendor Inits (bundled in "examples/js/examples.bundle.min.js") -->
   <script type="text/javascript">
     (function( $ ){
  function isValidEmailAddress(emailAddress) {
    var pattern = /^([a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+(\.[a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+)*|"((([ \t]*\r\n)?[ \t]+)?([\x01-\x08\x0b\x0c\x0e-\x1f\x7f\x21\x23-\x5b\x5d-\x7e\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|\\[\x01-\x09\x0b\x0c\x0d-\x7f\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))*(([ \t]*\r\n)?[ \t]+)?")@(([a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.)+([a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.?$/i;
    return pattern.test(emailAddress);
};

function custom_alert(output_msg, title_msg)
{
    if (!title_msg)
        title_msg = 'Alert';

    if (!output_msg)
        output_msg = 'No Message to Display.';

    $("<div></div>").html(output_msg).dialog({
        title: title_msg,
        resizable: false,
        modal: true,
        buttons: {
            "Ok": function() 
            {
                $( this ).dialog( "close" );
            }
        }
    });
}
     $.fn.multipleInput = function() {
 
          return this.each(function() {
 
               // create html elements
 
               // list of email addresses as unordered list
               $list = $('<ul />');
 
               // input
               var $input = $('<input type="text" class="from-contorl"/>').keyup(function(event) {
 
                    if(event.which == 32 || event.which == 188 || event.which == 9) {
                         // key press is space or comma
                         var val = $(this).val().slice(0, -1); // remove space/comma from value
                        
                        if( isValidEmailAddress( val ) ) 
                        { 
                         // append to list of emails with remove button
                         $list.append($('<li class="multipleInput-email"><span>' + val + '</span></li>')
                              .append($('<a href="#" class="multipleInput-close" title="Remove" ><i class="fa fa-times"></i></a>')
                                   .click(function(e) {
                                        $(this).parent().remove();
                                        e.preventDefault();
                                   })
                              )
                         );
                         $(this).attr('placeholder', '');
                         // empty input
                         $(this).val('');
                         }
                         else{
                         custom_alert("Not vailid email", "Email Error");
                         }
                    }
 
               });
 
               // container div
               var $container = $('<div class="multipleInput-container" />').click(function() {
                    $input.focus();
               });
 
               // insert elements into DOM
               $container.append($list).append($input).insertAfter($(this));
 
               // add onsubmit handler to parent form to copy emails into original input as csv before submitting
               var $orig = $(this);
               $(this).closest('form').submit(function(e) {
 
                    var emails = new Array();
                    $('.multipleInput-email span').each(function() {
                         emails.push($(this).html());
                    });
                    emails.push($input.val());
 
                    $orig.val(emails.join());
 
               });
 
               return $(this).hide();
 
          });
 
     };
})( jQuery );
     </script>

  <script type="text/javascript">
  $(document).ready(function (){
    var loader="processing";
    $(".requestupgradebtn").click(function (){
      $('#requestupgrade').modal("show");
      $("#packagename").val($(this).data("name"));
      $("#packageid").val($(this).data("id"));
    });

     $(".changerequest").click(function (e){
      e.preventDefault();
      var packageid= $(this).data("packageid");
      var type= $(this).data("type");
      $.ajax({
            url: "<?php echo base_url();?>packages/requestupdate",
            method: "post",
            data: {packageid:packageid,type:type} ,
            success: function(result){
              //window.location="";
            }
        });
    });
    
    $('#my_input').multipleInput();
    $("body").on('click','#change_password',function(e){
        e.preventDefault();
        $("#password_result").html(loader);
        var oldpass=$("#oldpass").val();
        var newpassword=$("#newpassword").val();
        var repeatpassword=$("#repeatpassword").val();
        var user_id=$("#user_id").val();
        if(oldpass==""){ 
            $("#password_result").html("<p class='alert alert-danger'> Old Password is required</p>"); 
        }
        else{
            if(newpassword==""){ 
                $("#password_result").html("<p class='alert alert-danger'> Password is required</p>"); 
            }
            else if(repeatpassword==""){ 
                $("#password_result").html("<p class='alert alert-danger'> Confirm Password is required</p>"); 
            }
            else{

                    if(newpassword!=repeatpassword)
                    {
                        $("#password_result").html("<p class='alert alert-danger'> New paswords not matached.</p>");
                    }
                    else
                    {
                        $.ajax({
                            url: "<?php echo base_url();?>user/changepass",
                            method: "post",
                            data: {oldpass:oldpass,newpassword:newpassword,repeatpassword:repeatpassword} ,
                            success: function(result){
                                $("#password_result").html(result);
                            }
                        });
                    }

            }
            
        }

    });

  	 $(".chosen-select").chosen({no_results_text: "Oops, nothing found!"}); 
     $('.datatable').DataTable({
        dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ]
     });

     $('.download_change').change(function() {
      var sThisVal="";
      var aurl="";
         var sThisVal = $('input:checkbox:checked').map(function() {
              aurl=aurl+","+this.value;
              return "<li>"+this.value+"</li>";
          }).get();
          $("#selected>span").html(sThisVal);
          $("#downloadlink").attr("href","<?php echo base_url();?>files/downloadmultiple?filename="+aurl);
          
     });


  })
  </script>


<script src="https://code.jquery.com/ui/jquery-ui-git.js"></script>
<script src="//ajax.aspnetcdn.com/ajax/jquery.templates/beta1/jquery.tmpl.min.js"></script>


<script src="<?php echo base_url();?>fileuploader/js/vendor/jquery.ui.widget.js"></script>
<!-- The Templates plugin is included to render the upload/download listings -->
<script src="http://blueimp.github.io/JavaScript-Templates/js/tmpl.min.js"></script>
<!-- The Load Image plugin is included for the preview images and image resizing functionality -->
<script src="http://blueimp.github.io/JavaScript-Load-Image/js/load-image.all.min.js"></script>
<!-- The Canvas to Blob plugin is included for image resizing functionality -->
<script src="http://blueimp.github.io/JavaScript-Canvas-to-Blob/js/canvas-to-blob.min.js"></script>
<!-- Bootstrap JS is not required, but included for the responsive demo navigation -->
<script src="http://netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
<!-- blueimp Gallery script -->
<script src="http://blueimp.github.io/Gallery/js/jquery.blueimp-gallery.min.js"></script>
<!-- The Iframe Transport is required for browsers without support for XHR file uploads -->
<script src="<?php echo base_url();?>fileuploader/js/jquery.iframe-transport.js"></script>
<!-- The basic File Upload plugin -->
<script src="<?php echo base_url();?>fileuploader/js/jquery.fileupload.js"></script>
<!-- The File Upload processing plugin -->
<script src="<?php echo base_url();?>fileuploader/js/jquery.fileupload-process.js"></script>
<!-- The File Upload image preview & resize plugin -->
<script src="<?php echo base_url();?>fileuploader/js/jquery.fileupload-image.js"></script>
<!-- The File Upload audio preview plugin -->
<script src="<?php echo base_url();?>fileuploader/js/jquery.fileupload-audio.js"></script>
<!-- The File Upload video preview plugin -->
<script src="<?php echo base_url();?>fileuploader/js/jquery.fileupload-video.js"></script>
<!-- The File Upload validation plugin -->
<script src="<?php echo base_url();?>fileuploader/js/jquery.fileupload-validate.js"></script>
<!-- The File Upload user interface plugin -->
<script src="<?php echo base_url();?>fileuploader/js/jquery.fileupload-ui.js"></script>
<!-- The main application script -->
<script src="<?php echo base_url();?>fileuploader/js/main.js"></script>
     

    
</body>
</html>