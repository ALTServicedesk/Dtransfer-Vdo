
  
    <div class="content-wrapper">
    
    <div class="row">
      
      <ol class="breadcrumb m-b-0">      
      </ol>
      <div class="col-md-12">
      <h3>Packages</h3>
        <div class="card">
        <table class="table table-striped table-hover table-sm datatable">
        	<thead>
        		<td>S No</td>
        		<td>Name</td>
        		<td>Validity</td>
        		<td>Disk Size</td>
        		<td>Bandwidth</td>
        		<td>Shown Order</td>
        		<td>Price</td>
        		<td>Actions</td>
        	</thead>
        	<?php
        	$i=1;
        		foreach ($packages as $key => $value) {
        			
        		?>
        			<tr>
        				<td><?php echo $i++;?></td>
        				<td><?php echo $value->name;?></td>
        				<td><?php echo $value->validity;?> Months</td>
        				<td><?php echo $value->size;?> MB</td>
        				<td><?php echo $value->bandwidth;?> MB</td>
        				<td><?php echo $value->packageorder;?> </td>
        				<td><i class="fa fa-inr"></i> <?php echo $value->price;?></td>
        				<td><a class="btn btn-success" href="<?php echo base_url();?>packages/edit/<?php echo $value->package_id;?>">Edit</a></td>
        			</tr>
        		<?php
        		}
        		?>

        </table>
        </div>

      </div>
    </div>

  </div>