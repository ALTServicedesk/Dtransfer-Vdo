
  
    <div class="content-wrapper">
    
    <div class="row">
      
      <ol class="breadcrumb m-b-0">      
      </ol>
      <div class="col-md-12">
      <h3>OTP Transactions</h3>
        <div class="card">
            <?php if(isset($message)) { echo "<p class='alert alert-success'>".$message."</p>" ; } ?>
        
        <table class="table table-striped table-hover table-sm datatable">
            <thead>
                <th>S NO.</th>
                <th>Used By</th>
                <th>Sent to</th>
                <th>OTP</th>
                <th>Status</th>
                <th>Time</th>
            </thead>
            <?php
            $i=1;
            if($allotp!=NULL)
            {
                foreach ($allotp as $key => $value) {
                    # code...
                ?>
                <tr>
                    <td><?php echo $i++;?></td>
                    <td><?php echo  $value->email." <br>"; ?></td>
                    <td><?php echo  $value->sentemail." <br>"; ?></td>
                    <td><?php echo $value->otp;?></td>
                    <td><?php if($value->status==1){ echo "<p class='btn btn-success'> <i class='fa fa-check'></i></p>"; } else{ echo "<p class='btn btn-danger'> <i class='fa fa-times'></i></p>"; } ?></td>
                    <td><?php echo date("d-m-Y H:m A",strtotime($value->timestamp));?></td>
                  
                <?php
                }
                ?>
            <?php    
            }
            else
            {
                echo "<tr><td colspan='5'>No Data found</td></tr>";
            }
            ?>
        </table>
        </div>

      </div>
    </div>

  </div>

  <script id="template-upload" type="text/x-tmpl">
{% for (var i=0, file; file=o.files[i]; i++) { %}
    <tr class="template-upload fade">
        <td>
            <span class="preview"></span>
        </td>
        <td>
            <p class="name">{%=file.name%}</p>
            <strong class="error text-danger"></strong>
        </td>
        <td>
            <p class="size">Processing...</p>
            <div class="progress progress-striped active" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><div class="progress-bar progress-bar-success" style="width:0%;"></div></div>
        </td>
        <td>
            {% if (!i && !o.options.autoUpload) { %}
                <button class="btn btn-primary start" disabled>
                    <i class="glyphicon glyphicon-upload"></i>
                    <span>Start</span>
                </button>
            {% } %}
            {% if (!i) { %}
                <button class="btn btn-warning cancel">
                    <i class="glyphicon glyphicon-ban-circle"></i>
                    <span>Cancel</span>
                </button>
            {% } %}
        </td>
    </tr>
{% } %}
</script>
<!-- The template to display files available for download -->
<script id="template-download" type="text/x-tmpl">
{% for (var i=0, file; file=o.files[i]; i++) { %}
    <tr class="template-download fade">
        <td>
            <span class="preview">
                {% if (file.thumbnailUrl) { %}
                    <img src="{%=file.thumbnailUrl%}">
                {% } %}
            </span>
        </td>
        <td>
            <p class="name">
                {% if (file.url) { %}
                    {%=file.name%}
                    <input type="hidden" value="{%=file.name%}" name="filename[]">
                {% } else { %}
                    <span>{%=file.name%}</span>
                {% } %}
            </p>
            {% if (file.error) { %}
                <div><span class="label label-danger">Error</span> {%=file.error%}</div>
            {% } %}
        </td>
        <td>
            <span class="size">{%=o.formatFileSize(file.size)%}</span>
        </td>
        <td>
            {% if (file.deleteUrl) { %}
                <button class="btn btn-danger delete" data-type="{%=file.deleteType%}" data-url="{%=file.deleteUrl%}"{% if (file.deleteWithCredentials) { %} data-xhr-fields='{"withCredentials":true}'{% } %}>
                    <i class="glyphicon glyphicon-trash"></i>
                    <span>Delete</span>
                </button>
                <input type="checkbox" name="delete" value="1" class="toggle">
            {% } else { %}
                <button class="btn btn-warning cancel">
                    <i class="glyphicon glyphicon-ban-circle"></i>
                    <span>Cancel</span>
                </button>
            {% } %}
        </td>
    </tr>
{% } %}
</script>