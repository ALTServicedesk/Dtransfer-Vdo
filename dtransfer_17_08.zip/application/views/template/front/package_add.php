
  
    <div class="content-wrapper">
    
    <div class="row">
    <h3>Add new package</h3>
    	<div class="card">
    		<div class="card-block">
    				<form action="<?php echo base_url();?>packages/add" method="POST">
             		 <div class="form-group row">
		                <label class="col-sm-3 form-control-label" for="inputEmail3">Package Name</label>
		                <div class="col-sm-9">
		                  <input class="form-control" name="name" value="<?php echo set_value('name');?>" >
		                <?php echo form_error("name");?>
		                </div>
		              </div>
		              <div class="form-group row">
		                <label class="col-sm-3 form-control-label" for="inputEmail3">Package Price</label>
		                <div class="col-sm-9">
		                  <input class="form-control" name="price" value="<?php echo set_value('price');?>" >
		                <?php echo form_error("price");?>
		                </div>
		              </div>

		              <div class="form-group row">
		                <label class="col-sm-3 form-control-label" for="inputEmail3">Disk Size</label>
		                <div class="col-sm-9">
		                  <input class="form-control" name="size" value="<?php echo set_value('size');?>" >
		                <?php echo form_error("size");?>
		                </div>
		              </div>

		              <div class="form-group row">
		                <label class="col-sm-3 form-control-label" for="inputEmail3">Bandwidth</label>
		                <div class="col-sm-9">
		                  <input class="form-control" name="bandwidth" value="<?php echo set_value('bandwidth');?>" >
		                <?php echo form_error("bandwidth");?>
		                </div>
		              </div>

		              <div class="form-group row">
		                <label class="col-sm-3 form-control-label" for="inputEmail3">Bandwidth</label>
		                <div class="col-sm-9">
		                  <select class="form-control" name="validity">
		                  	<option value='3'>3 Months</option>
		                  	<option value='6'>6 Months</option>
		                  	<option value='9'>9 Months</option>
		                  	<option value='10'>10 Months</option>
		                  	<option value='12'>12 Months</option>
		                  </select>
		                <?php echo form_error("validity");?>
		                </div>
		              </div>

		               <div class="form-group row">
		                <label class="col-sm-3 form-control-label" for="inputEmail3">Package Order</label>
		                <div class="col-sm-9">
		                  <input class="form-control" name="packageorder" value="<?php echo set_value('packageorder');?>" >
		                <?php echo form_error("packageorder");?>
		                </div>
		              </div>
		            
		              
		              <div class="form-group row">
		                <label class="col-sm-3 form-control-label" for="inputEmail3"></label>
		                <div class="col-sm-9">
		                  <input type="submit" class="btn btn-primary"  value="Update" >
		                </div>
		              </div>
             		</form>
             		


                                                       
    		</div>
    	</div>
    </div>

  </div>