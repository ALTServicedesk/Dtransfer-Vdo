 
    <div class="content-wrapper">
    <ol class="breadcrumb m-b-0">
      
    </ol>
    <div class="row">
    	
      <div class="col-md-8">
      <h5>Users Activity</h5>
      <div class="card">
          <div class="card-header">
            <h5 class="card-title">Summary</h5>
          </div>
      </div>
        
      </div>
      <div class="col-md-4">
      <h5>Your Activity</h5>
      <div class="card">
          <div class="card-header">
            <h5 class="card-title">Activity Feed</h5>
          </div>
          <ul class="list-group">
          <?php
         
         if($activity!=NULL)
         {

        
          foreach ($activity as $key => $value) {
            $file=explode(",", $value->filename);

          ?>
          <li class="list-group-item">
              <div class="media">
                <div class="media-left media-middle">
                  <i class="material-icons md-36 text-muted">group_add</i>
                </div>
                <div class="media-body">
                  <p class="m-a-0">
                   You sent <?php echo count($file);?> files to  <a href="mailto:<?php echo $value->email;?>" ><?php echo $value->email;?> </a>
                  </p>
                  <small class="text-muted"><i class="material-icons md-18">today</i> <span class="icon-text"><?php echo date("d-m-Y h:s a",strtotime($value->timestamp));?></span></small>
                </div>
              </div>
            </li>
          <?php
          }
           }
           else{
            echo "Nothing to show yet.";
           }
          ?>
            
          </ul>
        </div>
        <div class="card">
          <div class="card-header ">
            <h5 class="card-title">Summary</h5>
          </div>   
          <table class="table table-sm m-a-0">
            <tr>
              <td>Total Uploaded</td>
              <td class="right text-primary"><strong><?php echo formatBytes($summaryupload['size']);?></strong></td>
            </tr>
            <tr>
              <td>Total Downloaded</td>
              <td class="right text-primary"><strong><?php echo formatBytes($summarydownload);?></strong></td>
            </tr>
          </table>
        </div>
    
        
    
       
      </div>
    
    </div>

  </div>