
  
    <div class="content-wrapper">
    <ol class="breadcrumb m-b-0">
     
    </ol>
    <div class="row">
    	<div class="card">
    		<div class="card-block">
    				<form action="<?php echo base_url();?>user/configuration" method="POST">
             		 <div class="form-group row">
		                <label class="col-sm-3 form-control-label" for="inputEmail3">Site Title</label>
		                <div class="col-sm-9">
		                  <input class="form-control" name="title" value="<?php echo $settings->title;?>" required>
		                </div>
		                <?php echo form_error("title");?>
		              </div>
		              <div class="form-group row">
		                <label class="col-sm-3 form-control-label" for="inputEmail3">Email</label>
		                <div class="col-sm-9">
		                  <input class="form-control" name="email" value="<?php echo $settings->email;?>" required>
		                </div>
		                <?php echo form_error("email");?>
		              </div>
		              <div class="form-group row">
		                <label class="col-sm-3 form-control-label" for="inputEmail3">Phone</label>
		                <div class="col-sm-9">
		                  <input class="form-control" name="phone" value="<?php echo $settings->phone;?>" required>
		                </div>
		                <?php echo form_error("phone");?>
		              </div>
		              <div class="form-group row">
		                <label class="col-sm-3 form-control-label" for="inputEmail3">Address</label>
		                <div class="col-sm-9">
		                  <input class="form-control" name="address" value="<?php echo $settings->address;?>" required>
		                </div>
		                <?php echo form_error("address");?>
		              </div>
		              
		              <div class="form-group row">
		                <label class="col-sm-3 form-control-label" for="inputEmail3"></label>
		                <div class="col-sm-9">
		                  <input type="submit" class="btn btn-primary"  value="Update" >
		                </div>
		              </div>
             		</form>
             		<h5>Upload Logo</h5>
             		<?php echo form_open_multipart('user/logoimage');?>
             		<div class="row">
             		<div class="col-md-9">
             		<div class="form-group row">
		                <label class="col-sm-3 form-control-label" for="inputEmail3">Site Logo</label>
		                <div class="col-sm-9">
		                  <?php echo "<input type='file' name='logo' size='20' required/>"; ?><br>
                                                        
		                </div>
		              </div>

		              <div class="form-group row">
		                <label class="col-sm-3 form-control-label" for="inputEmail3"></label>
		                <div class="col-sm-9">
                          <?php echo "<input type='submit' class='btn btn-primary' name='submit' value='upload' /> ";?>		                  
		                </div>
		               
		              </div>

                    </div>    
                     <div class="col-md-3">
                          <img src="<?php echo base_url();?>uploads/<?php echo $settings->logo;?>" width="100px">
		              		
		              </div> 
		            </div>                              
    		</div>
    	</div>
    </div>

  </div>