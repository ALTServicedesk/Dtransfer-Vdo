
  
    <div class="content-wrapper">
    
    <div class="row">
      
      <ol class="breadcrumb m-b-0">      
      </ol>
      <div class="col-md-12">
      <h3>Packages</h3>
        <div class="card">
        <?php if(isset($message)){ echo "<p class='alert alert-success'>".$message."</p>"; } ?>
            <div class="row db-padding-btm db-attached">
            <?php
            $i=1;
            	foreach ($packages as $key => $value) {
            		if($i==1){ $color="one"; }
            		if($i==2){ $color="two"; }
            		if($i==3){ $color="three"; }
            	?>
		            <div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
		                <div class="db-wrapper">
		                    <div class="db-pricing-eleven db-bk-color-<?php echo $color;?>">
		                        <div class="price">
		                            <sup><i class="fa fa-inr"></i></sup><?php echo $value->price;?>
		                                <small><?php echo $value->validity;?> Months</small>
		                        </div>
		                        <div class="type">
		                            <?php echo $value->name;?>
		                        </div>
		                        <ul>

		                            <li><i class="glyphicon glyphicon-print"></i><?php echo $value->bandwidth;?> MB </li>
		                            <li><i class="glyphicon glyphicon-time"></i><?php echo $value->size;?> MB </li>
		                        </ul>
		                        <div class="pricing-footer">

		                            <a href="#" class="btn db-button-color-square requestupgradebtn btn-lg" data-name="<?php echo $value->name;?>" data-id="<?php echo $value->package_id;?>" >REQUEST UPGRADE</a>
		                        </div>
		                    </div>
		                </div>
		            </div>

            	<?php
            	$i++;
            	}
            ?>
            
        </div>

      </div>
    </div>

  </div>