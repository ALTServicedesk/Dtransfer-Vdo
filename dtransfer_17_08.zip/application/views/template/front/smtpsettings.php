
  
    <div class="content-wrapper">
    <ol class="breadcrumb m-b-0">
      
    </ol>
    <div class="row">
    	<div class="card">
    		<div class="card-block">
    				<form action="<?php echo base_url();?>user/smtpsettings" method="POST">
             		 <div class="form-group row">
		                <label class="col-sm-3 form-control-label" for="inputEmail3">SMTP Host</label>
		                <div class="col-sm-9">
		                  <input class="form-control" name="smtphost" value="<?php echo $settings->smtphost;?>" required>
		                </div>
		              </div>
		              <div class="form-group row">
		                <label class="col-sm-3 form-control-label" for="inputEmail3">SMTP Port</label>
		                <div class="col-sm-9">
		                  <input class="form-control" name="smtpport" value="<?php echo $settings->smtpport;?>" required>
		                </div>
		              </div>
		              <div class="form-group row">
		                <label class="col-sm-3 form-control-label" for="inputEmail3">SMTP User</label>
		                <div class="col-sm-9">
		                  <input class="form-control" name="smtpuser" value="<?php echo $settings->smtpuser;?>" required>
		                </div>
		              </div>
		              <div class="form-group row">
		                <label class="col-sm-3 form-control-label" for="inputEmail3">SMTP Pass</label>
		                <div class="col-sm-9">
		                  <input type="password" class="form-control" name="smtppass" value="<?php echo $settings->smtppass;?>" required>
		                </div>
		              </div>
		              
		              <div class="form-group row">
		                <label class="col-sm-3 form-control-label" for="inputEmail3"></label>
		                <div class="col-sm-9">
		                  <input type="submit" class="btn btn-primary"  value="Update" >
		                </div>
		              </div>
             		</form>                          
    		</div>
    	</div>
    </div>

  </div>