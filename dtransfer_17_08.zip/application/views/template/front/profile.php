
    <div class="content-wrapper">
    <ol class="breadcrumb m-b-0">
     
    </ol>
    <div class="row">
    	<div class="col-md-12">
    		<h5>Update your Profile</h5>

    		<div class="card">
    			<div class="card-block">
            		<?php if(isset($message)) { echo "<p class='alert alert-success'>".$message."</p>" ; } ?>
					<form action="<?php echo base_url();?>user/profile" method="POST">
             		 <div class="form-group row">
		                <label class="col-sm-2 form-control-label" for="inputEmail3">Name</label>
		                <div class="col-sm-6">
		                  <input class="form-control" name="name" value="<?php echo $user->name;?>" required>
		                </div>
		              </div>
		              <div class="form-group row">
		                <label class="col-sm-2 form-control-label" for="inputEmail3">Email</label>
		                <div class="col-sm-6">
		                  <input class="form-control" name="email" readonly value="<?php echo $user->email;?>" required>
		                </div>
		              </div>
		              <div class="form-group row">
		                <label class="col-sm-2 form-control-label" for="inputEmail3"></label>
		                <div class="col-sm-6">
		                  <input type="submit" class="btn btn-primary"  value="Update" >
		                </div>
		              </div>
             		</form>
             		
             			<div class="row">
             				<div class="col-md-8">
             					<h5 class="text-center">Change Password</h5>
            						<?php if(isset($passmessage)) { echo "<p class='alert alert-success'>".$message."</p>" ; } ?>
             					<form>
			             		 <div class="form-group row">
					                <label class="col-sm-3 form-control-label" for="inputEmail3">Old Password</label>
					                <div class="col-sm-9">
					                  <input type="password" class="form-control" id="oldpass" required></textarea>
					                </div>
					              </div>
					              <div class="form-group row">
					                <label class="col-sm-3 form-control-label" for="inputEmail3">New Password</label>
					                <div class="col-sm-9">
					                  <input type="password" class="form-control" id="newpassword" required></textarea>
					                </div>
					              </div>
					              <div class="form-group row">
					                <label class="col-sm-3 form-control-label" for="inputEmail3">Confirm Password</label>
					                <div class="col-sm-9">
					                  <input type="password" class="form-control" id="repeatpassword" required></textarea>
					                </div>
					              </div>
					              <div class="form-group row">
					                <label class="col-sm-3 form-control-label" for="inputEmail3"></label>
					                <div class="col-sm-9">
					                  <input type="submit" id="change_password" class="btn btn-primary changepass"  value="Change Password" >
					               		<span id="password_result" ></span>
					                </div>
					              </div>
			             		</form>

             				</div>
             				<div class="col-md-4 text-center">
             					<h5 class="text-center">Change Image</h5>
             					<?php
             					
             					if($user->image=="")
             						$imgurl=base_url()."assetsnew/images/icon-user-default.png";
             					else
             						$imgurl=base_url()."uploads/".$user->image;

             					?>
             					<img src="<?php echo $imgurl;?>" class="img-circle profile-image">
             					<?php echo form_open_multipart('user/profileimage');?>
				             		<div class="form-group row">
						                <div class="col-sm-9">
						                  <?php echo "<input type='file' name='profileimage' size='20' required/>"; ?><br>
				                                                        
						                </div>
						              </div>

						              <div class="form-group row">
						                <label class="col-sm-3 form-control-label" for="inputEmail3"></label>
						                <div class="col-sm-4">
				                          <?php echo "<input type='submit' class='btn btn-primary' name='submit' value='upload' /> ";?>		                  
						                </div>

             				</div>
             			</div>
             	
    			</div>

    		</div>
    	</div>
    </div>

  </div>