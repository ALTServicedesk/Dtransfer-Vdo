<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html
  xmlns="http://www.w3.org/1999/xhtml">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>
      <?php echo $settings->site_name;?>
    </title>
    <style type="text/css">
    @import url(http://fonts.googleapis.com/css?family=Lato:400);

    /* Take care of image borders and formatting */

    img {
      max-width: 600px;
      outline: none;
      text-decoration: none;
      -ms-interpolation-mode: bicubic;
    }

    a {
      text-decoration: none;
      border: 0;
      outline: none;
    }

    a img {
      border: none;
    }

    /* General styling */

    td, h1, h2, h3  {
      font-family: Helvetica, Arial, sans-serif;
      font-weight: 400;
    }

    body {
      -webkit-font-smoothing:antialiased;
      -webkit-text-size-adjust:none;
      width: 100%;
      height: 100%;
      color: #37302d;
      background: #ffffff;
    }

     table {
      border-collapse: collapse !important;
    }


    h1, h2, h3 {
      padding: 0;
      margin: 0;
      color: #ffffff;
      font-weight: 400;
    }

    h3 {
      color: #21c5ba;
      font-size: 24px;
    }

    .important-font {
      color: black;
      font-weight: bold;

    }

    .hide {
      display: none !important;
    }

    .force-full-width {
      width: 100% !important;
    }
  </style>
    <style type="text/css" media="screen">
    @media screen {
       /* Thanks Outlook 2013! http://goo.gl/XLxpyl*/
      td, h1, h2, h3 {
        font-family: 'Lato', 'Helvetica Neue', 'Arial', 'sans-serif' !important;
      }
    }
  </style>
    <style type="text/css" media="only screen and (max-width: 480px)">
    /* Mobile styles */
    @media only screen and (max-width: 480px) {
      table[class="w320"] {
        width: 320px !important;
      }

      table[class="w300"] {
        width: 300px !important;
      }

      table[class="w290"] {
        width: 290px !important;
      }

      td[class="w320"] {
        width: 320px !important;
      }

      td[class="mobile-center"] {
        text-align: center !important;
      }

      td[class="mobile-padding"] {
        padding-left: 20px !important;
        padding-right: 20px !important;
        padding-bottom: 20px !important;
      }

      td[class="mobile-block"] {
        display: block !important;
        width: 100% !important;
        text-align: left !important;
        padding-bottom: 20px !important;
      }

      td[class="mobile-border"] {
        border: 0 !important;
      }

      td[class*="reveal"] {
        display: block !important;
      }
    }
  </style>
  </head>
  <body class="body" style="padding:0; margin:0; display:block; background:#ffffff; -webkit-text-size-adjust:none" bgcolor="#ffffff">
    <table style="background-color: #fff" align="center" width="100%">
      <tr>
        <td>
          <table style=" border:1px solid;" align="center"><!--6 tr in this table-->
          <tr><td height="40"></td></tr><!--ist tr of blur table-->
         
            <tr><td align="center"><img src="<?php echo base_url();?>uploads/logo.png" alt="ALTBalaji" title="Logo" style="display:block;" width="auto" height="auto"></td></tr><!--second tr of blur table-->
            <tr><td height="20"></td></tr><!--3th tr of blur table-->
            
              <tr><td style="font-size:24px;text-align: center;font-weight: bold;color:#000;">Reset Password!</td>  </tr><!--4th tr of blur table-->
              
              <tr>
                <td>
                  <table>
                    <td width="12%"></td>
                    <td width="76%">
                      <table>
                        <tr>
                          <td height="15"></td>
                        </tr>
                        <tr>
                          <td style="font-size:16px;color:#000;text-align:left">Hello,</td>
                        </tr>
                       
                        <tr>
                          <td style="font-size:16px;color:#000;text-align:left">Please click below to complete Forgot Password process. .</td>
                        </tr>
                        
                          <td height="20"></td>
                        </tr>
                        <tr>
                          <td style="text-align: center;">
                            <a style="font-size:18px;border: 2px solid #000;padding: 8px 17px;color: #000;border-radius: 10px;" href="<?php echo base_url();?>user/setnewpass/<?php echo $message['temppass'];?>">Click Here</a>
                          </td>
                        </tr>
                        <tr>
                          <td height="40"></td>                          
                        </tr>
                        <tr>
                          <td style="font-size:16px;color:#000;">
                            <table width="100%">
                              <tr>
                                <td width="14%"></td>
                                <td width="72%">Have fun!</td>
                                <td width="14%"></td>
                              </tr>
                            </table>
                          </td>
                        </tr>
                        <tr>
                          <td height="10"></td>
                        </tr>
                        <tr>
                          <td style="font-size:16px;color:#000;">

                            <table width="100%">
                              <tr>
                                <td width="14%"></td>
                                <td width="72%">Your friends at ALTBalaji</td>
                                <td width="14%"></td>
                              </tr>
                            </table>
                          </td>
                        </tr>
                        <tr>
                          <td height="10"></td>
                        </tr>
                         <tr>
                          <td style="font-size:16px;color:#000;">

                            <table width="100%">
                              <tr>
                                <td width="14%"></td>
                                <td width="72%"> If you have any questions, please feel free to contact our team on  <?php echo $settings->email;?></td>
                                <td width="14%"></td>
                              </tr>
                            </table>
                          </td>
                        </tr>
                        <tr>
                          <td height="40"></td>
                        </tr>
                      </table>
                    </td>
                    <td width="12%"></td>

                  </table>
                </td>
              </tr><!--6th tr of blur table-->



            
       
            
          </table><!--inside table with blur bg-->
        </td>
      </tr>
    </table><!--main table with black bg-->
                              </body>
                            </html>

