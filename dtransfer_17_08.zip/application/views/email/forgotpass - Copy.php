<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<table style="width:100%;padding:10px">
  <tbody><tr style="background-color:#0388C9;color:#fff;width:100%">
    <td style="padding:20px"><h1><?php echo $settings->title;?></h1></td>
    <td style="padding:20px"><?php echo $settings->address;?></td>
  </tr>
 
  <tr>
    <td colspan="2">
      <strong>Hi </strong>
      <p>
       You requested for password reset, Please visit <a href="<?php echo $baseurl;?>user/setnewpass/<?php echo $message['temppass'];?>"> this link </a> to setup new password.
      </p>
      If you have any questions, please feel free to contact our team on  <?php echo $settings->email;?>
</p><p>
<br><br>
      Thanks. Stay Connected

      
    </td>
    </tr><tr style="background-color:#0388C9;color:#fff;width:100%">
    <td colspan="2" style="padding:20px">
      <p>&copy; <?php echo $settings->title;?>, All rights are reserved.</p>
    </td>
    </tr>
  
</tbody></table>
</html>
