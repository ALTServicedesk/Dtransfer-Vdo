<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html
  xmlns="http://www.w3.org/1999/xhtml">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title><?php echo $settings->title;?></title>
    <style type="text/css">
    @import url(http://fonts.googleapis.com/css?family=Lato:400);

    /* Take care of image borders and formatting */

    img {
      max-width: 600px;
      outline: none;
      text-decoration: none;
      -ms-interpolation-mode: bicubic;
    }

    a {
      text-decoration: none;
      border: 0;
      outline: none;
    }

    a img {
      border: none;
    }

    /* General styling */

    td, h1, h2, h3  {
      font-family: Helvetica, Arial, sans-serif;
      font-weight: 400;
    }

    body {
      -webkit-font-smoothing:antialiased;
      -webkit-text-size-adjust:none;
      width: 100%;
      height: 100%;
      color: #37302d;
      background: #ffffff;
    }

     table {
      border-collapse: collapse !important;
    }


    h1, h2, h3 {
      padding: 0;
      margin: 0;
      color: #ffffff;
      font-weight: 400;
    }

    h3 {
      color: #21c5ba;
      font-size: 24px;
    }

    .important-font {
      color: black;
      font-weight: bold;

    }

    .hide {
      display: none !important;
    }

    .force-full-width {
      width: 100% !important;
    }
  </style>
    <style type="text/css" media="screen">
    @media screen {
       /* Thanks Outlook 2013! http://goo.gl/XLxpyl*/
      td, h1, h2, h3 {
        font-family: 'Lato', 'Helvetica Neue', 'Arial', 'sans-serif' !important;
      }
    }
  </style>
    <style type="text/css" media="only screen and (max-width: 480px)">
    /* Mobile styles */
    @media only screen and (max-width: 480px) {
      table[class="w320"] {
        width: 320px !important;
      }

      table[class="w300"] {
        width: 300px !important;
      }

      table[class="w290"] {
        width: 290px !important;
      }

      td[class="w320"] {
        width: 320px !important;
      }

      td[class="mobile-center"] {
        text-align: center !important;
      }

      td[class="mobile-padding"] {
        padding-left: 20px !important;
        padding-right: 20px !important;
        padding-bottom: 20px !important;
      }

      td[class="mobile-block"] {
        display: block !important;
        width: 100% !important;
        text-align: left !important;
        padding-bottom: 20px !important;
      }

      td[class="mobile-border"] {
        border: 0 !important;
      }

      td[class*="reveal"] {
        display: block !important;
      }
    }
  </style>
  </head>
  <?php
$files=explode(",",$message['files']["filename"]);
?>
  <body class="body" style="padding:0; margin:0; display:block; background:#ffffff; -webkit-text-size-adjust:none" bgcolor="#ffffff">
    <table style="background-color: #fff" align="center" width="100%">
      <tr>
        <td>
          <table style="  " align="center" width="100%"><!--6 tr in this table-->
          <tr><td height="40"></td></tr><!--ist tr of blur table-->
            <tr>
              <td>
                <table width="100%">
                  <tr>
                    <td width="10%"></td>
                    <td width="80%">
                      <table>
                        <tr>
                          <td width="40%" style="color:#000">
                            <b>ALT Digital Media Entertainment Limited</b><br>
                              <?php echo $settings->address;?>
                          </td>
                          <td width="60%" align="right">
                            <img alt="ALTBalaji" title="Logo" style="display:block;" align="right" width="auto" height="auto" src="<?php echo base_url();?>uploads/logo.png">
                          </td>
                        </tr>
                      </table>
                    </td>
                    <td width="10%"></td>
                  </tr>
                </table>
              </td>
            </tr><!--second tr of blur table-->
            <!-- <tr><td height="40"></td></tr> --><!--3rd tr of blur table-->
            <tr>
              <td>
                <table width="100%">
                    <tr>
                      <td width="10%"></td>
                      <td width="80%">
                        <table width="100%">
                          <tr><td height="15"></td></tr>
                          <tr><td style="color:#000">Hello,</td></tr>
                          <tr><td height=""></td></tr>
                          <tr>
                            <td style="color:#000">
                              
                            </td>
                          </tr>
                          <tr><td height=""></td></tr>
                          
                          
                          <tr>
                            <td>
                              <table width="100%" style="color:#000">
                                <tr>
                                  <td >Date: <?php echo date('d-M-Y');?></td>
                                  <td></td>
                                </tr>
                                <tr><td height="5"></td></tr>
                                <tr>
                                  <td colspan="2">
                                    From: <?php echo $message['sender']->name;?>
                                  </td>
                                </tr>
                                <tr><td colspan="2" height="5"></td></tr>                                
                                
                              </table>
                            </td>
                          </tr>
                          <tr><td height="10"></td></tr>
                          <tr>
                            <td>
                           
                              <table width="100%" style="color:#000;border:1px solid;">
                                <tr>
                                  <th style="text-align:left;border-bottom:1px solid;border-right: 1px solid;">Sr. No.</th>
                                  <th style="text-align:left;border-bottom:1px solid;border-right: 1px solid;">File Name</th>
                                  <th style="text-align:left;border-bottom:1px solid;border-right: 1px solid;">File Size</th>
                                  <th style="text-align:left;border-bottom:1px solid;border-right: 1px solid;">Validity</th>
                                  <th style="text-align:left;border-bottom:1px solid;border-right: 1px solid;">Download Limit</th>
                                  <th style="text-align:left;border-bottom:1px solid;">Download Link</th>
                                </tr>
                             <?php
                              $i=1;
                              $j=0;
                              foreach ($files as $key => $value) {
                                ?>
                                <tr>
                                <td style="border-bottom:1px solid;border-right: 1px solid;">
                                <?php echo $i++; ?>
                                </td>
                                <td style="border-bottom:1px solid;border-right: 1px solid;">
                                <?php echo $value; ?>
                                </td>
                                <td style="border-bottom:1px solid;border-right: 1px solid;">
                                <?php echo file_size($value); ?>
                                </td>
                                <td style="border-bottom:1px solid;border-right: 1px solid;">
                                <?php
                                $today=date('d-m-Y');
                                $date=$message['files']['validity'];
                                $next_date= date('d-M-Y', strtotime($today. ' + '.$date.' days'));
                                echo $next_date;
                                ?>
                                </td>
                                <td style="border-bottom:1px solid;border-right: 1px solid;">
                                <?php if($message['files']['onetime']==1) { echo "One time" ; } else { echo "unlimited"; } ?>
                                </td>
                                <td style="border-bottom:1px solid;border-right: 1px solid;">
                                 <a href="<?php echo $baseurl;?>files/accessfiles/<?php echo $message['user']->user_id;?>/<?php echo base64_encode($message['files']['files_id']);?>/<?php echo $value; ?>">Download</a>
                                <!-- <a href="<?php echo base_url();?>files/download/<?php echo $message['user']->user_id;?>?filename=<?php echo trim($value);?>">Download</a> -->
                                </td>
                                  
                                </tr>
                                <?php
                                $j++;
                              }
                              ?>
                              </table>
                            </td>
                          </tr>
                          <tr><td height="20"></td></tr>
                          
                          <tr>
                            <td style="font-size:16px;color:#000"><a href="www.altbalaji.com">ALTbalaji</a></td>
                          </tr>
                          <tr><td height="10"></td></tr>
                          <tr><td style="color:#000;font-size:16px;"></td></tr>
                          <tr><td height="20"></td></tr>
                          
                        </table>
                      </td>
                      <td width="10%"></td>
                    </tr>
                </table>
              </td>
            </tr><!--4th tr of blur table-->
           <!--  <tr>
              <td>
                <img alt="ALTBalaji" title="Logo" style="display:block;" width="200" height="87" src="<?php echo base_url();?>uploads/line.gif">
              </td>
            </tr> --><!--5th tr of blur table-->
             
          </table><!--inside table with blur bg-->
        </td>
      </tr>
    </table><!--main table with black bg-->
                              </body>
                            </html>

