<?php  
	
    $this->load->view($template);
?>