<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
$lang['error_noMail'] = "You must submit a valid email address336434545";
$lang['success_noUser'] = "You must submit a username2324";
$lang['general_noUser'] = "You must submit a username2324";
$lang['warning_noUser'] = "You must submit a username4235235";
$lang['information_noUser'] = "You must submit a username436436";
$lang['information_settings_config'] = "* Some settings will affect after reloading the page 2545bgvjhg";
