<?php 

function asset_url()
{
  return base_url().'assets/';
}
function admin_asset()
{
  return base_url().'admin-assets/';
}
function admin_url()
{
  return base_url().'admin/';
}
function get_data($table,$condition,$get,$return){
    $ci=& get_instance();
    $ci->load->database();
    $data=$ci->db->query("select `$return` from $table where `$get`='$condition'");
    return $data->row()->$return;
}

function getExcerpt($str, $maxLength=100) {
	if(strlen($str) > $maxLength) {
		$excerpt   = substr($str, 0, $maxLength-3);
		$lastSpace = strrpos($excerpt, ' ');
		$excerpt   = substr($excerpt, 0, $lastSpace);
		$excerpt  .= '...';
	} else {
		$excerpt = $str;
	}
	
	return $excerpt;
}

function formatBytes($bytes,$unit="",$dec=2) { 
    $size   = array('B', 'kB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB');
    $factor = floor((strlen($bytes) - 1) / 3);

    return sprintf("%.{$dec}f", $bytes / pow(1024, $factor)) . @$size[$factor];
}

function formatBytesboth($bytes,$unit="",$dec=2) { 
    $size   = array('B', 'kB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB');
    $factor = floor((strlen($bytes) - 1) / 3);

    $return['value']=sprintf("%.{$dec}f", $bytes / pow(1024, $factor));
    $return['factor']=@$size[$factor];
    return  $return;
} 

function file_size($file_name){
  
      $abc= filesize("./server/php/files/".trim($file_name));
      return formatBytes($abc);
    }


function checkdownload($filename,$user_id,$files_id){
      $ci=& get_instance();
      $ci->load->database();
     
      $data=$ci->db->query("select onetime from files where `files_id`='$files_id'");    
      
      if($data->num_rows()>0)
      {
        $data=$data->row();
        if($data->onetime==1)
        {
            $data=$ci->db->query("select * from download where `filename`='$filename' and user_id='$user_id'");    
           
            if($data->num_rows()<=0){
              //echo "string";
              return false;
            }
            else{
              return true;
            }          
        }
        else
        {
          return false;
        }
      }
    }

function produce_input($type,$name,$token="",$values=""){
    if($values!=""){ $val=explode(",", $values); }
    switch ($type) {
      case 'radiotoggle':
        ?>
        <div data-toggle="buttons" class="btn-group">
          <?php
          foreach ($val as $key => $value) {
           ?>
           <label class="btn <?php echo $token==$value?'active':''?>">
            <input type="radio" <?php echo $token==$value?"checked":""?> autocomplete="off" id="option1" name="<?php echo $name;?>" value="<?php echo $value;?>"> <?php echo ucfirst($value);?>
          </label>
           <?php
          }
          ?>
        </div>
        <?php
        break;
      
      default:
        # code...
        break;
    }
}


function showtime($time2){
    // echo $time2;
    $time =   time() - $time2 ; // to get the time since that moment

    $tokens = array (
    31536000 => 'year',
    2592000 => 'month',
    604800 => 'week',
    86400 => 'day',
    3600 => 'hour',
    60 => 'minute',
    1 => 'second'
    );

    foreach ($tokens as $unit => $text) {
      if ($time < $unit) continue;
      $numberOfUnits = floor($time / $unit);
      return $numberOfUnits.' '.$text.(($numberOfUnits>1)?'s ago':' ago');
    }
}

function generatedatetime($date){
$ci =& get_instance();
return date($ci->config->item('general_datetimeformat'),strtotime($date)) ;
}

function generatedate($date){
$ci =& get_instance();  
return date($ci->config->item('general_dateformat'),strtotime($date)) ;
}

