<?php
ini_set('max_execution_time', 0); 
ini_set('memory_limit','2048M');
class MY_Controller extends CI_Controller
{
    
    public function __construct()
    {
        
        parent::__construct();
        ini_set('memory_limit', '128M');
        ini_set('set_time_imit',30000);
        $this->load->driver('session');
        $this->load->helper('file');
        $this->lang->load('general_lang', 'english');
        
        //Settings Model for LOGO TITLE ETC..
        $this->load->model('User_model','user_model');
        $this->load->model('Package_model','package_model');
        
        //CHECK REMEMBER ME

        //check for licence

        //$this->checklicencelocal();

    }

    public function get_user_template($template,$data=""){
        $user_id=$this->is_logged_in();
        $query=$this->db->query("select * from user where user_id='$user_id'");
        $data["logged_in_user"]=$query->row();
        $data["site_settings"]=$this->user_model->configuration();
        if($this->is_logged_in()!=false){            
        //$data["package_data"]=$this->package_model->get_details($data["logged_in_user"]->package_id);
        }
        $data['template']=TEMPLATE_NAME.'/'.$template;
        $this->load->view('template',$data);
    }
    

    public function get_user_template_ajax($template,$data=""){
        $data['template']=TEMPLATE_NAME.'/ajax/'.$template;
        $this->load->view('template-ajax',$data);
    }

    public function get_admin_template($template,$data=""){
        $data['template']=TEMPLATE_ADMIN_NAME.'/'.$template;
        $this->load->view('template-admin',$data);
    }

    public function get_admin_template_ajax($template,$data=""){
        $data['template']=TEMPLATE_ADMIN_NAME.'/'.$template;
        $this->load->view('template-admin-ajax',$data);
    }
    
    public function is_logged_in()
    {
        $user = $this->session->userdata('user_id');
        $this->config->set_item('user_id',$user);
        if(isset($user))
            return $user;
        else
            return false;
    }

    public function is_admin_logged_in()
    {
        $adminuser = $this->session->userdata('admin_id');
        $this->config->set_item('admin_id',$adminuser);
        if(isset($adminuser))
            return $adminuser;
        else
            return false;
    }
   
    
    function get_name($table,$condition,$get,$return){
        $data=$this->db->query("select `$return` from $table where `$get`='$condition'");
        return $data;
    }


    function check_access(){
        $user=$this->is_logged_in();
        if($user==false){
            return false;
        }
        else{
            // else check for access
            return $user;
        }

  
    }
    





    public function checklicence()
    {       
        
            $licenceinfo=$this->db->get("licence")->row();  
            $ch = curl_init();

            curl_setopt($ch, CURLOPT_URL,"http://dtransfer.afterdoor.com/api/getlicense");
            curl_setopt($ch, CURLOPT_POST, 1);
             curl_setopt($ch, CURLOPT_POSTFIELDS, 
                      http_build_query(array('license_id' => $licenceinfo->licence_id))); //replace licence id
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

            $server_output = curl_exec ($ch);

            curl_close ($ch);
            $licence=(json_decode($server_output));
            $updatearray = array(
                'domains' => $licence->LC_Domains, 
                'startdate' => $licence->LC_Startdate, 
                'enddate' => $licence->LC_Enddate, 
                'packagename' => $licence->Pkg_name, 
                'status' => $licence->LC_Status, 
                'key' => $licence->LC_Key, 
                );
            $this->db->where("licence_id", $licenceinfo->licence_id)->update("licence",$updatearray);
        
    }
    

    public function checklicencelocal(){
        $this->checklicence();
        $data['licence']=$this->db->select("*")->get("licence")->row();
        if($data['licence']->status!="activated"){
            echo "<h3 style='color:red;text-align:center'>This licence is ".ucfirst($data['licence']->status)."<h3>";
        die();
        }
    }   
}

