<?php
class MY_Model extends CI_Model
{
	public $settings;
    public function __construct()
    {
        parent::__construct(); 
        global $settings;
          
		
    }

    public function settings()
    {
    	
    }
}