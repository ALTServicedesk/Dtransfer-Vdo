<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
$config['general_sitetitle'] = "ALT Digital Media Entertainment Limited";
$config['general_copyright'] = "© ALT Digital Media Entertainment Limited";
$config['user_allow_signup'] = "yes";
$config['general_dateformat'] = "d-m-Y";
$config['general_datetimeformat'] = "d-M-Y H:m:s";
$config['user_allow_otp_phone'] = "no";
$config['user_allow_otp_email'] = "no";
$config['user_domain_restriction'] = "no";
