<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Test extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		$this->load->library('ftp');

		$config['hostname'] = '127.0.0.1';
		$config['username'] = 'user';
		$config['password'] = 'after456door';
		$config['port']     = 14147;
		$config['debug']        = TRUE;

		$this->ftp->connect($config);

		//$this->ftp->upload('./ubuntu-15.04-desktop-amd64.iso', '/ubuntu-15.04-desktop-amd64.iso', 'ascii', 0775);

		$this->ftp->close();
	}
	public function mailrecord(){/*
		$this->load->model('Ouremail','ouremail');
		$value="info@afterdoor.com";
		$senddatanewuser = array(
				            	'password' =>"11",
				            	'email' => "info@afterdoor.com",
				            	'user_id' => "1",
				            	 );
				            $this->ouremail->sendemail("You have been signed up","welcomenew",$senddatanewuser,$value);*/

				            log_message('info', 'Email success.','email');
	}

function ldapse(){
		$adServer = "192.168.0.150";
        $ldap = ldap_connect($adServer);
        $ldaprdn = 'dc=domain,dc=local';

        ldap_set_option($ldap, LDAP_OPT_PROTOCOL_VERSION, 3);
        ldap_set_option($ldap, LDAP_OPT_REFERRALS, 0);

        $bind = @ldap_bind($ldap, "dtransfer@domain.local", "Daman0587");
        if ($bind) {
           $result = ldap_search($ldap,$ldaprdn, "(&(objectCategory=user))") or die ("Error in search query: ".ldap_error($ldap));
        $data = ldap_get_entries($ldap, $result);
       
        // SHOW ALL DATA
         //var_dump($data[5]['userprincipalname'][0]);
        echo "<pre>";
         var_dump($data);
        $emails = array();
       for ($i=0; $i<$data["count"]; $i++) {
       	$emails[$i]=$data[$i]["userprincipalname"][0];
       }
       echo '<h1>Dump all data</h1><pre>';
        var_dump($emails);   
        echo '</pre>';
       
       if(in_array("manish@domain.local", $emails)){
       	echo "found";
       }
        // iterate over array and print data for each entry
        echo '<h1>Show me the users</h1>';
        for ($i=0; $i<$data["count"]; $i++) {
        	/*echo "<pre>";
        	var_dump($data[$i]);
        	echo "</pre>";*/
            //echo "dn is: ". $data[$i]["dn"] ."<br />";
            echo "User: ". $data[$i]["cn"][0] ."<br />";
            if(isset($data[$i]["userprincipalname"][0])) {
                echo "Email: ". $data[$i]["userprincipalname"][0] ."<br /><br />";
            } else {
                echo "Email: None<br /><br />";
            }
        }
        // print number of entries found
        echo "Number of entries found: " . ldap_count_entries($ldapconn, $result);
        } 
        else {
          echo "0";
        }
	}
}
