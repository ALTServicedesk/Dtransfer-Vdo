<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Logs extends My_Controller {

	function __construct()
	{
		parent::__construct();
        $this->load->model('User_model','user_model');
        $this->load->model('Logs_model','logs_model');

	}

	public function index()
	{
		$data['home']=true;
		if (check_access()!=false) {
			redirect("user/dashboard");
		}
		else
			redirect("user/login");
	}

	public function otp()
	{		
		if (check_access()!=false) {
			$data['user']=$this->user_model->get_user(check_access());
			$data['allotp']=$this->logs_model->allotp();
			$this->get_user_template('allotp',$data);			
		}
		else
			redirect("user/login");
	}

	public function download()
	{		
		if (check_access()!=false) {
			$data['user']=$this->user_model->get_user(check_access());
			$data['downloadlogs']=$this->logs_model->downloadlogs();
			$this->get_user_template('downloadlogs',$data);			
		}
		else
			redirect("user/login");
	}


	public function readlogs($type)
	{		
		if ($this->is_logged_in()!=false) {
			$data['user']=$this->user_model->get_user($this->is_logged_in());
			$data['errorlogs']=$this->logs_model->readlogs($type);

			function sortfilenames(&$array, $subfield)
	        {
	            $sortarray = array();
	            foreach ($array as $key => $row)
	            {

	                $sortarray[$key]['filemtime'] = $row[$subfield];
	                $sortarray[$key]['filesize'] = $row['filesize'];
	                $sortarray[$key]['filename'] = $row['filename'];

	            }
	             array_multisort($sortarray, SORT_DESC, $array);
	           return $sortarray;
	        }			
			$data['heading']=ucfirst($type)." Logs";
			$data['errorlogs']=sortfilenames($data['errorlogs'],"filemtime");
			$this->get_user_template('logs',$data);			
		}
		else
			redirect("user/login");
	}


	public function getlogfile()
	{		
		if ($this->is_logged_in()!=false) {
			$file = file(FCPATH."application/logs/".$this->input->post("logfilename"));
			$file = array_reverse($file);
			foreach($file as $f){
			    echo $f."<br />";
			}		
		}
		else
			redirect("user/login");
	}
	
	
}
