<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Licence extends My_Controller {

	function __construct()
	{
		parent::__construct();
        $this->load->model('User_model','user_model');
        $this->load->model('Reports_model','reports_model');

	}

	public function index()
	{
		$data['home']=true;
		if (check_access()!=false) {
			redirect("user/dashboard");
		}
		else
			redirect("user/login");
	}


	public function checklicence()
	{		
		
			$licenceinfo=$this->db->get("licence")->row();	
			$ch = curl_init();

			curl_setopt($ch, CURLOPT_URL,"http://dtransfer.afterdoor.com/api/getlicense");
			curl_setopt($ch, CURLOPT_POST, 1);
			 curl_setopt($ch, CURLOPT_POSTFIELDS, 
			          http_build_query(array('license_id' => $licenceinfo->licence_id))); //replace licence id
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

			$server_output = curl_exec ($ch);

			curl_close ($ch);
			$licence=(json_decode($server_output));
			$updatearray = array(
				'domains' => $licence->LC_Domains, 
				'startdate' => $licence->LC_Startdate, 
				'enddate' => $licence->LC_Enddate, 
				'packagename' => $licence->Pkg_name, 
				'status' => $licence->LC_Status, 
				'key' => $licence->LC_key, 
				);
			$this->db->where("licence_id", $licenceinfo->licence_id)->update("licence",$updatearray);
		
	}
	

	public function checklicencelocal(){
		$this->checklicence();
		$data['licence']=$this->db->select("*")->get("licence")->row();
		if($data['licence']->status=="deactivated"){
			echo "expired";
		die();
		}
	}	
}
