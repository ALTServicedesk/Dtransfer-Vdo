<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Settings extends My_Controller {

	function __construct()
	{
		parent::__construct();
        $this->load->model('Settings_model','settings');
	}
	
	public function index()
	{
		if (check_access()!=false) {
			redirect("user/dashboard");
		}
		else
			redirect("user/login");
	}

	public function messages()
	{
		if ($this->check_access()!=false) {
			$data['language']=$this->settings->getallmessages();
			$this->get_user_template('settings_language',$data);
		}
		else
			redirect("user/login");
	}

	public function savemessages()
	{
		if ($this->check_access()!=false) {
			$data['messages']=$this->settings->savemessages();
			//var_dump($this->input->post());
		}
		else
			redirect("user/login");
	}

	public function siteconfig()
	{
		if ($this->check_access()!=false) {
			$data['config']=$this->settings->getsiteconfig();
			$this->get_user_template('settings_config',$data);
		}
		else
			redirect("user/login");
	}

	public function saveconfig()
	{
		if ($this->check_access()!=false) {
			$data['messages']=$this->settings->saveconfig();
			//var_dump($this->input->post());
		}
		else
			redirect("user/login");
	}

	public function backup()
	{
		if ($this->check_access()!=false) {
			$this->load->helper('directory');
			$data['files'] = directory_map('./backups/');
			$this->get_user_template('backup',$data);
		}
		else
			redirect("user/login");
	}

	public function createbackup()
	{
		if ($this->check_access()!=false) {
			// Load the DB utility class
			$this->load->dbutil();
			$filename=date("d_m_Y_h_m_s").".sql";
			$prefs = array(                   
		        'format'        => 'txt', 
		        'filename'      => $filename, 
		        'add_drop'      => TRUE,                       
		        'add_insert'    => TRUE,       
		        'newline'       => "\n"      
			);
			// Backup your entire database and assign it to a variable
			$backup = $this->dbutil->backup($prefs);
			$path= base_url().'backups/'.$prefs['filename'];
			// Load the file helper and write the file to your server
			$this->load->helper('file');

			write_file('./backups/'.$prefs['filename'], $backup);
			
			// Load the download helper and send the file to your desktop
			$this->load->helper('download');
			force_download($prefs['filename'], $backup);
			//redirect("settings/backup");
		}
		else
			redirect("user/login");
	}

	public function restorebackup($filename){
	  $backup = file_get_contents('./backups/'.$filename);
	  $sql_clean = '';
                foreach (explode("\n", $backup) as $line){
                    if(isset($line[0]) && $line[0] != "#"){
                        $sql_clean .= $line."\n";
                    }
                }
                foreach (explode(";\n", $sql_clean) as $sql){
                    $sql = trim($sql);
                    if($sql)
                    {
                        $this->db->query($sql);
                    }
                }
			$this->session->set_flashdata("backupmsg","<p class='alert alert-success'>Backup restored.</p>");
           redirect("settings/backup");
	}	

	public function licence(){
		$data['licence']=$this->db->select("*")->get("licence")->row();
		$this->get_user_template('licence',$data);
	}

	public function updates(){
		$licenceinfo=$this->db->get("licence")->row();  
            $ch = curl_init();

            curl_setopt($ch, CURLOPT_URL,"http://dtransfer.afterdoor.com/api/checkUpdate");
            curl_setopt($ch, CURLOPT_POST, 1);
             curl_setopt($ch, CURLOPT_POSTFIELDS, 
                      http_build_query(array('licenseid' => $licenceinfo->licence_id,'version' => $licenceinfo->curver))); //replace licence id
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

            $data['server_output'] = curl_exec ($ch);

            curl_close ($ch);
			
			$data['licence']=$this->db->select("*")->get("licence")->row();
            
			$this->get_user_template('updates',$data);
	}

	public function smtpsettings(){
		if ($this->is_logged_in()!=false) {
			$data['user']=$this->user_model->get_user($this->is_logged_in());
			$data['settings']=$this->user_model->configuration();
			$this->form_validation->set_error_delimiters('<div class="error" style="color:red">', '</div>');
		    	$config = array(
			        
			        
			        array(
			                'field' => 'smtphost',
			                'label' => 'SMTP Host',
			                'rules' => 'required'
			        ),
			        array(
			                'field' => 'smtpport',
			                'label' => 'SMTP Port',
			                'rules' => 'required'
			        ),
			        array(
			                'field' => 'smtpuser',
			                'label' => 'SMTP User',
			                'rules' => 'required'
			        ),
			        array(
			                'field' => 'smtppass',
			                'label' => 'SMTP Password',
			                'rules' => 'required'
			        )
				);
				$this->form_validation->set_rules($config);
			    if ($this->form_validation->run() == FALSE)
				{
					$this->get_user_template('smtpsettings',$data);
				}
				else
				{
					$data['message']=$this->user_model->updatesmtp();
						if($data['message']==true){ 
							$data['settings']=$this->user_model->configuration();

							
							$this->get_user_template('smtpsettings',$data);
						}
				}
		}
		else{
			redirect("user/login");
		}
	}
	public function ldap(){
		if ($this->is_logged_in()!=false) {
			$data['value']=$this->user_model->ldap();
			$this->get_user_template('ldap',$data);
		}
		else{
			redirect("user/login");
		}
	}
	function CheckConnection(){
		if ($this->is_logged_in()!=false) {

		$host=$this->input->post('host');
		$port=$this->input->post('port');
		$username=$this->input->post('username');
		$password=$this->input->post('password');
		$domain=$this->input->post('domains');
		$this->user_model->checkconnection($host,$port,$username,$password,$domain);
	}else{
		redirect("user/login");
	}

	}
	function ldapupdate()
	{
		$this->user_model->updateldap();
		$data['value']=$this->user_model->ldap();
		$this->session->set_flashdata("linkmessage","<p class='alert alert-success' style='margin-top:-4px;margin-bottom:3px;margin-left: -15px;'>Ldap Updated.</p>");
		$this->get_admin_template('ldap',$data);
	}
	function General(){
		if ($this->is_logged_in()!=false) {
			$data['value']=$this->user_model->general();
			$this->get_user_template('general',$data);
		}
	}
	function updategeneral(){
		if ($this->is_logged_in()!=false) {
			$this->user_model->UpdateGeneral();
			
		}
	}
}//class

