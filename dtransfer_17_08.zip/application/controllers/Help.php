<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Help extends My_Controller {

	function __construct()
	{
		parent::__construct();
        $this->load->model('Settings_model','settings');
        $this->load->model('Help_model','help');
        $this->load->model('User_model','user_model');

	}
	
	public function index()
	{
		if (check_access()!=false) {
			redirect("user/dashboard");
		}
		else
			redirect("user/login");
	}

	public function messages()
	{
		if ($this->check_access()!=false) {
			$data['language']=$this->settings->getallmessages();
			$this->get_user_template('settings_language',$data);
		}
		else
			redirect("user/login");
	}

	public function submitticket(){

		//echo'hello'; die;
		if ($this->check_access()!=false) {
		 $data['user']=$this->user_model->get_user($this->is_logged_in());

		  $data['allusers']=$this->user_model->get_all_user();
		/*echo'<pre>';
		 print_r($data);die;*/

		 $this->form_validation->set_rules('department', 'department', 'trim|required');
         $this->form_validation->set_rules('subject', 'subject', 'trim|required');
         $this->form_validation->set_rules('priority', 'priority', 'trim|required');
         $this->form_validation->set_rules('description', 'description', 'trim|required');
         //$this->form_validation->set_rules('status', 'status', 'trim|required');
         if ($this->form_validation->run() == FALSE)
            {
             // $data['licenceid']=$this->help->getLiscenceID();
			  //echo'<pre>';print_r($data['licenceid']);die;
			  $this->get_user_template('submit_help',$data);
            }
            else
            {
            
                $data = array(
                               // 'ST_ID' => $st_id,
                                'help_department' => $this->input->post('department'),
                                'help_subject' => $this->input->post('subject'),
                                'help_priority' => $this->input->post('priority'),
                                'help_description'=>$this->input->post('description'),
                               // 'help_status'=>$this->input->post('status'),
                                'help_userid'  => $this->input->post('userid')
                            );
               // print_r($data);die;
					  // insert form data into database
                if ($this->help->insertTickets($data))
                {
                        // successfully sent mail
                        $this->session->set_flashdata('msg','<div class="alert alert-success text-center">Ticket Successfully added!! </div>');
                        redirect('/help/submitticket');
                   
                }
                else
                {
                    // error
                    $this->session->set_flashdata('msg','<div class="alert alert-danger text-center">Oops! Error.  Please try again later!!!</div>');
                    redirect('/help/submitticket');
                }

                //redirect("help/alltickets");
                          
                    /* Start Uploading File */
                    /* $config =   [
                                 'upload_path'   => './uploads/',
                                    'allowed_types' => 'doc|docx|pdf',
                                    'max_size'      => 500000,
                                    'max_width'     => 10240,
                                    'max_height'    => 7680
                                 ];

                   $this->load->library('upload', $config);
                    $image1 = $this->input->post('ticketfile');
                   
                   */

            }
			
		}
		else
			redirect("user/login");

	}

	public function alltickets()
	{
		if ($this->check_access()!=false) {
			//$data['messages']=$this->settings->savemessages();
			$data['alltickets'] = $this->help->alltickets();
			$data['current_user'] =$this->user_model->get_user($this->is_logged_in());

			//echo'<pre>';print_r($data);die;
			$this->get_user_template('allhelptickets',$data);
		}
		else
			redirect("user/login");
	}

	public function singleticket()
	{
		if ($this->check_access()!=false) {
			$data['current_user'] = $this->user_model->get_user($this->is_logged_in());
			if($data['current_user']->type == 3){
				$data['alluser'] = $this->user_model->get_all_user();
			}
			 $hid = $this->uri->segment(3);
			 $data['singleticket'] = $this->help->getsingleticket($hid);
       		 $data['replies'] = $this->help->getreplies($hid);
			$this->get_user_template('singlehelp',$data);
		}
		else
			redirect("user/login");
	}

	public function ticketreply(){

		 $this->form_validation->set_rules('description', 'description', 'trim|required');
         $this->form_validation->set_rules('ticketid', 'ticketid', 'trim|required');
         $data['user']=$this->user_model->get_user($this->is_logged_in());
         //print_r($data); die;
         $tkid = $this->input->post('ticketid');
         if ($this->form_validation->run() == FALSE)
            {
                // fails
                redirect("support/singleticket/".$tkid);
            }
            else
            {
            	
            
                $data = array(
                                'help_id' => $this->input->post('ticketid'),
                                'description'=>$this->input->post('description'),
                                'user_id'  => $data['user']->user_id,
                            );
                 // insert form data into database
                if ($this->help->addreply($data))
                {
                        // successfully sent mail
                        $this->session->set_flashdata('msg','<div class="alert alert-success text-center">You Have Successfully updated Your Articles! </div>');
                         redirect("help/singleticket/".$tkid);
                   
                }
                else
                {
                    // error
                    $this->session->set_flashdata('msg','<div class="alert alert-danger text-center">Oops! Error.  Please try again later!!!</div>');
                     redirect("help/singleticket/".$tkid);
                }

                //redirect("support/singleticket/".$tkid);
                          
                     

            }

	}

    public function changeStatus(){
         $this->form_validation->set_rules('status', 'status','trim|required');
          $tid =  $this->input->post('helpid');
            if ($this->form_validation->run() == FALSE)
            {
                 redirect('/help/singleticket/'.$tid);
            }            
            else{
                  // $tid =  $this->input->post('ticketid');
                $data = array(
                                'help_status' => $this->input->post('status'),
                               
                            );
                   //   print_r($data);die;
                            // insert form data into database
                
                if ($this->help->changeStatus($data, $tid))
                {
                        // successfully sent mail
                        $this->session->set_flashdata('msg','<div class="alert alert-success text-center">Status Changed !! </div>');
                        redirect('/help/singleticket/'.$tid);
                   
                }
                else
                {
                    // error
                    $this->session->set_flashdata('msg','<div class="alert alert-danger text-center">Oops! Error.  Please try again later!!!</div>');
                    redirect('/help/singleticket/'.$tid);
                }
                        
            }

        }

}
