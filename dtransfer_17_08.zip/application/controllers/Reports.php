<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Reports extends My_Controller {

	function __construct()
	{
		parent::__construct();
        $this->load->model('User_model','user_model');
        $this->load->model('Reports_model','reports_model');

	}

	public function index()
	{
		$data['home']=true;
		if (check_access()!=false) {
			redirect("user/dashboard");
		}
		else
			redirect("user/login");
	}


	public function uploads()
	{		
		if ($this->is_logged_in()!=false) {
			$data['users']=$this->user_model->get_all_user();
			$this->get_user_template('uploadReport',$data);	
		}
		else
			redirect("user/login");
	}

	public function downloads()
	{		
		if ($this->is_logged_in()!=false) {
			$data['users']=$this->user_model->get_all_user();
			$this->get_user_template('downloadReport',$data);	
		}
		else
			redirect("user/login");
	}

	public function storage()
	{		
		if ($this->is_logged_in()!=false) {
			$data['users']=$this->user_model->get_all_user();
			$this->get_user_template('storageReport',$data);	
		}
		else
			redirect("user/login");
	}

	public function generateuploads()
	{		
		if ($this->is_logged_in()!=false) {
				$user = $this->input->post('user_id');
			   $date_array =  explode('-', $this->input->post('date'));
               $date1 = str_replace('/','-', $date_array[0]);
               $date2 = str_replace('/','-', $date_array[1]);

              //echo strtotime($date1);
                $d1 = date('Y-m-d', strtotime($date1));
                $d1 = str_replace('-', '/', $d1);
                $d2 = date('Y-m-d', strtotime($date2));
                $d2 = str_replace('-', '/', $d2);
                $data['startdate']=$d1;
                $data['enddate']=$d2;
                $data['user'] = $user;
                //print_r($data);die;
                $result = array();
                $result['details'] =  $this->reports_model->generateuploads($data);
               // print_r($reult);die;
			   $this->get_user_template('generateuploadReport',$result);	
		}
		else
			redirect("user/login");
	}
	
	public function generatedownloads()
	{		
		if ($this->is_logged_in()!=false) {
				$user = $this->input->post('user_id');
			   $date_array =  explode('-', $this->input->post('date'));
               $date1 = str_replace('/','-', $date_array[0]);
               $date2 = str_replace('/','-', $date_array[1]);

              //echo strtotime($date1);
                $d1 = date('Y-m-d', strtotime($date1));
                $d1 = str_replace('-', '/', $d1);
                $d2 = date('Y-m-d', strtotime($date2));
                $d2 = str_replace('-', '/', $d2);
                $data['startdate']=$d1;
                $data['enddate']=$d2;
                $data['user'] = $user;
                //print_r($data);die;
                $result = array();
                $result['details'] =  $this->reports_model->generatedownloads($data);
               // print_r($reult);die;
			   $this->get_user_template('generatedownloadReport',$result);	
		}
		else
			redirect("user/login");
	}

	public function generatestorage()
	{		
		if ($this->is_logged_in()!=false) {
				$user = $this->input->post('user_id');
			   $date_array =  explode('-', $this->input->post('date'));
               $date1 = str_replace('/','-', $date_array[0]);
               $date2 = str_replace('/','-', $date_array[1]);

              //echo strtotime($date1);
                $d1 = date('Y-m-d', strtotime($date1));
                $d1 = str_replace('-', '/', $d1);
                $d2 = date('Y-m-d', strtotime($date2));
                $d2 = str_replace('-', '/', $d2);
                $data['startdate']=$d1;
                $data['enddate']=$d2;
                $data['user'] = $user;
                //print_r($data);die;
                $result = array();
                $result['details'] =  $this->reports_model->generatestorage($data);
               // print_r($reult);die;
			   $this->get_user_template('generatestorageReport',$result);	
		}
		else
			redirect("user/login");
	} 

}
