<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Packages extends My_Controller {

	function __construct()
	{
		parent::__construct();
        $this->load->model('Package_model','package');

	}
	
	public function index()
	{
		//$data['home']=true;
		if ($this->is_logged_in()!=false) {
			redirect("user/dashboard");
		}
		else
			$this->get_user_template('index',$data);
	}

	public function add(){
		//$data['home']=true;
		$data['user']=$this->user_model->get_user($this->is_logged_in());

		if ($this->is_logged_in()!=false) {
			$this->form_validation->set_error_delimiters('<div class="error" style="color:red">', '</div>');
		    	$config = array(
			        
			        
			        array(
			                'field' => 'name',
			                'label' => 'Package Name',
			                'rules' => 'required'
			        ),
			        array(
			                'field' => 'price',
			                'label' => 'Package Cost',
			                'rules' => 'required|is_numeric'
			        ),
			        array(
			                'field' => 'size',
			                'label' => 'Disk size allowed',
			                'rules' => 'required|is_numeric'
			        ),
			        array(
			                'field' => 'packageorder',
			                'label' => 'Package order',
			                'rules' => 'required|is_numeric'
			        ),
			         array(
			                'field' => 'bandwidth',
			                'label' => 'Bandwidth',
			                'rules' => 'required|is_numeric'
			        ),
			          array(
			                'field' => 'validity',
			                'label' => 'Package Validity',
			                'rules' => 'required'
			        ),
			        
				);
				$this->form_validation->set_rules($config);
			    if ($this->form_validation->run() == FALSE)
				{
					$this->get_user_template('package_add',$data);
				}
				else
				{
					$data['message']=$this->package->package_add();
						if($data['message']==true){ 
							
							redirect("packages/all");
						}
				}
		}
		else{
			redirect("user/login");
		}
	}


	public function edit($id=""){
		//$data['home']=true;
		$data['user']=$this->user_model->get_user($this->is_logged_in());

		if ($this->is_logged_in()!=false) {
			$this->form_validation->set_error_delimiters('<div class="error" style="color:red">', '</div>');
		    	$config = array(
			        
			        
			        array(
			                'field' => 'name',
			                'label' => 'Package Name',
			                'rules' => 'required'
			        ),
			        array(
			                'field' => 'price',
			                'label' => 'Package Cost',
			                'rules' => 'required|is_numeric'
			        ),
			        array(
			                'field' => 'size',
			                'label' => 'Disk size allowed',
			                'rules' => 'required|is_numeric'
			        ),
			        array(
			                'field' => 'packageorder',
			                'label' => 'Package order',
			                'rules' => 'required|is_numeric'
			        ),
			         array(
			                'field' => 'bandwidth',
			                'label' => 'Bandwidth',
			                'rules' => 'required|is_numeric'
			        ),
			          array(
			                'field' => 'validity',
			                'label' => 'Package Validity',
			                'rules' => 'required'
			        ),
			          
			        
				);
				$this->form_validation->set_rules($config);
			    if ($this->form_validation->run() == FALSE)
				{
					$data['package']=$this->package->get_details($id);
					$this->get_user_template('package_edit',$data);
				}
				else
				{
					$data['message']=$this->package->package_update();
						if($data['message']==true){ 
							
							redirect("packages/all");
						}
				}
		}
		else{
			redirect("user/login");
		}
	}

	public function all(){
		$data['user']=$this->user_model->get_user($this->is_logged_in());
		
		if ($this->is_logged_in()!=false) {
			$data['packages']=$this->package->listallview();
			$this->get_user_template('package_all',$data);
		}
		else{
			redirect("user/login");
		}
	}

	public function viewall(){
		$data['user']=$this->user_model->get_user($this->is_logged_in());
		
		if ($this->is_logged_in()!=false) {
			$data['packages']=$this->package->listall();
			$this->get_user_template('package_view',$data);
		}
		else{
			redirect("user/login");
		}
	}

	public function requestall($type){
		$data['user']=$this->user_model->get_user($this->is_logged_in());
		
		if ($this->is_logged_in()!=false) {
			$data['request']=$this->package->requestall($type);
			$this->get_user_template('requestall',$data);
		}
		else{
			redirect("user/login");
		}
	}

	public function request(){
		$data['user']=$this->user_model->get_user($this->is_logged_in());
		
		if ($this->is_logged_in()!=false) {
			$data = array(
				'package_id' => $this->input->post("packageid"), 
				'message' => $this->input->post("message"), 
				'user_id' => $this->input->post("userid"), 
				);
			$this->db->insert("package_request",$data);
		    $data['user']=$this->user_model->get_user($this->is_logged_in());

			$data['message']="Package change request submitted. We will respond you shortly";
			$data['packages']=$this->package->listall();
			$this->get_user_template('package_view',$data);
		}
		else{
			redirect("user/login");
		}
	}

	public function requestupdate(){
		$request=$this->input->post("packageid");
		$da=$this->db->get_where("package_request",array("package_request_id"=>$request));
		$da=$da->row();
		$package=$this->db->get_where("package",array("package_id"=>$da->package_id));
		$package=$package->row();
		$curdate=date('Y-m-d');
		$expirydate = date('m-d-Y', strtotime("+".$package->validity." months", strtotime($curdate)));		
		$this->db->where("user_id",$da->user_id);
		$this->db->update("user",array("package_id"=>$request,"package_validity"=>$expirydate));
		$this->db->where("package_request_id",$request);
		$this->db->update("package_request",array("status"=>1));

	}
}
