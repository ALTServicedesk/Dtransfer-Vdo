<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Api extends My_Controller {

	function __construct()
	{
		parent::__construct();
       	$this->load->model('User_model','user');

	}

	public function createStatus($status){
		switch ($status) {
			case '200':
				return "Ok";
				break;
			case '400':
				return "Bad request. Parameters missing.";
				break;
			case '401':
				return "Unauthorized. Unable to verify url.";
				break;
			case '404':
				return "Not found.";
				break;
			
			default:
				# code...
				break;
		}
	}

	public function index(){
       	echo "No direct access is allowed.";       
	}

	public function checkUrl($url){
		if($url==md5($this->getDomain())){ return true; } else { return false; }		
	}

	public function getDomain(){
		$pieces = parse_url(base_url());
		  $domain = isset($pieces['host']) ? $pieces['host'] : '';
		  if (preg_match('/(?P<domain>[a-z0-9][a-z0-9\-]{1,63}\.[a-z\.]{2,6})$/i', $domain, $regs)) {
		    return $regs['domain'];
		  }
	}

	public function sendotpapi($type,$user_id){

			$data['user']=$this->user_model->get_user($this->is_logged_in());
			if($type=="mobile")
				$data['messageotp']=$this->user_model->get_otp_mobileapi($user_id,"upload");
			else
				$data['messageotp']=$this->user_model->get_otp_emailapi($user_id,"upload");

			return $data['messageotp'];
	}

	public function login(){
		if($this->checkUrl($this->input->post("url"))){
			
			$user=$this->db->select("*")->where("email",$this->input->post("email"))->where("password",$this->input->post("password"))->get("user");
			if($user->num_rows()>0){
				$user=$user->row();
				$return['data']['login']="true";
				$return['data']['login_txt']="Login successful.";
				$return['data']['name']=$user->name;
				$return['data']['lname']=$user->lname;
				$return['data']['email']=$user->email;
				$return['data']['phone']=$user->phone;
				$return['data']['user_id']=$user->user_id;
				if($user->image=="")
					$return['data']['image']=base_url()."assets/img/avatar-2-64.png";				
				else
					$return['data']['image']=base_url()."uploads/".$user->image;
			}
			else{
				$return['data']['login']="false";
				$return['data']['login_txt']="Email/Password combination incorrect";
			}
				$return['status_code']="200";
				$return['status_txt']=$this->createStatus(200);
		}
		else{
			$return['status_code']="401";
			$return['status_txt']=$this->createStatus(401);
		}

		echo json_encode($return); 
	}


	public function checkRegister(){
		if($this->checkUrl($this->input->post("url"))){			
				$return['data']['register']="true"; // Change this with config variable 
				$return['status_code']="200";
				$return['status_txt']=$this->createStatus(200);
		}
		else{
			$return['status_code']="401";
			$return['status_txt']=$this->createStatus(401);
		}

		echo json_encode($return); 
	}

	public function register(){
		if($this->checkUrl($this->input->post("url"))){		

			$user=$this->db->select("*")->where("email",$this->input->post("email"))->get("user");
			if($user->num_rows()>0){
				$return['data']['register']="false"; 
				$return['data']['register_txt']="Email already exists"; 				
			}
			else{
				$data=array(
						"name" => $this->input->post("name"),
						"lname" => $this->input->post("lname"),
						"email" => $this->input->post("email"),
						"phone" => $this->input->post("phone"),
						"password" => $this->input->post("password"),
						"status" => 0,
						);				
				if ( in_array("", $data,true) || in_array(NULL, $data,true)) {
			    	$return['status_code']="400";
					$return['status_txt']=$this->createStatus(400);
			    }
			    else{
					$return['data']['register']="true"; 
					$return['data']['register_txt']="Registration successful, please check email for validating email"; 
					//insert new					
					$this->db->insert("user",$data);
					$return['data']['user_id']=$this->db->insert_id(); 	
					$return['status_code']="200";
					$return['status_txt']=$this->createStatus(200);		    	
			    }
			}
			
		}
		else{
			$return['status_code']="401";
			$return['status_txt']=$this->createStatus(401);
		}

		echo json_encode($return); 
	}


	public function otp(){
		if($this->checkUrl($this->input->post("url"))){			
				//$return['data']['register']="true"; // Change this with config variable 
			$data = array(
				'user_id' => $this->input->post("user_id"), 
				'type' => $this->input->post("type"), 
				);
			if ( in_array("", $data,true) || in_array(NULL, $data,true)) {
				$return['status_code']="400";
				$return['status_txt']=$this->createStatus(400);
			}
			else{
				$otp="yes"; //change variable here
				if($otp=="yes")
				{
					$return['otp']=true;
					$return['otp_txt']="OTP has been sent";
					//insert OTP
					$return['otpvalue']=$this->sendotpapi($data['type'],$data['user_id']);
					//insert OTP
				}
				else{
					$return['otp']=false;
					$return['otp_txt']="No OTP required";	
				}
					$return['status_code']="200";
					$return['status_txt']=$this->createStatus(200);				
			}
		}
		else{
			$return['status_code']="401";
			$return['status_txt']=$this->createStatus(401);
		}

		echo json_encode($return); 
	}


	public function sendFilesdata(){
		if($this->checkUrl($this->input->post("url"))){		

			$data = array(
				'user_id' => $this->input->post("user_id"), 
				'validity' => $this->input->post("validity"), 
				'onetime' => $this->input->post("onetime"), 
				'filename' => $this->input->post("filename"), 
				'filesize' => $this->input->post("filesize"), 
				'email' => $this->input->post("email"), 
				);

			if ( in_array("", $data,true) || in_array(NULL, $data,true)) {
				/*Upload change*/
				$return['status_code']="400";
				$return['status_txt']=$this->createStatus(400);
			}
			else{

				$return['files']=true;
				$return['files_txt']="Files sent";
				$return['status_code']="200";
				$return['status_txt']=$this->createStatus(200);		    	
			}
			
		}
		else{
			$return['status_code']="401";
			$return['status_txt']=$this->createStatus(401);
		}

		echo json_encode($return); 
	}

	public function deleteFile(){
		if($this->checkUrl($this->input->post("url"))){		

			$data = array(
				'user_id' => $this->input->post("user_id"), 
				'file_id' => $this->input->post("file_id"), 
				);

			if ( in_array("", $data,true) || in_array(NULL, $data,true)) {
				/*Upload change*/
				$return['status_code']="400";
				$return['status_txt']=$this->createStatus(400);
			}
			else{

				$return['data']['files']=true;
				$return['data']['files_txt']="Files removed";
				$return['status_code']="200";
				$return['status_txt']=$this->createStatus(200);		    	
			}
			
		}
		else{
			$return['status_code']="401";
			$return['status_txt']=$this->createStatus(401);
		}

		echo json_encode($return); 
	}

	public function archiveFile(){
		if($this->checkUrl($this->input->post("url"))){		

			$data = array(
				'user_id' => $this->input->post("user_id"), 
				'file_id' => $this->input->post("file_id"), 
				);

			if ( in_array("", $data,true) || in_array(NULL, $data,true)) {
				/*Upload change*/
				$return['status_code']="400";
				$return['status_txt']=$this->createStatus(400);
			}
			else{

				$return['data']['files']=true;
				$return['data']['files_txt']="Archive done";
				$return['status_code']="200";
				$return['status_txt']=$this->createStatus(200);		    	
			}
			
		}
		else{
			$return['status_code']="401";
			$return['status_txt']=$this->createStatus(401);
		}

		echo json_encode($return); 
	}

	public function inbox(){
		if($this->checkUrl($this->input->post("url"))){		

			$data = array(
				'user_id' => $this->input->post("user_id"), 
				);

			if ( in_array("", $data,true) || in_array(NULL, $data,true)) {
				$return['status_code']="400";
				$return['status_txt']=$this->createStatus(400);
			}
			else{
				//get inbox
				$return['data']=$this->user->myfilesreceived($data['user_id']);
				$return['status_code']="200";
				$return['status_txt']=$this->createStatus(200);		    	
			}
			
		}
		else{
			$return['status_code']="401";
			$return['status_txt']=$this->createStatus(401);
		}

		echo json_encode($return); 
	}

	public function sentItems(){
		if($this->checkUrl($this->input->post("url"))){		

			$data = array(
				'user_id' => $this->input->post("user_id"), 
				);

			if ( in_array("", $data,true) || in_array(NULL, $data,true)) {
				$return['status_code']="400";
				$return['status_txt']=$this->createStatus(400);
			}
			else{
				//get inbox
				$return['data']=$this->user->myfilessent($data['user_id']);
				$return['status_code']="200";
				$return['status_txt']=$this->createStatus(200);		    	
			}
			
		}
		else{
			$return['status_code']="401";
			$return['status_txt']=$this->createStatus(401);
		}

		echo json_encode($return); 
	}


	public function getProfile(){
		if($this->checkUrl($this->input->post("url"))){		

			$data = array(
				'user_id' => $this->input->post("user_id"), 
				);

			if ( in_array("", $data,true) || in_array(NULL, $data,true)) {
				$return['status_code']="400";
				$return['status_txt']=$this->createStatus(400);
			}
			else{
				//get inbox
				$return['data']=$this->user->get_user($data['user_id']);
				$return['status_code']="200";
				$return['status_txt']=$this->createStatus(200);		    	
			}
			
		}
		else{
			$return['status_code']="401";
			$return['status_txt']=$this->createStatus(401);
		}

		echo json_encode($return); 
	}



	public function updateProfile(){
		if($this->checkUrl($this->input->post("url"))){		

			$data = array(
				'user_id' => $this->input->post("user_id"), 
				'name' => $this->input->post("name"), 
				'lname' => $this->input->post("lname"), 
				'phone' => $this->input->post("phone"), 
				'email' => $this->input->post("email"), 
				);

			if ( in_array("", $data,true) || in_array(NULL, $data,true)) {
				$return['status_code']="400";
				$return['status_txt']=$this->createStatus(400);
			}
			else{
				//check for correct info
				$user=$this->db->select("user_id")->where(array('user_id' => $data['user_id']))->get("user");
				if($user->num_rows()>0)
				{
					//update password
					$this->db->where(array('user_id' => $data['user_id']))->update("user",$data);
					$return['data']['profile']=true;
					$return['data']['profile_txt']="Profile Updated";
				}
				else{
					$return['data']['profile']=true;
					$return['data']['profile_txt']="No user found.";		
				}
				$return['status_code']="200";
				$return['status_txt']=$this->createStatus(200);		    	
			}
			
		}
		else{
			$return['status_code']="401";
			$return['status_txt']=$this->createStatus(401);
		}

		echo json_encode($return); 
	}

	public function changePassword(){
		if($this->checkUrl($this->input->post("url"))){		

			$data = array(
				'user_id' => $this->input->post("user_id"), 
				'oldpassword' => $this->input->post("oldpassword"), 
				'newpassword' => $this->input->post("newpassword"), 
				);

			if ( in_array("", $data,true) || in_array(NULL, $data,true)) {
				$return['status_code']="400";
				$return['status_txt']=$this->createStatus(400);
			}
			else{
				//check for correct info
				$user=$this->db->select("user_id")->where(array('user_id' => $data['user_id'], 'password' => $data['oldpassword']))->get("user");
				if($user->num_rows()>0)
				{
					//update password
					$this->db->where(array('user_id' => $data['user_id']))->update("user",array('password' => $data['newpassword'] ));
					$return['data']['password']=true;
					$return['data']['password_txt']="Password Changed";
				}
				else{
					$return['data']['password']=true;
					$return['data']['password_txt']="User & Password combination is wrong";		
				}
				$return['status_code']="200";
				$return['status_txt']=$this->createStatus(200);		    	
			}
			
		}
		else{
			$return['status_code']="401";
			$return['status_txt']=$this->createStatus(401);
		}

		echo json_encode($return); 
	}

}//class

