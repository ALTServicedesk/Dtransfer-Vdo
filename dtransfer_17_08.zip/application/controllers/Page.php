<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Page extends My_Controller {

	function __construct()
	{
		parent::__construct();
        $this->load->model('Package_model','package');

	}
	
	public function index()
	{
		//$data['home']=true;
		if ($this->is_logged_in()!=false) {
			redirect("user/dashboard");
		}
		else
			$this->get_user_template('index',$data);
	}

	public function getpage(){
		//$data['home']=true;
		$slug=$this->input->post("slug");
		$ch = curl_init();

			curl_setopt($ch, CURLOPT_URL,"http://dtransfer.afterdoor.com/api/getpage");
			curl_setopt($ch, CURLOPT_POST, 1);
			 curl_setopt($ch, CURLOPT_POSTFIELDS, 
			          http_build_query(array('slug' => $slug))); //replace licence id
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

			$server_output = curl_exec ($ch);

			curl_close ($ch);
			$licence=(json_decode($server_output));
			//var_dump($licence);
			echo $licence->content;
	}

}
