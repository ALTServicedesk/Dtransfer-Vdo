<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Support extends My_Controller {

	function __construct()
	{
		parent::__construct();
        $this->load->model('Settings_model','settings');
        $this->load->model('Support_model','support');
        $this->load->model('User_model','user_model');

	}
	
	public function index()
	{
		if (check_access()!=false) {
			redirect("user/dashboard");
		}
		else
			redirect("user/login");
	}

	public function messages()
	{
		if ($this->check_access()!=false) {
			$data['language']=$this->settings->getallmessages();
			$this->get_user_template('settings_language',$data);
		}
		else
			redirect("user/login");
	}

	public function submitticket(){

		//echo'hello'; die;
		if ($this->check_access()!=false) {

		 $this->form_validation->set_rules('department', 'department', 'trim|required');
         $this->form_validation->set_rules('subject', 'subject', 'trim|required');
         $this->form_validation->set_rules('priority', 'priority', 'trim|required');
         $this->form_validation->set_rules('description', 'description', 'trim|required');
         $this->form_validation->set_rules('status', 'status', 'trim|required');
         if ($this->form_validation->run() == FALSE)
            {
              $data['licenceid']=$this->support->getLiscenceID();
			  //echo'<pre>';print_r($data['licenceid']);die;
			  $this->get_user_template('submit_ticket',$data);
            }
            else
            {
            
                $data = array(
                               // 'ST_ID' => $st_id,
                                'department' => $this->input->post('department'),
                                'subject' => $this->input->post('subject'),
                                'priority' => $this->input->post('priority'),
                                'description'=>$this->input->post('description'),
                                'status'=>$this->input->post('status'),
                                'licid'  => $this->input->post('licid')
                            );
                	$ch = curl_init();

					curl_setopt($ch, CURLOPT_URL,"http://dtransfer.afterdoor.com/api/openTicket");
					curl_setopt($ch, CURLOPT_POST, 1);
					curl_setopt($ch, CURLOPT_POSTFIELDS, $data); //replace licence id			
					curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
					$server_output = curl_exec ($ch);
					curl_close ($ch);
					$returnId = json_decode($server_output);

                redirect("support/alltickets");
                          
                    /* Start Uploading File */
                    /* $config =   [
                                 'upload_path'   => './uploads/',
                                    'allowed_types' => 'doc|docx|pdf',
                                    'max_size'      => 500000,
                                    'max_width'     => 10240,
                                    'max_height'    => 7680
                                 ];

                   $this->load->library('upload', $config);
                    $image1 = $this->input->post('ticketfile');
                   if ( ! $this->upload->do_upload('ticketfile'))
                   {
                    
                     //echo $this->upload->display_errors(); die;
                         return $error = array('error' => $this->upload->display_errors());
                     // $this->load->view('admin/student_postresume',$error);
                   }
                   else
                   { 
                           $file = $this->upload->data();
                            $datapath = 'uploads/' . $file['file_name'];
                            $fullpath = $file['full_path'];
                          // unlink($image->file);

                        //insert the user registration details into database
                      //  $st_id = $this->session->userdata('user_id');
                        
                    }*/

            }
			
		}
		else
			redirect("user/login");

	}

	public function alltickets()
	{
		if ($this->check_access()!=false) {
			//$data['messages']=$this->settings->savemessages();
			$data['licenceid'] = $this->support->getLiscenceID();
			//echo $data['licenceid']->licence_id; die;
			 $data_new = array(
                               // 'ST_ID' => $st_id,
                                'licenceid' => $data['licenceid']->licence_id,
                            );
			$ch = curl_init();

			curl_setopt($ch, CURLOPT_URL,"http://dtransfer.afterdoor.com/api/getTicket");
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $data_new); //replace licence id			
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			$server_output = curl_exec ($ch);
			curl_close ($ch);
			$returndata['allticket'] = json_decode($server_output);
			

			//$dat['alltickets'] = $this->support->getAllTickets($data['licenceid']->licence_id);
			$this->get_user_template('alltickets',$returndata);

			//var_dump($this->input->post());
		}
		else
			redirect("user/login");
	}

	public function singleticket()
	{
		if ($this->check_access()!=false) {
			//$data['messages']=$this->settings->savemessages();
			$data['licenceid'] = $this->support->getLiscenceID();
			 $tkid = $this->uri->segment(3);
			//die;
       
			 $data_new = array(
                               // 'ST_ID' => $st_id,
                                'tkid' => $tkid,
                            );
			$ch = curl_init();

			curl_setopt($ch, CURLOPT_URL,"http://dtransfer.afterdoor.com/api/getSingleTicket");
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $data_new); //replace licence id			
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			$server_output = curl_exec ($ch);
			curl_close ($ch);
			$returndata['allticket'] = json_decode($server_output);
			/*echo'<pre>';
			print_r($returndata['allticket']);
			die;*/
			$this->get_user_template('singletickets',$returndata);

			//var_dump($this->input->post());
		}
		else
			redirect("user/login");
	}

	public function ticketreply(){

		 $this->form_validation->set_rules('description', 'description', 'trim|required');
         $this->form_validation->set_rules('ticketid', 'ticketid', 'trim|required');
         $data['user']=$this->user_model->get_user($this->is_logged_in());
         //print_r($data); die;
         $tkid = $this->input->post('ticketid');
        if ($this->form_validation->run() == FALSE)
            {
                // fails
                redirect("support/singleticket/".$tkid);
            }
            else
            {
                $data = array(
                                'ticketid' => $this->input->post('ticketid'),
                                'description'=>$this->input->post('description'),
                                'username' => $data['user']->name,
                                //'RP_File'  => $fullpath
                            );
                	$ch = curl_init();

					curl_setopt($ch, CURLOPT_URL,"http://dtransfer.afterdoor.com/api/replyTicket");
					curl_setopt($ch, CURLOPT_POST, 1);
					curl_setopt($ch, CURLOPT_POSTFIELDS, $data); //replace licence id			
					curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
					$server_output = curl_exec ($ch);
					curl_close ($ch);
					$returnId = json_decode($server_output);

                redirect("support/singleticket/".$tkid);
                          
                     

            }
	}

	public function faq()
	{
		if ($this->check_access()!=false) {
			//$data['messages']=$this->settings->savemessages();
			//$data['licenceid'] = $this->support->getLiscenceID();
			//echo $data['licenceid']->licence_id; die;
			
			$ch = curl_init();

			curl_setopt($ch, CURLOPT_URL,"http://dtransfer.afterdoor.com/api/getFaq");
			//curl_setopt($ch, CURLOPT_POST, 1);
			//curl_setopt($ch, CURLOPT_POSTFIELDS, $data_new); //replace licence id			
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			$server_output = curl_exec ($ch);
			curl_close ($ch);
			$returndata['allfaq'] = json_decode($server_output);
			

			//$dat['alltickets'] = $this->support->getAllTickets($data['licenceid']->licence_id);
			$this->get_user_template('allfaqs',$returndata);

			//var_dump($this->input->post());
		}
		else
			redirect("user/login");
	}

	public function knowledgebase()
	{
		if ($this->check_access()!=false) {
			
			$ch = curl_init();

			curl_setopt($ch, CURLOPT_URL,"http://dtransfer.afterdoor.com/api/getKnowledgeCategories");
			//curl_setopt($ch, CURLOPT_POST, 1);
			//curl_setopt($ch, CURLOPT_POSTFIELDS, $data_new); //replace licence id			
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			$server_output = curl_exec ($ch);
			curl_close ($ch);
			$returndata['allcategories'] = json_decode($server_output);
			

			//$dat['alltickets'] = $this->support->getAllTickets($data['licenceid']->licence_id);
			$this->get_user_template('allknowledgebase',$returndata);

			//var_dump($this->input->post());
		}
		else
			redirect("user/login");
	}

	public function article(){
		if ($this->check_access()!=false) {
			
			 $artid = $this->uri->segment(3);       
			 $data_new = array(
                               // 'ST_ID' => $st_id,
                                'artid' => $artid,
                            );
			$ch = curl_init();

			curl_setopt($ch, CURLOPT_URL,"http://dtransfer.afterdoor.com/api/getArticle");
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $data_new); //replace licence id			
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			$server_output = curl_exec ($ch);
			curl_close ($ch);
			$returndata['allticket'] = json_decode($server_output);
			/*echo'<pre>';
			print_r($returndata['allticket']);
			die;*/
			$this->get_user_template('article',$returndata);

			//var_dump($this->input->post());
		}
		else
			redirect("user/login");

	}


		public function catarticle(){
		if ($this->check_access()!=false) {
			
			 $catid = $this->uri->segment(3);       
			 $data_new = array(
                               // 'ST_ID' => $st_id,
                                'catid' => $catid,
                            );
			$ch = curl_init();

			curl_setopt($ch, CURLOPT_URL,"http://dtransfer.afterdoor.com/api/getKnowledgeArticles");
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $data_new); //replace licence id			
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			$server_output = curl_exec ($ch);
			curl_close ($ch);
			$returndata['allticket'] = json_decode($server_output);
			/*echo'<pre>';
			print_r($returndata['allticket']);
			die;*/
			$this->get_user_template('catarticles',$returndata);

			//var_dump($this->input->post());
		}
		else
			redirect("user/login");

	}

}
