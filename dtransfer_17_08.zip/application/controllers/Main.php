<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Main extends My_Controller {

	public function index()
	{
		if ($this->is_logged_in()!=false) {
			redirect("user/profile");
		}
		else
			$this->get_user_template('index');
	}
}
