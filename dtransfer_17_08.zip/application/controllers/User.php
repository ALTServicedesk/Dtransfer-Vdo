<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends My_Controller {

	function __construct()
	{
		parent::__construct();
        $this->load->model('User_model','user_model');
       	$this->load->model('Ouremail','ouremail');
        $this->load->model('Files_model','files_model');
        $this->load->model('Logs_model','logs_model');

	}

	public function index()
	{
		
		$data['home']=true;
		if ($this->is_logged_in()!=false) {
			redirect("user/dashboard");
		}
		else
			redirect("user/login");
	}

	public function register()
	{
		$data['home']=true;
		if ($this->is_logged_in()!=false) {
			redirect('user/dashboard');
		}
		else
		{
			$this->form_validation->set_error_delimiters('<div class="error" style="color:red">', '</div>');
		    	$config = array(
			        
			         array(
			                'field' => 'email',
			                'label' => 'email',
			                'rules' => 'required|valid_email|is_unique[user.email]'
			        ),
			        array(
			                'field' => 'password',
			                'label' => 'password',
			                'rules' => 'required'
			        ),
			        array(
			                'field' => 'confirmpassword',
			                'label' => 'Confirm Password',
			                'rules' => 'required|matches[password]'
			        ),
			        array(
			                'field' => 'name',
			                'label' => 'Name',
			                'rules' => 'required'
			        ),
			        array(
			                'field' => 'lname',
			                'label' => 'Last Name',
			                'rules' => 'required'
			        )
			        ,
			        array(
			                'field' => 'phone',
			                'label' => 'Phone',
			                'rules' => 'required|numeric|max_length[10]'
			        )
				);
				$this->form_validation->set_message('is_unique', 'Already exits. Please use another one or login into your existing account.');
			    $this->form_validation->set_rules($config);
				if ($this->form_validation->run() == FALSE)
				{
					$this->get_user_template('register',$data);
				}
				else
				{
						$data['messageregister']=$this->user_model->register();
						if($data['messageregister']==true){ 
							$this->session->set_flashdata("messageregister",$data['messageregister']);
							$this->get_user_template('register',$data);
						}
					    ///$this->get_user_template('login',$data);
					
				}
			
		}
	}

	public function login()
	{	
		$data['home']=true;
		if ($this->is_logged_in()!=false) {
			redirect("user/dashboard");
		}
		else
		{
			$this->form_validation->set_error_delimiters('<div class="error" style="color:red">', '</div>');
		    	$config = array(
			        
			         array(
			                'field' => 'emaillogin',
			                'label' => 'email',
			                'rules' => 'required|valid_email'
			        ),
			        array(
			                'field' => 'passwordlogin',
			                'label' => 'password',
			                'rules' => 'required'
			        )
				);
				$this->form_validation->set_rules($config);
				if ($this->form_validation->run() == FALSE)
				{
					$this->get_user_template('index',$data);
				}
				else
				{
						$data['user']=$this->user_model->get_user($this->is_logged_in());

						$data['messagelogin']=$this->user_model->login();
						if($data['messagelogin']==1){ 													
							redirect("user/login");							
						}
						if($data['messagelogin']==2){ 													
							redirect("user/profile");							
						}
						else
						{

					     $this->get_user_template('index',$data);							
						}
					
				}

		}
	}

	public function verifyemail($user_id,$md5email){
		$data['messageverify']=$this->user_model->verifyemail($user_id,$md5email);
		$data['home']=true;
		$data['user']=$this->user_model->get_user($this->is_logged_in());
		$this->session->set_flashdata("messageverify",$data['messageverify']);
		$this->get_user_template('index',$data);
	}


	public function resendverification($user_id){
		$data['messageverifyrequest']=$this->user_model->resendverification($user_id);
		$data['home']=true;
		$data['user']=$this->user_model->get_user($this->is_logged_in());

		$this->get_user_template('index',$data);
	}


	public function logout()
	{
		if($this->is_logged_in()==false)
				{					
					redirect('user/login');
				}
				else
				{
					$this->session->sess_destroy();
					$this->config->set_item('user_id','');
					delete_cookie('user_id');	
					redirect('user/login');

				}
	}

	public function dashboard(){
		if ($this->is_logged_in()!=false) {
			$data['user']=$this->user_model->get_user($this->is_logged_in());
			if($this->session->userdata("type")==3){
				$data['dashboarddata']=$this->user_model->dashboard3($this->is_logged_in());				
				$data['userslogs']=$this->logs_model->getlatestlog('user');
				$data['smtplogs']=$this->logs_model->getlatestlog('smtp');
				$this->get_user_template('dashboard-3',$data);
			}
			else{
				$data['dashboarddata']=$this->user_model->dashboard($this->is_logged_in());
				$this->get_user_template('dashboard',$data);
			}

		}
		else{
			redirect("/");
		}
	}

	public function upload(){
		if ($this->is_logged_in()!=false) {

			if($this->input->post('otp'))
			{
				$otp=$this->input->post('otp');
				$auth=$this->user_model->check_otp($this->is_logged_in(),$otp);
				if($auth!=false)
				{
					$data['session_id']=$auth->session_id;
					$data['user']=$this->user_model->get_user($this->is_logged_in());
					$data['staff']=$this->user_model->get_all_staff();
					$this->get_user_template('upload',$data);
				}
				else
				{
					$data['otp']=$otp;	
					//$data['session_id']=NULL;				
					$this->user_model->get_otp($this->is_logged_in(),"upload");
					$data['error']="Wrong OTP Entered";
					$data['user']=$this->user_model->get_user($this->is_logged_in());
					//$data['staff']=$this->user_model->get_all_staff();
					$this->get_user_template('otp',$data); // change to otp
				}
			}
			else
			{
				
				$this->user_model->get_otp($this->is_logged_in(),"upload");
				$data['user']=$this->user_model->get_user($this->is_logged_in());
				//$data['staff']=$this->user_model->get_all_staff();
				$this->get_user_template('otp',$data); // change to otp
			}
		}
		else{
			redirect("/");
		}
	}

	public function download(){
		if ($this->is_logged_in()!=false) {

			if($this->input->post('otp'))
			{
				$otp=$this->input->post('otp');
				$auth=$this->user_model->check_otp($this->is_logged_in(),$otp);
				if($auth!=false)
				{
					$data['session_id']=$auth->session_id;
					$data['user']=$this->user_model->get_user($this->is_logged_in());
					$data['staff']=$this->user_model->get_all_staff();
					$data['home']=true;
					$this->get_user_template('download',$data);
				}
				else
				{
					$data['otp']=$otp;	
					//$data['session_id']=NULL;				
					$this->user_model->get_otp($this->is_logged_in(),"download");
					$data['error']="Wrong OTP Entered";
					$data['user']=$this->user_model->get_user($this->is_logged_in());
					$data['home']=true;
					//$data['staff']=$this->user_model->get_all_staff();
					$this->get_user_template('downloadfiles',$data); // change to otp
				}
			}
			else
			{
				
				$this->user_model->get_otp($this->is_logged_in(),"upload");
				$data['user']=$this->user_model->get_user($this->is_logged_in());
				$data['home']=true;
				//$data['staff']=$this->user_model->get_all_staff();
				$this->get_user_template('downloadfiles',$data); // change to otp
			}
		}
		else{
			redirect("/");
		}
	}

	public function requestotp($type,$user_id){		
		$this->user_model->requestotp($user_id,$type);
		if($type=='upload')
			redirect("user/upload");
		else
		{
			$this->load->library('user_agent');
			
				echo redirect($this->agent->referrer());
			
		}
}

public function uploaduser(){
		if ($this->is_logged_in()!=false) {

			if($this->input->post('otp'))
			{
				$otp=$this->input->post('otp');
				$auth=$this->user_model->check_otp($this->is_logged_in(),$otp);
				if($auth!=false)
				{
					$data['session_id']=$auth->session_id;
					$data['user']=$this->user_model->get_user($this->is_logged_in());
					$data['staff']=$this->user_model->get_all_user();
					$this->get_user_template('uploaduser',$data);
				}
				else
				{
					$data['otp']=$otp;	
					//$data['session_id']=NULL;				
					$this->user_model->get_otp($this->is_logged_in(),"upload");
					$data['error']="Wrong OTP Entered";
					$data['user']=$this->user_model->get_user($this->is_logged_in());
					//$data['staff']=$this->user_model->get_all_staff();
					$this->get_user_template('uploaduserotp',$data);
				}
			}
			else
			{
				
				$this->user_model->get_otp($this->is_logged_in(),"upload");
				$data['user']=$this->user_model->get_user($this->is_logged_in());
				//$data['staff']=$this->user_model->get_all_staff();
				$this->get_user_template('uploaduserotp',$data);
			}
		}
		else{
			redirect("/");
		}
	}

	public function myfilessent(){
		if ($this->is_logged_in()!=false) {
			$data['user']=$this->user_model->get_user($this->is_logged_in());
			$data['myfiles']=$this->user_model->myfilessent($this->is_logged_in());
			$this->get_user_template('myfilessent',$data);

		}
		else{
			redirect("/");
		}
	}

	public function myfilesreceived(){
		if ($this->is_logged_in()!=false) {
			$data['user']=$this->user_model->get_user($this->is_logged_in());
			$data['myfiles']=$this->user_model->myfilesreceived($this->is_logged_in());
			$this->get_user_template('myfilesreceived',$data);

		}
		else{
			redirect("user/login");
		}
	}


	public function uploadfile(){
		//if ($this->is_logged_in()!=false) {
			$vaild = $this->input->post("validity");
			
			$expiry=date('Y-m-d H:i:s',strtotime('+'.$vaild.' days'));
			$session_id=$this->input->post("session_id");
			$onetime=$this->input->post("onetime");
			$user_id=$this->input->post("user_id");
			$filename="";
			$totalfilesize=array_sum($this->input->post("filesize[]"));
			if($this->input->post("filename[]"))
			{
					foreach ($this->input->post("filename[]") as $key => $value) {
						$filename=$filename.", ".$value;
					}
					$filename=ltrim($filename,",");
					$filesize="";
					foreach ($this->input->post("filesize[]") as $key => $value) {
						$filesize=$filesize.", ".$value;
					}
					$filesize=ltrim($filesize,",");
					$staff=trim($this->input->post("email"), ",");
					$staffnew=explode(',',$staff);
					if($this->input->post("cc")!=""){
						$cc=trim($this->input->post("cc"), ",");
						$ccnew=explode(',',$cc);
						$sendemails=array_merge($staffnew,$ccnew);
					}
					else{
						$sendemails=$staffnew;
					}
					//var_dump($staffnew);
					foreach ($sendemails as $key => $value) {
						//check for user
						$query=$this->db->query("select * from user where email='$value'");
						$query2=$this->db->query("select * from user where user_id='$user_id'");
						$senddata['sender']=$query2->row();

						if($query->num_rows()>0)
						{ // exitsinh user
							$query=$query->row();
							$data = array(
								'user_id' => $user_id, 
								'staff_id' => $query->user_id, 
								'filename' => $filename, 
								'validity' => $this->input->post("validity"), 
								'session_id' => $session_id, 
								'description' => $this->input->post("description"), 
								'subject' => $this->input->post("subject"), 
								'filesize' => $filesize, 
								'onetime' => $onetime, 
								'expiry' => $expiry, 
								'totalfilesize' => $totalfilesize, 
								);
								$this->db->insert("files",$data);
								$data['files_id']=$this->db->insert_id();
								$this->db->query("update session set status='1' where session_id='$session_id'");
								//send email for shared files
								//data to send

								$senddata['user']=$query;
								$senddata['files']=$data;
								
						}
						else
						{

							//new user
				$query=$this->db->get('ldap')->row();
                $host=$query->host;
                $port=$query->port;
                $domain=$query->domain;
                $ldapuser=$query->ldapuser;
                $ldappass=$query->ldappass;
                
		$domainsplit=explode(".",$domain);	
		//var_dump($domainsplit);		//check for ldap existance
		$adServer = $host;
        $ldap = ldap_connect($adServer);
        $ldaprdn = 'dc='.$domainsplit[0].',dc='.$domainsplit[1];

        ldap_set_option($ldap, LDAP_OPT_PROTOCOL_VERSION, 3);
        ldap_set_option($ldap, LDAP_OPT_REFERRALS, 0);

        $bind = @ldap_bind($ldap, $ldapuser, $ldappass);
        if ($bind) {
           $result = ldap_search($ldap,$ldaprdn, "(&(objectCategory=user))") or die ("Error in search query: ".ldap_error($ldap));
        $data = ldap_get_entries($ldap, $result);
        $emails = array();
        $givenname = array();
       for ($i=0; $i<$data["count"]; $i++) {
       	if (isset($data[$i]["userprincipalname"][0])) {
       		$emails[$i]=$data[$i]["userprincipalname"][0];
       		$givenname[$i]=$data[$i]["givenname"][0];
       	}
       }
       $namekey = array_search($value, $emails);
       if(!in_array($value,$emails)){
       	//check for ldap existance
       	//echo "normal";
							$password=rand(100000,999999);
							$expiry=date("d-m-Y");
		       				$expiry=date("d-m-Y",strtotime("+90 days"));
							//insert new user first
							$data = array(
				            'name' => "", 
				            'email' => $value, 
				            'password' => md5($password),
				            'department' => "",
				            'type' => "1" ,
				            'status' => "2" ,		            
		            		'package_id' => "1" ,
		            		'package_validity' => $expiry ,
				            );
				            $this->db->insert("user",$data);
				            $new_user_id=$this->db->insert_id();
				            //email to new user//
				            $senddatanewuser = array(
				            	'password' => $password,
				            	'email' => $value,
				            	'user_id' => $new_user_id,
				            	 );
				            $this->ouremail->sendemail("You have been signed up","welcomenew",$senddatanewuser,$value);
				            //email to new user//
       } else{
       //	echo "ldap";

							$password=rand(100000,999999);
							$expiry=date("d-m-Y");
		       				$expiry=date("d-m-Y",strtotime("+90 days"));
							//insert new user first
							$data = array(
				            'name' => $givenname[$namekey], 
				            'email' => $value, 
				            'password' => "",
				            'department' => "",
				            'type' => "2" ,
				            'status' => "1" ,		            
		            		'package_id' => "1" ,
		            		'package_validity' => $expiry ,
				            );
				            $this->db->insert("user",$data);
				            $new_user_id=$this->db->insert_id();
				            //email to new user//
				            /*$senddatanewuser = array(
				            	'password' => $password,
				            	'email' => $value,
				            	'user_id' => $new_user_id,
				            	 );
				            $this->ouremail->sendemail("You have been signed up","welcomenew",$senddatanewuser,$value);*/
				            //email to new user//
       }
        // iterate over array and print data for each entry
       
	}//bind
							


				            //insert files to new user
				            $query_new=$this->db->query("select * from user where user_id='$new_user_id'");
				            $data = array(
								'user_id' => $user_id, 
								'staff_id' => $new_user_id, 
								'filename' => $filename, 
								'validity' => $this->input->post("validity"), 
								'session_id' => $session_id, 
								'description' => $this->input->post("description"), 
								'subject' => $this->input->post("subject"),
								'filesize' => $filesize, 
								'onetime' => $onetime, 
								'expiry' => $expiry, 
								'totalfilesize' => $totalfilesize,
								);
								$this->db->insert("files",$data);
								$data['files_id']=$this->db->insert_id();
								$this->db->query("update session set status='1' where session_id='$session_id'");
								$senddata['user']=$query_new->row();
								$senddata['files']=$data;
						}
						if (!in_array($value,$ccnew)) {
							$this->ouremail->sendemail("Files shared with you","fileshared",$senddata,$value,$this->input->post("cc"));
						}
						
						//check for user
					}
					//$data['user']=$this->user_model->get_user($user_id);
					//$data['staff']=$this->user_model->get_all_staff();
					$data['message']="Successfuly Sent";
					$data1 = array(
								'status' => 1,
								);
					$this->db->where("current_uploads_id",$this->input->post("insert_id"))->update("current_uploads",$data1);
					
					echo "<p class='alert alert-success text-center'>Files uploaded successfuly. You can leave the page to continue.</p>";
				}
				else{
					//$data['user']=$this->user_model->get_user($user_id);
					//$data['staff']=$this->user_model->get_all_staff();
					$data['message']="Failed!!.";
					//$data['myfiles']=$this->user_model->myfilessent($user_id);
					echo "<p class='alert alert-danger text-center'>Something went wrong in uploading files. This may be due to network issues. Please try again.</p>";

				}
			

		//}
		//else{
		//	redirect("user/login");
		//}
	}

	public function uploadfileapi(){
		//if ($this->is_logged_in()!=false) {
			$vaild = $this->input->post("validity");
			
			$expiry=date('Y-m-d H:i:s',strtotime('+'.$vaild.' days'));
			$session_id=$this->input->post("session_id");
			$onetime=$this->input->post("onetime");
			$user_id=$this->input->post("user_id");
			$filename="";
			$totalfilesize=array_sum($this->input->post("filesize[]"));
			if($this->input->post("filename[]"))
			{
					foreach ($this->input->post("filename[]") as $key => $value) {
						$filename=$filename.", ".$value;
					}
					$filename=ltrim($filename,",");
					$filesize="";
					foreach ($this->input->post("filesize[]") as $key => $value) {
						$filesize=$filesize.", ".$value;
					}
					$filesize=ltrim($filesize,",");
					$staff=trim($this->input->post("email"), ",");
					$staffnew=explode(',',$staff);
					//var_dump($staffnew);
					foreach ($staffnew as $key => $value) {
						//check for user
						$query=$this->db->query("select * from user where email='$value'");
						$query2=$this->db->query("select * from user where user_id='$user_id'");
						$senddata['sender']=$query2->row();

						if($query->num_rows()>0)
						{
							$query=$query->row();
							$data = array(
								'user_id' => $user_id, 
								'staff_id' => $query->user_id, 
								'filename' => $filename, 
								'validity' => $this->input->post("validity"), 
								'session_id' => $session_id, 
								'description' => $this->input->post("description"), 
								'subject' => $this->input->post("subject"), 
								'filesize' => $filesize, 
								'onetime' => $onetime, 
								'expiry' => $expiry, 
								'totalfilesize' => $totalfilesize, 
								);
								$this->db->insert("files",$data);
								$this->db->query("update session set status='1' where session_id='$session_id'");
								//$query['files_id']=$this->db->insert_id();
								//send email for shared files
								//data to send

								$senddata['user']=$query;
								$senddata['files']=$data;
								$this->ouremail->sendemail("Files shared with you","fileshared",$senddata,$value);
						}
						else
						{
							//$query=$query->row();

							$password=rand(100000,999999);
							$expiry=date("d-m-Y");
		       				$expiry=date("d-m-Y",strtotime("+90 days"));
							//insert new user first
							$data = array(
				            'name' => "", 
				            'email' => $value, 
				            'password' => md5($password),
				            'department' => "",
				            'type' => "1" ,
				            'status' => "2" ,		            
		            		'package_id' => "1" ,
		            		'package_validity' => $expiry ,
				            );
				            $this->db->insert("user",$data);
				            $new_user_id=$this->db->insert_id();
				            //insert files to new user
				            //email to new user//
				            $senddatanewuser = array(
				            	'password' => $password,
				            	'email' => $value,
				            	'user_id' => $new_user_id,
				            	 );
				            /*$this->ouremail->sendemail("You have been signed up","welcomenew",$senddatanewuser,$value);*/
				            //email to new user//
				            $query_new=$this->db->query("select * from user where user_id='$new_user_id'");
				            $data = array(
								'user_id' => $user_id, 
								'staff_id' => $new_user_id, 
								'filename' => $filename, 
								'validity' => $this->input->post("validity"), 
								'session_id' => $session_id, 
								'description' => $this->input->post("description"), 
								'subject' => $this->input->post("subject"), 													 
								'filesize' => $filesize, 
								'onetime' => $onetime, 
								'expiry' => $expiry, 
								'totalfilesize' => $totalfilesize, 
								
								);
								$this->db->insert("files",$data);
								$this->db->query("update session set status='1' where session_id='$session_id'");
								$senddata['user']=$query_new->row();
								$senddata['files']=$data;
								$this->ouremail->sendemail("Files shared with you","fileshared",$senddata,$value);
						}
						//check for user
					

					}
					$data['user']=$this->user_model->get_user($user_id);
					$data['staff']=$this->user_model->get_all_staff();
					$data['message']="Successfuly Sent";
					$data['myfiles']=$this->user_model->myfilessent($user_id);

					echo "<p class='alert alert-success text-center'>Email sent. You can leave the page now to continue.</p>";
				}
				else{
					$data['user']=$this->user_model->get_user($user_id);
					$data['staff']=$this->user_model->get_all_staff();
					$data['message']="Failed!!.";
					$data['myfiles']=$this->user_model->myfilessent($user_id);
					echo "<p class='alert alert-danger text-center'>Something went wrong in uploading files. This may be due to network issues. Please try again.</p>";

				}
			

		//}
		//else{
		//	redirect("user/login");
		//}
	}

	public function addstaff(){
		if ($this->is_logged_in()!=false) {
			$data['user']=$this->user_model->get_user($this->is_logged_in());
			//$data['myfiles']=$this->user_model->myfilessent($this->is_logged_in());

			$this->form_validation->set_error_delimiters('<div class="error" style="color:red">', '</div>');
		    	$config = array(
			        
			         array(
			                'field' => 'email',
			                'label' => 'email',
			                'rules' => 'required|valid_email|is_unique[user.email]'
			        ),
			        array(
			                'field' => 'password',
			                'label' => 'password',
			                'rules' => 'required'
			        ),
			        array(
			                'field' => 'confirmpassword',
			                'label' => 'Confirm Password',
			                'rules' => 'required|matches[password]'
			        ),
			        array(
			                'field' => 'name',
			                'label' => 'First Name',
			                'rules' => 'required'
			        ),
			        array(
			                'field' => 'lname',
			                'label' => 'Last Name',
			                'rules' => 'required'
			        ),
			        array(
			                'field' => 'phone',
			                'label' => 'Phone',
			                'rules' => 'required'
			        )
				);
				$this->form_validation->set_message('is_unique', 'Already exits. Please use another one or login into your existing account.');
			    $this->form_validation->set_rules($config);
				if ($this->form_validation->run() == FALSE)
				{
					$this->get_user_template('addstaff',$data);
				}
				else
				{
						$data['message']=$this->user_model->addstaffregister();
						if($data['message']==true){ 
							
							$this->get_user_template('addstaff',$data);
						}
					    ///$this->get_user_template('login',$data);
					
				}
			

		}
		else{
			redirect("user/login");
		}
	}

	public function addgroup(){
		if ($this->is_logged_in()!=false) {
			$data['user']=$this->user_model->get_user($this->is_logged_in());
			//$data['myfiles']=$this->user_model->myfilessent($this->is_logged_in());

			$this->form_validation->set_error_delimiters('<div class="error" style="color:red">', '</div>');
		    	$config = array(
			        array(
			                'field' => 'name',
			                'label' => 'Group Name',
			                'rules' => 'required'
			        )
				);
				$this->form_validation->set_rules($config);
				if ($this->form_validation->run() == FALSE)
				{
					$this->get_user_template('addgroup',$data);
				}
				else
				{
						$data['message']=$this->user_model->addgroup();
						if($data['message']==true){ 
							
							$this->get_user_template('addgroup',$data);
						}
					    ///$this->get_user_template('login',$data);
					
				}
			

		}
		else{
			redirect("user/login");
		}
	}

	public function editgroup(){
		if ($this->is_logged_in()!=false) {
			$gid = $this->uri->segment(3);
			$data['group']=$this->user_model->get_group($gid)->row();
			//$data['myfiles']=$this->user_model->myfilessent($this->is_logged_in());

			$this->form_validation->set_error_delimiters('<div class="error" style="color:red">', '</div>');
		    	$config = array(
			        array(
			                'field' => 'name',
			                'label' => 'Group Name',
			                'rules' => 'required'
			        )
				);
				$this->form_validation->set_rules($config);
				if ($this->form_validation->run() == FALSE)
				{
					$this->get_user_template('editgroup',$data);
				}
				else
				{
					$data = array(
			            'name' => $this->input->post("name"), 
			           );
						if($this->user_model->editgroup($gid,$data)){ 
							
							redirect("user/groups");
						}
					    ///$this->get_user_template('login',$data);
					
				}
			

		}
		else{
			redirect("user/login");
		}
	}

	public function defaultgroup($id){
		if ($this->is_logged_in()!=false) {
			$this->db->update("group",array('default' => 0, ));
			$this->db->where("group_id",$id)->update("group",array('default' => 1, ));
			$this->session->set_flashdata("defaultgroupmsg","<p class='alert alert-success'>Default groupchanged</p>");
			redirect("user/groups");
			}
		else{
			redirect("user/login");
		}
	}

	public function managestaff(){
		if ($this->is_logged_in()!=false) {
			$data['user']=$this->user_model->get_user($this->is_logged_in());
			$data['staff']=$this->user_model->get_all_staff();
			$this->get_user_template('managestaff',$data);
		}
		else{
			redirect("user/login");
		}
	}

	public function allusers(){
		if ($this->is_logged_in()!=false) {
			$data['user']=$this->user_model->get_user($this->is_logged_in());
			$data['users']=$this->user_model->get_all_user();
			$this->get_user_template('allusers',$data);
		}
		else{
			redirect("user/login");
		}
	}


	


	public function configuration(){
		if ($this->is_logged_in()!=false) {
			$data['user']=$this->user_model->get_user($this->is_logged_in());
			$data['settings']=$this->user_model->configuration();
			$this->form_validation->set_error_delimiters('<div class="error" style="color:red">', '</div>');
		    	$config = array(
			        
			        
			        array(
			                'field' => 'title',
			                'label' => 'Site Title',
			                'rules' => 'required'
			        ),
			        array(
			                'field' => 'email',
			                'label' => 'Email',
			                'rules' => 'required'
			        ),
			        array(
			                'field' => 'phone',
			                'label' => 'Phone',
			                'rules' => 'required'
			        ),
			        array(
			                'field' => 'address',
			                'label' => 'Address',
			                'rules' => 'required'
			        )
				);
				$this->form_validation->set_rules($config);
			    if ($this->form_validation->run() == FALSE)
				{
					$this->get_user_template('configuration',$data);
				}
				else
				{
					$data['message']=$this->user_model->updateconfiguration();
						if($data['message']==true){ 
							$data['settings']=$this->user_model->configuration();

							
							$this->get_user_template('configuration',$data);
						}
				}
		}
		else{
			redirect("user/login");
		}
	}


	

	public function profile(){
		if ($this->is_logged_in()!=false) {
			$data['user']=$this->user_model->get_user($this->is_logged_in());
			$this->form_validation->set_error_delimiters('<div class="error" style="color:red">', '</div>');
		    	$config = array(			        
			         array(
			                'field' => 'name',
			                'label' => 'First Name',
			                'rules' => 'required'
			        	),
			         array(
			                'field' => 'lname',
			                'label' => 'Last Name',
			                'rules' => 'required'
			        	),
			         array(
			                'field' => 'phone',
			                'label' => 'Phone',
			                'rules' => 'required'
			        	),
				);
				$this->form_validation->set_rules($config);
			    if ($this->form_validation->run() == FALSE)
				{
					$this->get_user_template('profile',$data);
				}
				else
				{
						$data['message']=$this->user_model->profileupdate($this->is_logged_in());
						$data['user']=$this->user_model->get_user($this->is_logged_in());
						
						if($data['message']==true){ 
							$this->get_user_template('profile',$data);
						}
				}
			
		}
		else{
			redirect("user/login");
		}
	}
	public function changepassword(){
			
			if ($this->is_logged_in()==true) {
			
			$this->get_user_template('changepass');
		}
		else
			redirect('user/login');

		}

	public function changepass()
	{
		if ($this->is_logged_in()==true) {
			
			$data['message']=$this->user_model->changepass($this->is_logged_in());
				echo $data['message'];
		}
		else
			redirect('user/login');
		
		//$this->load->view(TEMPLATE_NAME.'/index');
	}

	public function logoimage(){
			$config = array(
			'upload_path' => "./uploads/",
			'allowed_types' => "gif|jpg|png|jpeg|pdf",
			'overwrite' => TRUE,
			'max_size' => "2048000", // Can be set to particular file size , here it is 2 MB(2048 Kb)
			);
		$this->load->library('upload', $config);

		if($this->upload->do_upload('logo'))
		{
			$data = array('upload_data' => $this->upload->data());
			$res=$this->user_model->logoimage($data['upload_data']['file_name']);
			if($res==1){
				redirect("user/configuration");
			}
		}
		else
		{
			$error = array('error' => $this->upload->display_errors());
			var_dump($error );
		}
	}


	public function profileimage(){
			$config = array(
			'upload_path' => "./uploads/",
			'allowed_types' => "gif|jpg|png|jpeg",
			'overwrite' => TRUE,
			'max_size' => "2048000", // Can be set to particular file size , here it is 2 MB(2048 Kb)
			);
		$this->load->library('upload', $config);

		if($this->upload->do_upload('profileimage'))
		{
			$data = array('upload_data' => $this->upload->data());
			$res=$this->user_model->profileimage($data['upload_data']['file_name'],$this->is_logged_in());
			if($res==1){
				redirect("user/profile");
			}
		}
		else
		{
			$error = array('error' => $this->upload->display_errors());
			var_dump($error );
		}
	}

	public function support()
	{
		$data['user']=$this->user_model->get_user($this->is_logged_in());
		if ($this->is_logged_in()==false) {
			redirect('user/login');
		}
		else
		{
			$this->form_validation->set_error_delimiters('<div class="error" style="color:red">', '</div>');
		    	$config = array(
			        
			        array(
			                'field' => 'subject',
			                'label' => 'Subject',
			                'rules' => 'required'
			        ),
			        array(
			                'field' => 'msg',
			                'label' => 'Message',
			                'rules' => 'required'
			        )
				);
				$this->form_validation->set_message('is_unique', 'Already exits. Please use another one or login into your existing account.');
			    $this->form_validation->set_rules($config);
				if ($this->form_validation->run() == FALSE)
				{
					$this->get_user_template('support',$data);
				}
				else
				{
						$data['message']=$this->user_model->support($this->is_logged_in());
						if($data['message']==true){ 
							
							$this->get_user_template('support',$data);
						}
					    ///$this->get_user_template('login',$data);
					
				}
			
		}
	}
		public function changestatus($userid,$status){
			$data = array(
               'status' => $status,
            );

			$this->db->where('user_id', $userid);
			$this->db->update('user', $data);
			redirect("user/allusers");
		}

		public function delete($userid){
			
			//unlink files
				$query=$this->db->get_where('files', array('user_id' => $userid));
				$query=$query->result();
				foreach ($query as $key => $value) {
					 $files=explode(",",$value->filename);

					 foreach ($files as $key2 => $value2) {
					 	unlink("./server/php/files/". trim($value2));
					 }
				}
			

			 $this->db->delete('user', array('user_id' => $userid)); 
			 $this->db->delete('session', array('user_id' => $userid)); 
			 $this->db->delete('package_request', array('user_id' => $userid)); 
			 $this->db->delete('files', array('user_id' => $userid)); 
			 $this->db->delete('download', array('user_id' => $userid));
			 redirect("user/allusers");
		}


		public function completeprofile($userid){
			$data['user']=$this->user_model->get_user($userid);
			$data['home']=true;
			//if($this->is_logged_in()==false){
				$this->user_model->forcedlogin($userid);
			//}
			//if ($this->is_logged_in()!=false) {
			$data['user']=$this->user_model->get_user($this->is_logged_in());
			$this->form_validation->set_error_delimiters('<div class="error" style="color:red">', '</div>');
		    	$config = array(
			         array(
			                'field' => 'name',
			                'label' => 'First Name',
			                'rules' => 'required'
			        	),
			         array(
			                'field' => 'lname',
			                'label' => 'Last Name',
			                'rules' => 'required'
			        	),
			         array(
			                'field' => 'phone',
			                'label' => 'Phone',
			                'rules' => 'min_length[10]|numeric|required'
			        	),
			         array(
			                'field' => 'pass',
			                'label' => 'Set Password',
			                'rules' => 'required'
			        	),
			         array(
			                'field' => 'confirmpass',
			                'label' => 'Confirm Password',
			                'rules' => 'trim|required|matches[pass]'
			        	),
			         
				);
				$this->form_validation->set_rules($config);
			    if ($this->form_validation->run() == FALSE)
				{
					$this->get_user_template('completeprofile',$data);
				}
				else
				{
						$data['message']=$this->user_model->completeupdate($this->is_logged_in());
						$data['user']=$this->user_model->get_user($this->is_logged_in());
						
						if($data['message']==true){ 
							$data['messagecomplete']="<p class='alert alert-success'>Profile Completed. Please login with the password you have set.</p>";
							$this->session->set_flashdata("messagecompleteprofile",$data['messagecomplete']);
							//redirect("user/dashboard/");
							$this->get_user_template('index',$data);
						}					
				}
			
			//}
			//else{
			//	echo "//forced logged in";
			
			//$this->is_logged_in();
			//forced logged in
			//	redirect("user/completeprofile/".$this->is_logged_in());
			//}	
		}

		public function forgotpass(){
			$data['home']=true;
			$this->get_user_template('forgotpass',$data);

		}
		public function forgotpassproccess(){
			$data['home']=true;
			
			//if ($this->is_logged_in()!=false) {
			$data['user']=$this->user_model->get_user($this->is_logged_in());
			$data['messageforgot']=$this->user_model->forgotpass($this->input->post('email'));
			$this->session->set_flashdata("forgotpassmsg","<p class='alert alert-success'>Please check instructions on email.</p>");
			$this->get_user_template('index',$data);

		}

		
		public function setnewpass($key){
			$data['home']=true;
			
			//if ($this->is_logged_in()!=false) {
			
			$data['user']=$this->user_model->get_user($this->is_logged_in());
			$check=$this->user_model->newpasscheck($key);
			if($check==true) // verify email reset key exists
			{
				$data['key']=$key;
				$this->get_user_template('setnewpass',$data);
			}
			else
			{
				$this->session->set_flashdata("forgotpassmsg","<p class='alert alert-danger'>Password reset link is expried or link has been tampered. Please request again.</p>");
				$data['messagesetnewpass']="";
				$this->get_user_template('index',$data);
			}
			

		}


		public function updatepass(){
			$key=$this->input->post('key');
			$data['user']=$this->user_model->get_user($this->is_logged_in());
			$data['home']=true;
			$data['key']=$key;
			$this->form_validation->set_error_delimiters('<div class="error" style="color:red">', '</div>');
		    	$config = array(
			         array(
			                'field' => 'newpass',
			                'label' => 'Set Password',
			                'rules' => 'required'
			        	),
			         array(
			                'field' => 'confirmpass',
			                'label' => 'Confirm Password',
			                'rules' => 'trim|required|matches[newpass]'
			        	),
			         
				);
				$this->form_validation->set_rules($config);
			    if ($this->form_validation->run() == FALSE)
				{
					$this->session->set_flashdata("forgotpassmsg","<p class='alert alert-danger'>Password doesn't match.</p>");
					$this->get_user_template('setnewpass',$data);
				}
				else
				{
						$data['messagechangepass']=$this->user_model->setnewpass($key);
						
						if($data['messagechangepass']==true){ 
							$data['messagechangepass']="";
							//redirect("user/dashboard/");
							$this->session->set_flashdata("forgotpassmsg","<p class='alert alert-success'>Password changed you can login.</p>");
							$this->get_user_template('index',$data);
						}					
				}
		}



		// V2 Functions


		public function mail(){
		if ($this->check_access()!=false) {
			$data['user']=$this->user_model->get_user($this->is_logged_in());
			$data['mail']=$this->user_model->myfilesreceived($this->is_logged_in());
			$data['type']="inbox";
			$this->get_user_template('mail',$data);
		}
		else{
			redirect("user/login");
		}
	}

	public function sentmail(){
		if ($this->check_access()!=false) {
			$data['user']=$this->user_model->get_user($this->is_logged_in());
			$data['mail']=$this->user_model->myfilessent($this->is_logged_in());
			$data['type']="sentmail";			
			$this->get_user_template('sentmail',$data);

		}
		else{
			redirect("user/login");
		}
	}

	public function getmaildata(){
		if ($this->check_access()!=false) {
			$data['user']=$this->user_model->get_user($this->is_logged_in());
			$data['type']=$this->input->post("type");
			$data['maildata']=$this->user_model->getmaildata($this->input->post("mailid"));
			$this->get_user_template_ajax('viewmail',$data);
			//var_dump($data['maildata']);

		}
		else{
			redirect("user/login");
		}
	}


	public function compose(){
		if ($this->check_access()!=false) {
			$data['value']=$this->user_model->gettype($this->is_logged_in());
			$data['user']=$this->user_model->get_user($this->is_logged_in());
			$data['domain']=$this->user_model->general();
			if($this->config->item("user_allow_otp_email")=="yes" || $this->config->item("user_allow_otp_phone")=="yes")
			{
				$this->get_user_template('compose',$data);				
			}
			else
			{	$data['parse'] = $this->topDomainFromURL(base_url()); 
				$data['session_id']=$this->user_model->genTempsession($this->is_logged_in(),"upload");
				$data['domain']=$this->user_model->config();
				$data['value']=$this->user_model->gettype($this->is_logged_in());
				$this->get_user_template('composestart',$data);	// if both email and sms are disabled
			}
		}
		else{
			redirect("user/login");
		}
	}

	public function sendotp($type,$what="upload",$mailid=""){
		if ($this->check_access()!=false) {
			$data['user']=$this->user_model->get_user($this->is_logged_in());
			if($type=="mobile")
				$data['messageotp']=$this->user_model->get_otp_mobile($this->is_logged_in(),$what,$mailid);
			else
				$data['messageotp']=$this->user_model->get_otp_email($this->is_logged_in(),$what,$mailid);				
			
			$this->session->set_flashdata('messageotp', $data['messageotp']);

			redirect("user/compose");
			//var_dump($data['maildata']);

		}
		else{
			redirect("user/login");
		}
	}

	public function sendotponly($type,$what="upload",$mailid=""){
		if ($this->check_access()!=false) {
			$data['user']=$this->user_model->get_user($this->is_logged_in());
			if($type=="mobile")
				$data['messageotp']=$this->user_model->get_otp_mobile($this->is_logged_in(),$what,$mailid);
			else
				$data['messageotp']=$this->user_model->get_otp_email($this->is_logged_in(),$what,$mailid);				
			
			$this->session->set_flashdata('messageotp', $data['messageotp']);

		}
		else{
			redirect("user/login");
		}
	}

	public function sendotponlyuserid($user_id,$type,$what="upload",$mailid=""){
		if ($this->check_access()!=false) {
			$data['user']=$this->user_model->get_user($this->is_logged_in());
			if($type=="mobile")
				$data['messageotp']=$this->user_model->get_otp_mobile($user_id,$what,$mailid);
			else
				$data['messageotp']=$this->user_model->get_otp_email($user_id,$what,$mailid);				

		}
		else{
			redirect("user/login");
		}
	}

	public function requestdownloadotp(){
		$this->sendotponlyuserid($this->input->post("userid"),$this->input->post("sentto"),"download",$this->input->post("mailid"));
	}

	public function composestart(){
		if($this->input->post('otp'))
			{
				$otp=$this->input->post('otp');
				$auth=$this->user_model->check_otp($this->is_logged_in(),$otp);
				if($auth!=false)
				{
					$data['session_id']=$auth->session_id;
					$data['user']=$this->user_model->get_user($this->is_logged_in());
					$data['domain']=$this->user_model->config();
					$data['parse'] = $this->topDomainFromURL(base_url()); 

					$this->get_user_template('composestart',$data);
				}
				else
				{
					$data['otp']=$otp;	
					//$data['session_id']=NULL;				
					$this->user_model->get_otp($this->is_logged_in(),"upload");
					$data['messageotp']="<p class='alert alert-danger'>Wrong OTP Entered.</p>";
					$this->session->set_flashdata('messageotp', $data['messageotp']);
					redirect("user/compose");
				}
			}
			else
			{
				redirect("user/compose");
			}
	}
	function topDomainFromURL($url) {
		$url_parts = parse_url($url);
		$domain_parts = explode('.', $url_parts['host']);
		if (strlen(end($domain_parts)) == 2 ) { 
		// ccTLD here, get last three parts
		$top_domain_parts = array_slice($domain_parts, -2);
		} else {
		$top_domain_parts = array_slice($domain_parts, -2);
		}
		$top_domain = implode('.', $top_domain_parts);
		return $top_domain;
}

	public function composeupload(){
		if ($this->check_access()!=false) {
			$data['user']=$this->user_model->get_user($this->is_logged_in());
			$email= $this->input->post('email');
			$cc= $this->input->post('cc');
			$description= $this->input->post('description');
			$onetime= $this->input->post('onetime');
			$validity= $this->input->post('validity');
			$subject= $this->input->post('subject');
			$session_id= base64_encode($this->input->post('session_id'));
			//check for vaild domain
			if($this->config->item('user_domain_restriction')=='yes')
			{
				$parse = $this->topDomainFromURL(base_url()); 
				//echo $parse;
				if( strpos($email, $parse) !== false  || strpos($cc, $parse) !== false) 
					{
						$url=base_url()."user/composeuploadstart/?email=".$email."&cc=".$cc."&description=".urlencode($description)."&subject=".$subject."&onetime=".$onetime."&validity=".$validity."&session_id=".$session_id;
						redirect($url);
					}
					else{
						?>
						<script>
						alert("One recipient must be from '<?php echo $parse;?>'");
						window.location=document.referrer;
						</script>
						<?php
						//redirect("user/login");
					}
			}
			else{
				$url=base_url()."user/composeuploadstart/?email=".$email."&cc=".$cc."&description=".urlencode($description)."&subject=".$subject."&onetime=".$onetime."&validity=".$validity."&session_id=".$session_id;
						redirect($url);
			}
			
		}
		else{
			redirect("user/login");
		}

	}

	public function composeuploadstart(){
		if ($this->check_access()!=false) {
			$data['user']=$this->user_model->get_user($this->is_logged_in());
			$data['conf']=$this->user_model->config();
			//check for session
			
			$this->get_user_template('composeuploadstart',$data);
		}
		else{
			redirect("user/login");
		}
	}


	public function adduser(){
		if ($this->is_logged_in()!=false) {
			$data['user']=$this->user_model->get_user($this->is_logged_in());
			$data['groups']=$this->user_model->allgroups();
			//$data['myfiles']=$this->user_model->myfilessent($this->is_logged_in());

			$this->form_validation->set_error_delimiters('<div class="error" style="color:red">', '</div>');
		    	$config = array(
			        
			         array(
			                'field' => 'email',
			                'label' => 'email',
			                'rules' => 'required|valid_email|is_unique[user.email]'
			        ),
			        array(
			                'field' => 'password',
			                'label' => 'password',
			                'rules' => 'required'
			        ),
			        array(
			                'field' => 'confirmpassword',
			                'label' => 'Confirm Password',
			                'rules' => 'required|matches[password]'
			        ),
			        array(
			                'field' => 'name',
			                'label' => 'First Name',
			                'rules' => 'required'
			        ),
			        array(
			                'field' => 'lname',
			                'label' => 'Last Name',
			                'rules' => 'required'
			        ),
			        array(
			                'field' => 'phone',
			                'label' => 'Phone',
			                'rules' => 'required'
			        )
				);
				$this->form_validation->set_message('is_unique', 'Already exits. Please use another one or login into your existing account.');
			    $this->form_validation->set_rules($config);
				if ($this->form_validation->run() == FALSE)
				{
					$this->get_user_template('adduser',$data);
				}
				else
				{
						$data['message']=$this->user_model->adduser();
						if($data['message']==true){ 
							
							$this->get_user_template('adduser',$data);
						}
					    ///$this->get_user_template('login',$data);
					
				}		

		}
		else{
			redirect("user/login");
		}
	}

		public function edituser(){
			//echo'helo'; 
			$userid = $this->uri->segment(3); 
		if ($this->is_logged_in()!=false) {
			$data['user']=$this->user_model->get_user($userid);
			$data['groups']=$this->user_model->allgroups();
			//echo'<pre>';print_r($data);die;
			//$data['myfiles']=$this->user_model->myfilessent($this->is_logged_in());

			$this->form_validation->set_error_delimiters('<div class="error" style="color:red">', '</div>');
		    	$config = array(
			        
			         array(
			                'field' => 'email',
			                'label' => 'email',
			                'rules' => 'required|valid_email'
			        ),
			        array(
			                'field' => 'name',
			                'label' => 'First Name',
			                'rules' => 'required'
			        ),
			        array(
			                'field' => 'lname',
			                'label' => 'Last Name',
			                'rules' => 'required'
			        ),
			        array(
			                'field' => 'phone',
			                'label' => 'Phone',
			                'rules' => 'required'
			        )
				);
				//$this->form_validation->set_message('is_unique', 'Already exits. Please use another one or login into your existing account.');
			    $this->form_validation->set_rules($config);
				if ($this->form_validation->run() == FALSE)
				{
					$this->get_user_template('edituser',$data);
				}
				else
				{
					 $newpass = $this->input->post("newpassword");
					
					$data = array(
			            'name' => $this->input->post("name"), 
			            'lname' => $this->input->post("lname"), 
			            'phone' => $this->input->post("phone"), 
			            'email' => $this->input->post("email"), 
			            'group_id' => $this->input->post("group_id"),
			            'type' => $this->input->post("usertype") ,
			            'status' => "0" ,
			            );
					if($newpass != ''){
						 $data['password'] = md5($newpass);
					}
					if($this->user_model->edituser($userid,$data)){ 
							
							redirect("user/users");
						}
					    ///$this->get_user_template('login',$data);
					
				}		

		}
		else{
			redirect("user/login");
		}
	}

	public function deleteuser(){
        $id = $this->uri->segment(3);
        $this->user_model->deleteuser($id);
        redirect('/user/users');
    }

    public function deletegroup(){
        $id = $this->uri->segment(3);
        $this->user_model->deletegroup($id);
        redirect('/user/groups');
    }

	public function groups(){
		if ($this->check_access()!=false) {

			$data['user']=$this->user_model->get_user($this->is_logged_in());
			$data['groups']=$this->user_model->allgroups();
			$this->get_user_template('groups',$data);

		}
		else{
			redirect("user/login");
		}
	}

	public function viewgroup(){
		if ($this->check_access()!=false) {
			$gid = $this->uri->segment(3);

			//$data['user']=$this->user_model->get_user($this->is_logged_in());
			$data['groups']=$this->user_model->viewgroup($gid);
			//echo'<pre>';print_r($data['groups']); die;
			$this->get_user_template('groupusers',$data);

		}
		else{
			redirect("user/login");
		}
	}

	public function users(){
		if ($this->check_access()!=false) {

			$data['user']=$this->user_model->get_user($this->is_logged_in());
			$data['users']=$this->user_model->allusers();
			//var_dump($data['users']);
			$this->get_user_template('users',$data);

		}
		else{
			redirect("user/login");
		}
	}

	public function getajaxotpform(){
		if ($this->check_access()!=false) {

			//$data['user']=$this->user_model->get_user($this->is_logged_in());
			//$data['users']=$this->user_model->allusers();
			//var_dump($data['users']);
			$this->get_user_template_ajax('getajaxotpform');

		}
		else{
			redirect("user/login");
		}
	}

	public function getajaxotpformsubmit(){
		if ($this->check_access()!=false) {
			//$data['user']=$this->user_model->get_user($this->is_logged_in());
			//$data['users']=$this->user_model->allusers();
			//var_dump($data['users']);
			$this->sendotponly($this->input->post("sentto"),"mailview",$this->input->post("mailid"));
			//$this->session->set_flashdata("messageotp","<p class='alert alert-success'>OTP has been sent.</p>");
			$this->get_user_template_ajax('getajaxotpform');

		}
		else{
			redirect("user/login");
		}
	}

	public function checkotpformailview(){
		if ($this->check_access()!=false) {
			$mailid=$this->input->post("mailid");
			$otp=$this->input->post("otp");
			$val=$this->db->select()->where(array('user_id' => $this->is_logged_in(),"mailid" => $mailid,"otp" => $otp ,"status" => 0 ))->get("session");
			if($val->num_rows()>0){
				echo "true";
				$this->db->where(array('user_id' => $this->is_logged_in(),"mailid" => $mailid,"otp" => $otp ))->update("session",array('status' => 1));
			}
			else{
				echo "false";
			}

		}
		else{
			redirect("user/login");
		}
	}

	public function checkotpfordownload(){
		if ($this->check_access()!=false) {
			$mailid=$this->input->post("mailid");
			$otp=$this->input->post("otp");
			$userid=$this->input->post("userid");
			$val=$this->db->select()->where(array('user_id' => $userid,"mailid" => $mailid,"otp" => $otp ,"status" => 0 ,"type" => "download" ))->get("session");
			if($val->num_rows()>0){
				echo "true";
				$this->db->where(array('user_id' => $userid,"mailid" => $mailid,"otp" => $otp ))->update("session",array('status' => 1));
			}
			else{
				echo "false";
			}

		}
		else{
			redirect("user/login");
		}
	}

	public function checkotpfordownloadsingle(){
		if ($this->check_access()!=false) {
			$mailid=$this->input->post("mailid");
			$otp=$this->input->post("otp");
			$userid=$this->input->post("userid");
			$val=$this->db->select()->where(array('user_id' => $userid,"mailid" => $mailid,"otp" => $otp ,"status" => 0 ,"type" => "download" ))->get("session");
			if($val->num_rows()>0){
				echo "true";
				$this->db->where(array('user_id' => $userid,"mailid" => $mailid,"otp" => $otp ))->update("session",array('status' => 1));
			}
			else{
				echo "false";
			}

		}
		else{
			redirect("user/login");
		}
	}

	public function forward($mailid){
		if ($this->check_access()!=false) {
			$val=$this->db->select("f.*,s.name as sendername,s.email as senderemail,r.name as recivername,r.email as reciveremail")->
			where(array('f.files_id' => $mailid))->
			join("user s","s.user_id=f.user_id")->
			join("user r","r.user_id=f.staff_id")->
			get("files f");
			if($val->num_rows()>0){
				$data['files']=$val->row();
				$this->get_user_template('forwardmail',$data);

			}
			else{
				echo "false";
			}
		}
		else{
			redirect("user/login");
		}
	}

	public function forwardsubmit(){
		if ($this->check_access()!=false) {
			$staff=trim($this->input->post("email"), ",");
			$staffnew=explode(',',$staff);
			$user_id=$this->is_logged_in();
			foreach ($staffnew as $key => $value) {
						//check for user
						$query=$this->db->query("select * from user where email='$value'");
						$query2=$this->db->query("select * from user where user_id='$user_id'");
						$senddata['sender']=$query2->row();

						if($query->num_rows()>0)
						{
							$query=$query->row();
							$data=$this->db->select()->where("files_id",$this->input->post("mailid"))->get("files")->row_array();
								//send email for shared files
								
								//insertnew row
								$newdata = array(
									'user_id' => $this->is_logged_in(), 
									'staff_id' => $query->user_id, 
									'session_id' => $data['session_id'], 
									'filename' => $data['filename'], 
									'filesize' => $data['filesize'], 
									'totalfilesize' => $data['totalfilesize'], 
									'description' => $data['description'], 
									'subject' => $data['subject'], 
									'validity' => $data['validity'], 
									'expiry' => $data['expiry'], 
									);
								$this->db->insert("files",$newdata);
								$newfileid=$this->db->insert_id();
								//data to send
								$senddata['user']=$query;
								$senddata['files']=$data;
								$senddata['files']['files_id']=$newfileid;
								$this->ouremail->sendemail("Files shared with you","fileshared",$senddata,$value);
						}
						else
						{
							//$query=$query->row();

							$password=rand(100000,999999);
							$expiry=date("d-m-Y");
		       				$expiry=date("d-m-Y",strtotime("+90 days"));
							//insert new user first
							$data = array(
				            'name' => "", 
				            'email' => $value, 
				            'password' => md5($password),
				            'department' => "",
				            'type' => "1" ,
				            'status' => "2" ,		            
		            		'package_id' => "1" ,
		            		'package_validity' => $expiry ,
				            );
				            $this->db->insert("user",$data);
				            $new_user_id=$this->db->insert_id();
				            //insert files to new user
				            //email to new user//
				            $senddatanewuser = array(
				            	'password' => $password,
				            	'email' => $value,
				            	'user_id' => $new_user_id,
				            	 );
				            $this->ouremail->sendemail("You have been signed up","welcomenew",$senddatanewuser,$value);
				            //email to new user//
				            $data=$this->db->select()->where("files_id",$this->input->post("mailid"))->get("files")->row_array();
				            $query_new=$this->db->query("select * from user where user_id='$new_user_id'");
				            	
				            	$newdata = array(
									'user_id' => $this->is_logged_in(), 
									'staff_id' => $new_user_id, 
									'session_id' => $data['session_id'], 
									'filename' => $data['filename'], 
									'filesize' => $data['filesize'], 
									'totalfilesize' => $data['totalfilesize'], 
									'description' => $data['description'], 
									'subject' => $data['subject'], 
									'validity' => $data['validity'], 
									'expiry' => $data['expiry'], 
									);
								$this->db->insert("files",$newdata);
								$newfileid=$this->db->insert_id();

								$senddata['user']=$query_new->row();
								$senddata['files']=$data;
								$senddata['files']['files_id']=$newfileid;

								$this->ouremail->sendemail("Files shared with you","fileshared",$senddata,$value);
						}
						//check for user
					
						$this->session->set_flashdata("forwardmessage","<p class='alert alert-success'>File has been forwarded.</p>");
					}
					redirect("user/forward/".$this->input->post("mailid"));
		}
		else{
			redirect("user/login");
		}
	}
	

}//class

