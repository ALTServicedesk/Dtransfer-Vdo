<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Files extends My_Controller {

	function __construct()
	{
		parent::__construct();
        $this->load->model('User_model','user_model');
        $this->load->model('files_model','files_model');

	}
	function get_client_ip_server() {
	 $ipaddress = '';
    if (isset($_SERVER['HTTP_CLIENT_IP']))
        $ipaddress = $_SERVER['HTTP_CLIENT_IP'];
    else if(isset($_SERVER['HTTP_X_FORWARDED_FOR']))
        $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
    else if(isset($_SERVER['HTTP_X_FORWARDED']))
        $ipaddress = $_SERVER['HTTP_X_FORWARDED'];
    else if(isset($_SERVER['HTTP_FORWARDED_FOR']))
        $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
    else if(isset($_SERVER['HTTP_FORWARDED']))
        $ipaddress = $_SERVER['HTTP_FORWARDED'];
    else if(isset($_SERVER['REMOTE_ADDR']))
        $ipaddress = $_SERVER['REMOTE_ADDR'];
    else
        $ipaddress = 'UNKNOWN';
    return $ipaddress;
}

	public function index()
	{
		//$data['home']=true;
		if ($this->is_logged_in()!=false) {
			redirect("user/dashboard");
		}
		else
			$this->get_user_template('index',$data);
	}

	public function getfiles($sesssion_id,$sesssion_key){
		if ($this->is_logged_in()!=false) {
			$data['files']=$this->files_model->getfiles($sesssion_id,$sesssion_key,$this->is_logged_in());
			$this->get_user_template('getfiles',$data);			
		}
		else
			$this->get_user_template('user/login',$data);
	}

	public function download($user_id){
		$file_url = "./server/php/files/". $this->input->get('filename');
			
		//$data = file_get_contents($file_url); // Read the file's contents
		//var_dump($data);
		//$name = $this->input->get('filename');
		//$this->files_model->insert_download($this->is_logged_in(),$name,filesize($file_url),$this->get_client_ip_server());
		//force_download($name, $data); 
		$file = $file_url;
		// Quick check to verify that the file exists
		//file name		
		$name=explode(".", basename($file));
		$newname = str_replace(' ', '', $name[0]); // Replaces all spaces with hyphens.
		$newname = preg_replace('/[^A-Za-z0-9\-]/', '', $newname); // Removes special chars.
		$newname= $newname.".".$name[1];
		//file name

		
		// Force the download
		$this->files_model->insert_download($user_id,$this->input->get('filename'),filesize($file),$this->get_client_ip_server());
		header("Content-Disposition: attachment; filename=" . $newname . "");
		header("Content-Length: " . filesize($file));
		header("Content-Type: application/octet-stream;");
		readfile($file);
	}

	public function downloadmultiple(){
		$files=ltrim($this->input->get('filename'),",");
		$files=explode(",", $files);
		//var_dump($files);
		foreach ($files as $key => $value) {
			$file_url = "./server/php/files/". trim($value);
				
			$data = file_get_contents($file_url); // Read the file's contents
			//var_dump($data);
			$name = $value;
			force_download($name, $data); 
			# code...
		}
	}

	public function accessfiles($user_id,$mailid,$filename=""){
		//echo trim($filename);
		$filename = str_replace('%20', ' ', $filename);
		$mailid=base64_decode($mailid);

		//echo checkdownload(trim($filename),$user_id);
		 $checkmail=$this->db->select("*")->where(array('staff_id' => $user_id, "files_id" =>$mailid ))->get("files");
		    if($checkmail->num_rows()>0)
		    {
		    	if(checkdownload(trim($filename),$user_id,$mailid)==false)
		    	{
		    		if($this->config->item("user_allow_otp_email")=="yes" || $this->config->item("user_allow_otp_phone")=="yes")
					{
			    	$data['home']=true;
					$data['user']=$this->user_model->get_user($this->is_logged_in());
					$data['mailid']=$mailid;
					$data['onetime']=$this->files_model->onetime($data['mailid']);
					$data['user_id']=$user_id;
					$data['filename']=$filename;
					$data['useremail']=$this->user_model->get_user($user_id);
					$this->get_user_template('requestotpdownloadsingle',$data);
					}
					else{
						$data['session_id']=$this->user_model->genTempsession($user_id,"download",$mailid);
						$otp=$this->db->where("session_id",$data['session_id'])->get("session")->row()->otp;
						$this->db->where("session_id",$data['session_id'])->update("session", array('status' => 1));
						redirect(base_url().'files/viewfile/'.base64_encode($user_id).'/'.base64_encode($mailid)."/".base64_encode($otp)."/".base64_encode($filename));
					}
		    	}
		    	else{
		    		show_error("File is Already Downloaded. Please visit link properly.", "200", $heading = 'Already Donwloaded.');

		    	}
		    }
		    else{
		    	 show_error("Link is expired or tempered. Please visit link properly.", $status_code, $heading = 'Url is tempered.');
		    }
		
	}

	public function accessallfiles($user_id,$mailid,$filename=""){
			 $mailid=base64_decode($mailid);
		    //check if mail id and user id exists
		    $checkmail=$this->db->select("*")->where(array('staff_id' => $user_id, "files_id" =>$mailid ))->get("files");


			//redirect("user/myfilesreceived");
		   
		    if($checkmail->num_rows()>0)
		    {

			//check for OTP is disabled

				if($this->config->item("user_allow_otp_email")=="yes" || $this->config->item("user_allow_otp_phone")=="yes")
				{
				    	$data['home']=true;
						$data['user']=$this->user_model->get_user($this->is_logged_in());
						$data['mailid']=$mailid;
						$data['onetime']=$this->files_model->onetime($data['mailid']);
						$data['user_id']=$user_id;
						$data['useremail']=$this->user_model->get_user($user_id);
						$this->get_user_template('requestotpdownload',$data); // change to ot			
				}
				else
				{	
					$data['session_id']=$this->user_model->genTempsession($user_id,"download",$mailid);
					$otp=$this->db->where("session_id",$data['session_id'])->get("session")->row()->otp;
					$this->db->where("session_id",$data['session_id'])->update("session", array('status' => 1));
					redirect(base_url().'files/viewallfiles/'.base64_encode($user_id).'/'.base64_encode($mailid)."/".base64_encode($otp));
				}
		    }
		    else{
		    	show_error("Link is expired or tempered. Please visit link properly.", "200", $heading = 'Url is tempered.');
		    }

	}

	public function viewallfiles($userid,$mailid,$otp=""){
			//redirect("user/myfilesreceived");
		    $mailid=base64_decode($mailid);
		    $otp=base64_decode($otp);
		    $userid=base64_decode($userid);
		    //check if mail id and user id exists
		    $checkmail=$val=$this->db->select()->where(array('user_id' => $userid,"mailid" => $mailid,"otp" => $otp ,"status" => 1 ,"type" => "download" ))->get("session");;
		    if($checkmail->num_rows()>0)
		    {
		    	$data['home']=true;
				$data['mailid']=$mailid;
				$data['user_id']=$userid;
				$data['user']=$this->user_model->get_user($this->is_logged_in());
				$data['onetime']=$this->files_model->onetime($data['mailid']);
				$data['files']=$this->files_model->getfilesdetails($data['mailid']);
				$data['useremail']=$this->user_model->get_user($userid);
				$this->get_user_template('viewallfiles',$data); // change to ot
		    }
		    else{
		    	show_error("Link is expired or tempered. Please visit link properly.", "200", $heading = 'Url is tempered.');echo "url temrd";
		    }

	}

	public function viewfile($userid,$mailid,$otp,$filename){
			//redirect("user/myfilesreceived");
		    $mailid=base64_decode($mailid);
		    $otp=base64_decode($otp);
		    $userid=base64_decode($userid);
		    $filename=base64_decode($filename);
		    //check if mail id and user id exists
		    $checkmail=$val=$this->db->select()->where(array('user_id' => $userid,"mailid" => $mailid,"otp" => $otp ,"status" => 1 ,"type" => "download" ))->get("session");;
		    if($checkmail->num_rows()>0)
		    {

		    	$data['home']=true;
				$data['mailid']=$mailid;
				$data['user_id']=$userid;
				$data['user']=$this->user_model->get_user($this->is_logged_in());
				$data['onetime']=$this->files_model->onetime($data['mailid']);
				//$data['files']=$this->files_model->getfilesdetails($data['mailid']);
				$data['useremail']=$this->user_model->get_user($userid);
				$data['filename']=$filename;
				$this->get_user_template('viewfile',$data); // change to ot
		    }
		    else{
		    	show_error("Link is expired or tempered. Please visit link properly.", "200", $heading = 'Url is tempered.');
		    }

	}

	public function delete($filesid,$from){
		$files=$this->db->get_where("files",array("files_id"=>$filesid));
		$files=$files->row();
		$filenames=explode(",",$files->filename);

		foreach ($filenames as $key => $value) {
			unlink("./server/php/files/".trim($value));
		}
		$this->db->delete("files",array("files_id"=>$filesid));
		//var_dump($files->result());
		redirect("user/".$from);
	}

	public function trash($mailid,$from){
		if($from=="sentmail"){
			$this->db->where("files_id",$mailid)->update("files",array('delete_user' => 1, ));
		}
		if($from=="inbox"){
			$this->db->where("files_id",$mailid)->update("files",array('delete_recevier' => 1, ));
		}
		//check if both removed
		$file=$this->db->select("")->where("files_id",$mailid)->get("files")->row();
		if($file->delete_user=='1' && $file->delete_recevier==1){
			$this->db->where("files_id",$mailid)->update("files",array('delete_all' => 1, ));
		}
		$this->session->set_flashdata("deletemessage","<p class='alert alert-danger'>Message deleted.</p>");
		if($from=="sentmail")
			redirect("user/sentmail");
		else{
			redirect("user/mail");
		}
	}

	public function autoclean(){
		$date=date('Y-m-d H:i:s');
		$query=$this->db->query("select * from files where `expiry` <'$date'");
		//echo $query->num_rows();
		$query=$query->result();
		foreach ($query as $key => $value) {
					 $files=explode(",",$value->filename);
					 foreach ($files as $key2 => $value2) {
					 	unlink("./server/php/files/". trim($value2));
					 }
				}
		$this->db->query("delete  from files where `expiry` <'$date'");
		
		$data['user']=$this->user_model->get_user($this->is_logged_in());
		$this->get_user_template('autoclean',$data);
	}

	public function getFile($filename=''){
		$filenamenew=trim($this->input->post("filename"));
		$path=base_url()."server/php/files/".$filenamenew ;
		echo "<p class='text-center'><a href='".base_url()."files/download/".$this->is_logged_in()."?filename=".$filenamenew."' class='btn btn-sm btn-primary'>Download</a></p>";
		$ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
		if($ext=='jpg' || $ext=='jpeg' || $ext=='png' || $ext=='gif')
		{
			echo "<img src='".$path."' width='100%'>";
		}
	}
}
