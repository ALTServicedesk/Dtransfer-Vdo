public function accessallfiles($user_id,$sesssion_id,$filename=""){
			//redirect("user/myfilesreceived");
			if($this->input->post('otp'))
			{
				$otp=$this->input->post('otp');
				$auth=$this->user_model->check_otp($user_id,$otp);
				if($auth!=false)
				{
					$data['session_id']=$auth->session_id;
					$data['user']=$this->user_model->get_user($this->is_logged_in());
					$data['useremail']=$this->user_model->get_user($user_id);
					$data['staff']=$this->user_model->get_all_staff();
					$data['home']=true;
					$data['session_id']=$sesssion_id;
					$data['onetime']=$this->files_model->onetime($data['session_id']);
					$data['user_id']=$user_id;
					//$data['filename']=$filename;
					$session_id=base64_decode($sesssion_id);
					$data['files']=$this->files_model->getfiles($session_id);
					$this->db->query("update session set status='1' where otp='$otp' and type='download' and status='0'");
					
					$this->get_user_template('downloadall',$data);
				}
				else
				{
					$data['otp']=$otp;	
					//$data['session_id']=NULL;				
					$this->user_model->get_otp($user_id,"download");
					$data['error']="Wrong OTP Entered";
					$data['user']=$this->user_model->get_user($this->is_logged_in());
					$data['home']=true;					
					$data['session_id']=$sesssion_id;
					$data['onetime']=$this->files_model->onetime($data['session_id']);
					$data['user_id']=$user_id;
					$data['useremail']=$this->user_model->get_user($user_id);
					//$data['filename']=$filename;
					//$data['staff']=$this->user_model->get_all_staff();
					$this->get_user_template('downloadallfiles',$data); // change to otp
				}
			}
			else
			{
				
				$this->user_model->get_otp($user_id,"download");
				$data['user']=$this->user_model->get_user($this->is_logged_in());
				$data['home']=true;
				$data['session_id']=$sesssion_id;
				$data['onetime']=$this->files_model->onetime($data['session_id']);
				$data['user_id']=$user_id;
				$data['useremail']=$this->user_model->get_user($user_id);
				//$data['filename']=$filename;
				//$data['staff']=$this->user_model->get_all_staff();
				$this->get_user_template('downloadallfiles',$data); // change to otp
			}
		

	}

	if(checkdownload(trim($filename),$user_id,base64_decode($sesssion_id))==false){
			//redirect("user/myfilesreceived");
			if($this->input->post('otp'))
			{
				$otp=$this->input->post('otp');
				$auth=$this->user_model->check_otp($user_id,$otp);
				if($auth!=false)
				{
					$data['session_id']=$auth->session_id;
					$data['user']=$this->user_model->get_user($this->is_logged_in());
					$data['useremail']=$this->user_model->get_user($user_id);
					$data['staff']=$this->user_model->get_all_staff();
					$data['home']=true;
					$data['session_id']=$sesssion_id;
					$data['onetime']=$this->files_model->onetime($data['session_id']);
					$data['user_id']=$user_id;
					$data['filename']=$filename;
					$session_id=base64_decode($sesssion_id);
					$this->db->query("update session set status='1' where otp='$otp' and type='download' and status='0'");
					
					$this->get_user_template('download',$data);
				}
				else
				{
					$data['otp']=$otp;	
					//$data['session_id']=NULL;				
					$this->user_model->get_otp($user_id,"download");
					$data['error']="Wrong OTP Entered";
					$data['user']=$this->user_model->get_user($this->is_logged_in());
					$data['home']=true;					
					$data['session_id']=$sesssion_id;
					$data['onetime']=$this->files_model->onetime($data['session_id']);
					$data['user_id']=$user_id;
					$data['useremail']=$this->user_model->get_user($user_id);
					$data['filename']=$filename;
					//$data['staff']=$this->user_model->get_all_staff();
					$this->get_user_template('downloadfiles',$data); // change to otp
				}
			}
			else
			{
				
				$this->user_model->get_otp($user_id,"download");
				$data['user']=$this->user_model->get_user($this->is_logged_in());
				$data['home']=true;
				$data['session_id']=$sesssion_id;
				$data['onetime']=$this->files_model->onetime($data['session_id']);
				$data['user_id']=$user_id;
				$data['filename']=$filename;
				$data['useremail']=$this->user_model->get_user($user_id);
				//$data['staff']=$this->user_model->get_all_staff();
				$this->get_user_template('downloadfiles',$data); // change to otp
			}
		}else{
			$data['user']=$this->user_model->get_user($this->is_logged_in());
				$data['home']=true;
			$data['alreadydownload']="File is already downloaded ";
			$this->get_user_template('downloadfiles',$data); // change to otp
		}
