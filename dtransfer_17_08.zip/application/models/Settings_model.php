<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Settings_model extends My_Model {


	function __construct()
	{
		parent::__construct();      
        $this->load->model('Ouremail','ouremail');
	}


    public function getallmessages(){
        $return = array();

        $this->db->where("category","error");
        $language=$this->db->get("language");
        $return['error']=$language->result();

        $this->db->where("category","success");
        $language=$this->db->get("language");
        $return['success']=$language->result();

        $this->db->where("category","warning");
        $language=$this->db->get("language");
        $return['warning']=$language->result();

        $this->db->where("category","general");
        $language=$this->db->get("language");
        $return['general']=$language->result();

        $this->db->where("category","information");
        $language=$this->db->get("language");
        $return['information']=$language->result();

        return $return;
    }

    public function savemessages(){

        foreach ($this->input->post() as $key => $value) {
           $data = array(
               'token' => $value,
            );
            $this->db->where('language_id', $key);
            $this->db->update('language', $data); 
        }

        $this->updatelangfile();

    }



    public function getsiteconfig(){

        $this->db->where("category","general");
        $language=$this->db->get("config");
        $return['general']=$language->result();

        $this->db->where("category","user");
        $language=$this->db->get("config");
        $return['user']=$language->result();
        
        return $return;
    }

    public function saveconfig(){

        foreach ($this->input->post() as $key => $value) {
           $data = array(
               'token' => $value,
            );
            $this->db->where('config_id', $key);
            $this->db->update('config', $data); 
        }

        $this->updateconfigfile();

    }

    function updatelangfile($my_lang="english"){
        $this->db->where('lang',$my_lang);
        $query=$this->db->get('language');

        $lang=array();
        $langstr="<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');\n";
        foreach ($query->result() as $row){
            //$lang['error_csrf'] = 'This form post did not pass our security checks.';
            $langstr.= "\$lang['".$row->category."_".$row->key."'] = \"$row->token\";"."\n";
        }
        write_file('./application/language/'.$my_lang.'/general_lang.php', $langstr);

    }

    function updateconfigfile($my_lang="english"){
        $this->db->where('lang',$my_lang);
        $query=$this->db->get('config');

        $lang=array();
        $langstr="<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');\n";
        foreach ($query->result() as $row){
            //$lang['error_csrf'] = 'This form post did not pass our security checks.';
            $langstr.= "\$config['".$row->category."_".$row->key."'] = \"$row->token\";"."\n";
        }
        write_file('./application/config/systemconfig.php', $langstr);

    }
}
