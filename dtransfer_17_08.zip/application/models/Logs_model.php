<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Logs_model extends My_Model {


	function __construct()
	{
		parent::__construct();      
        $this->load->model('Ouremail','ouremail');
	}


	public function allotp(){
        $query=$this->db->query("select * from session order by `timestamp`");
        foreach ($query->result() as $key => $value) {
            	$data[]=$value;
            	$query2 = $this->db->query("select name,email from user where user_id='$value->user_id' ");
                if($query2->num_rows()>0){
                    $query2=$query2->row();
                    $data[$key]->name=$query2->name;
                    $data[$key]->email=$query2->email;
                    $query3 = $this->db->query("select * from files where session_id='$value->session_id' ");
                    if($query3->num_rows()>0){
                    $query3=$query3->row();
                        $sentto=$query3->staff_id;
                        $query4 = $this->db->query("select email from user where user_id='$sentto' ");
                        if($query4->num_rows()>0){
                        $query4=$query4->row();
                        $data[$key]->sentemail=$query4->email;
                        }
                        else{
                           $data[$key]->sentemail="N/A";  
                        }
                    }
                    else{
                        $data[$key]->sentemail="N/A";

                    }
                }
                else{
                    $data[$key]->name="N/A";
                    $data[$key]->email="N/A";
                    $data[$key]->sentemail="N/A";

                }   

            }    
            return  $data;
    }

    public function downloadlogs(){
        $query=$this->db->query("select * from download order by `timestamp`");
        if($query->num_rows()>0){
            foreach ($query->result() as $key => $value) {
                    $data[]=$value;
                    $query2 = $this->db->query("select name,email from user where user_id='$value->user_id' ");
                    $query2=$query2->row();
                    $data[$key]->name=$query2->name;
                    $data[$key]->email=$query2->email;
                }    
        }
        else{
            $data=null;
        }
            return  $data;
    }

     public function readlogs($type){
        
        //read files
        /// create an array to hold directory list
        $results = array();

        // create a handler for the directory
        $directory = FCPATH."application/logs";
        $handler = opendir($directory);
        $i=0;
        // open directory and walk through the filenames
        while ($file = readdir($handler)) {

            // if file isn't this directory or its parent, add it to the results
            if ($file != "." && $file != "..") {

                // check with regex that the file format is what we're expecting and not something else
                if($type=="system"){
                    if(preg_match('#^(log)[^\s]*\.#', $file)) {
                        // add to our file array for later use
                        $results[$i]['filename'] = $file;
                        $results[$i]['filesize'] = filesize($directory.'/'.$file);
                        $results[$i]['filemtime'] = filemtime($directory.'/'.$file);
                    }                    
                }
                else{
                     if(preg_match('#^('.$type.'-log)[^\s]*\.#', $file)) {
                        // add to our file array for later use
                        $results[$i]['filename'] = $file;
                        $results[$i]['filesize'] = filesize($directory.'/'.$file);
                        $results[$i]['filemtime'] = filemtime($directory.'/'.$file);
                    }
                }
            }
            $i++;
        }

            return  $results;
    }

     function sortfilenames(&$array, $subfield)
            {
                $sortarray = array();
                foreach ($array as $key => $row)
                {

                    $sortarray[$key]['filemtime'] = $row[$subfield];
                    $sortarray[$key]['filesize'] = $row['filesize'];
                    $sortarray[$key]['filename'] = $row['filename'];

                }
                 array_multisort($sortarray, SORT_DESC, $array);
               return $sortarray;
            }  

    public function getlatestlog($type){
            $data['errorlogs']=$this->logs_model->readlogs($type);                    
            $data['heading']=ucfirst($type)." Logs";
            $data['errorlogs']=$this->sortfilenames($data['errorlogs'],"filemtime");
            if($data['errorlogs'])
            {
                $file = file(FCPATH."application/logs/".$data['errorlogs'][0]['filename']);
                $file = array_reverse($file);                
            }else{
                $file= array();
            }
            return $file;
    }

	
}