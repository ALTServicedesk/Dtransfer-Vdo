<?php
class Ouremail extends MY_Model
{
	
	function __construct()
	{
		parent::__construct();
		$this->load->model('User_model','user_model');
	}
   

   	public function sendemail($subject,$template,$data,$to,$cc="")
	{	
				$config=$this->user_model->configuration();
				$fromuser=$config->smtpuser;
					   $config = Array(
					  'protocol' => 'smtp',
					  'smtp_host' => $config->smtphost,
					  'smtp_port' => $config->smtpport,
					  'smtp_user' => $config->smtpuser, // change it to yours
					  'smtp_pass' => $config->smtppass, // change it to yours
					  'mailtype' => 'html',
					  'charset' => 'iso-8859-1',
					  'wordwrap' => TRUE,
					  'newline' => "\r\n"
					);

		      $message = '';
		      $this->load->library('email', $config);
		      $this->email->set_mailtype("html");
		      $this->email->initialize($config);  
		      $this->email->set_newline("\r\n");  
		      $this->email->from($fromuser); // change it to yours
		      $this->email->to($to);// change it to yours
		      //cc
		      if($template!="welcomenew"){
		      $cc=trim($this->input->post("cc"), ",");
			  //$ccnew=explode(',',$cc);
			  $this->email->cc($cc);
				}
		      //cc
		      $this->email->subject($subject);
		      $abc['settings']=$this->user_model->configuration();
		      $abc['baseurl']=base_url();
		      $abc['message']=$data;
		      $mesg = $this->load->view('email/'.$template,$abc,true);
		    /* $mesg = $this->load->view('email/'.$template,$abc);*/
		      $this->email->message($mesg);
		     if($this->email->send()){
		     log_message('info', 'An email sent to '.$to.' for '.$template,'smtp');
		     }
		     
		     else
		    {
		     show_error($this->email->print_debugger());
		    }

		}
    
}