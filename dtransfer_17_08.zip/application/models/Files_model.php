<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Files_model extends My_Model {


	function __construct()
	{
		parent::__construct();      
        $this->load->model('Ouremail','ouremail');
	}


	public function getfiles($sesssion_id,$sesssion_key="",$user_id=""){
        $query=$this->db->query("select filename from files where session_id='$sesssion_id'");
        return  $query->row();         
    }

    public function getfilesdetails($mailid){
        $query=$this->db->query("select * from files where files_id='$mailid'");
        return  $query->row();         
    }

    public function insert_download($user_id,$name,$size,$ip){
    	$data = array(
    		'user_id' => $user_id, 
    		'filename' => $name, 
    		'filesize' => $size, 
    		'ip' =>$ip,
    		);
    	$this->db->insert("download",$data);
    }

    public function onetime($files_id){
        $query=$this->db->query("select onetime from files where files_id='$files_id'");
        return  $query->row();   

    }

	
}