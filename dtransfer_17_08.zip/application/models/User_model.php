<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_model extends My_Model {


    function __construct()
    {
        parent::__construct();      

        $this->load->model('Ouremail','ouremail');
        $this->load->model('Files_model','files_model');
    }


    public function register(){
        $expiry=date("d-m-Y");
        $expiry=date("d-m-Y",strtotime("+90 days"));
        $data = array(
            'name' => $this->input->post("name"), 
            'lname' => $this->input->post("lname"), 
            'email' => $this->input->post("email"), 
            'phone' => $this->input->post("phone"), 
            'password' => md5($this->input->post("password")),
            'type' => "1" ,
            'status' => "0" ,
            'package_id' => "1" ,
            'package_validity' => $expiry ,
            );
            if($this->input->post("refid")=="")
            {
                $data['group_id']=$this->db->select('group_id')->where("default=1")->get("group")->row()->group_id;
            }
            else
            {
                $user=$this->db->select('*')->where("user_id",$this->input->post("refid"))->get("user");
                if($user->num_rows()>0){
                  echo  $data['group_id']=$user->row()->group_id;
                }
                else{
                    $data['group_id']=$this->db->select('group_id')->where("default=1")->get("group")->row()->group_id;
                }
            }
           $this->db->insert("user",$data);
            $new_user_id=$this->db->insert_id();

            $query = $this->db->query("select * from user where user_id='$new_user_id'");
            $row=$query->row();
            
            $this->ouremail->sendemail("Welcome","welcome-1",$row,$row->email);


            return "<p class='alert alert-success'>Registration successfull, We have sent you an email on ".$this->input->post("email")." please complete verification and then login. <a href='".base_url()."user/resendverification/$new_user_id'>Click Here</a> to resend.</p>";
    }

    public function support($user_id){
        $data = array(
            'subject' => $this->input->post("subject"), 
            'msg' => $this->input->post("msg")
            );

            $query = $this->db->query("select * from configuration where configuration_id='1'");
            $row=$query->row();
            $query2 = $this->db->query("select * from user where user_id='$user_id'");
            $row2=$query2->row();
            $emaildata["mail"]=$data;
            $emaildata["user"]=$row2;
            $this->ouremail->sendemail("Support Email","support",$emaildata,$row->email);


            return "<p class='alert alert-success'>Support email sent we will reply you shorlty</p>";
    }

    public function login(){
        $email = $this->input->post('emaillogin');
        $password = md5($this->input->post('passwordlogin'));
        $query = $this->db->query("select * from user where email='$email'");
        $row = $query->row();
        if($query->num_rows() == 1 && $row->password==$password){
                 
                        // If there is a user, then create session data
                        

                        if($row->status==1){
                            $data = array(
                                    'user_id' => $row->user_id,
                                    'validated' => true,
                                    'type' => $row->type
                                    );
                            $this->session->set_userdata($data);
                            $cookie = array(
                                'name'   => 'user_id',
                                'value'  => $row->user_id,
                                'expire' => '8650000'
                            ); 

                            log_message('info', $email.' is logged in.','user');

                            if($row->name!=""){

                                return 1;
                            }                                                     
                            else{
                                return 2;
                            }
                        }

                        elseif($row->status==3){
                            $message_login="<p class='alert alert-danger'>This account is deactivated.</p>";
                            log_message('info', $email.' tried to access deactivated account.','user');
                            return $message_login;
                        }
                        else{
                            $message_login="<p class='alert alert-danger'>Please verify your email address first. <a href='".base_url()."user/resendverification/".$row->user_id."'>Click Here</a> to resend verification email.</p</p>";
                            return $message_login;
                        }
               
            }
            else
            {

                $query=$this->db->get('ldap');
                $host=$query->row()->host;
                $port=$query->row()->port;
                $domain=$query->row()->domain;
                $adServer = $host;
                $domainsplit=explode(".",$domain);  
                $ldap = ldap_connect($adServer);
                $password =$this->input->post('passwordlogin');
                $ldaprdn = 'dc='.$domainsplit[0].',dc='.$domainsplit[1];
                ldap_set_option($ldap, LDAP_OPT_PROTOCOL_VERSION, 3);
                ldap_set_option($ldap, LDAP_OPT_REFERRALS, 0);
                $bind = @ldap_bind($ldap, $email, $password);
              /*  echo $password;
                die();*/
                if ($bind) {
                    $result = ldap_search($ldap,$ldaprdn, "(&(objectCategory=user))") or die ("Error in search query: ".ldap_error($ldap));
                    $data = ldap_get_entries($ldap, $result);
                    $emails = array();
                    $givenname = array();
                   for ($i=0; $i<$data["count"]; $i++) {
                    if (isset($data[$i]["userprincipalname"][0])) {
                        $emails[$i]=$data[$i]["userprincipalname"][0];
                        $givenname[$i]=$data[$i]["givenname"][0];
                    }
                   }
                 // $namekey = array_search($value, $emails);
    //echo "<pre>";                   
    //  var_dump($emails);
                   
                 //  die();
                    
                    $query=$this->db->where('email',$email)->get('user');
                    

                    if ($query->num_rows()>0) {
            $emailuser=$query->row()->email;
                    $user_id=$query->row()->user_id;
                            $data = array(
                            'password' => md5($this->input->post("passwordlogin")));
                            $this->db->where('user_id',$user_id)->update('user',$data);
                                    $data = array(
                                            'user_id' => $user_id,
                                            'validated' => true,
                                            );
                                    
                                    $cookie = array(
                                        'name'   => 'user_id',
                                        'value'  => $user_id,
                                        'expire' => '8650000'
                                    ); 
                                    $this->session->set_userdata($data);
                                    redirect("user/dashboard");      
                }
                else{
        

         $namekey = array_search(strtolower($email), array_map('strtolower', $emails));


                  // $namekey = array_search($email, $emails);
//die();
                    /*if(in_array($email,$emails)){
                        $givenname[$namekey];
                    }*/
                    $data = array(
                    'email' => $this->input->post("emaillogin"),
                    'name' => $givenname[$namekey],
                    'type' => "2",
                    'password' => md5($this->input->post("passwordlogin")),
                    'status' => 1,
                    );
                         $this->db->insert('user',$data);
                        $insert_id = $this->db->insert_id();
                        $data = array(
                                    'user_id' => $insert_id,
                                    'validated' => true,
                                    );
                            
                            $cookie = array(
                                'name'   => 'user_id',
                                'value'  => $insert_id,
                                'expire' => '8650000'
                            ); 
                            $this->session->set_userdata($data);
                        redirect("user/dashboard");
                }
            }else{
                $message_login="<p class='alert alert-danger'>Invalid Email/Password.</p>";
                log_message('error', $email.' failed login.','user');
                return $message_login;
            }
                
            }
    }

    public function forcedlogin($user_id){
        $query = $this->db->query("select * from user where user_id='$user_id' ");
        if($query->num_rows() == 1)
            {

                $row=$query->row();
                $this->session->sess_destroy();
                    $this->config->set_item('user_id','');
                    delete_cookie('user_id');

                
                            $data = array(
                                    'user_id' => $row->user_id,
                                    'validated' => true,
                                    'type' => $row->type
                                    );
                            
                            $this->session->set_userdata($data);                           
                       
            }
            else
            {
                $message_login="<p class='alert alert-danger'>Invalid Email/Password.</p>";
                return $message_login;
            }

    }


    function get_user($user_id)
    {
        $query = $this->db->query("select * from user where user_id='$user_id'");
         return $query->row();

    }
    function config()
    {
        $query = $this->db->get('configuration');
         return $query->row();

    }

    function get_group($g_id)
    {
        /*$query = $this->db->query("select * from group where group_id='$g_id'");
         return $query->row();*/
         $row = $this->db->where('group_id',$g_id)->limit(1)->get('group');
      return $row;

    }
    

    function resendverification($user_id)
    {
         $query = $this->db->query("select * from user where user_id='$user_id'");
         $row=$query->row();
         $this->ouremail->sendemail("Request For Verification","welcome-1",$row,$row->email);
         return "<p class='alert alert-success'>Please check email again for verification link.</p>";
    }

    function verifyemail($user_id,$md5email)
    {
        $user=$this->get_user($user_id);
        if($user){
                if(md5($user->email)==$md5email){
                    $data = array(
                    'status' => '1',
                     );
                   $this->db->where('user_id',$user_id);
                   $this->db->update('user',$data);
                   
                $message_verify="<p class='alert alert-success'>Email Verified please login.</p>";
                    
                }
                else{
                $message_verify="<p class='alert alert-danger'>Failed to verify email please visit link properly.</p>"; 
                }
        }
        else{
                $message_verify="<p class='alert alert-danger'>No user found.</p>"; 

        }

        
        return $message_verify;
    }

    function get_all_staff()
    {
        $query = $this->db->query("select * from user where type='2'");
        return $query->result();

    }

    function get_all_user()
    {
        $query = $this->db->query("select * from user where type='1' or type='2' ");
        return $query->result();

    }

    function addstaffregister()
    {
        $data = array(
            'name' => $this->input->post("name"), 
            'email' => $this->input->post("email"), 
            'password' => md5($this->input->post("password")),
            'department' => $this->input->post("department"),
            'type' => $this->input->post("usertype") ,
            'status' => "0" ,
            );
            $this->db->insert("user",$data);
            $new_user_id=$this->db->insert_id();

            $query = $this->db->query("select * from user where user_id='$new_user_id'");
            $row=$query->row();
            
            $this->ouremail->sendemail("Welcome","welcome-1",$row,$row->email);


            return "<p class='alert alert-success'>User added successfully, We have sent you an email on ".$this->input->post("email")." user can complete the verification and then login.</p>";
    }

    function adduser()
    {
        $data = array(
            'name' => $this->input->post("name"), 
            'lname' => $this->input->post("lname"), 
            'phone' => $this->input->post("phone"), 
            'email' => $this->input->post("email"), 
            'password' => md5($this->input->post("password")),
            'group_id' => $this->input->post("group_id"),
            'type' => $this->input->post("usertype") ,
            'status' => "0" ,
            );
            $this->db->insert("user",$data);
            $new_user_id=$this->db->insert_id();
            $query = $this->db->query("select * from user where user_id='$new_user_id'");
            $row=$query->row();
            $this->ouremail->sendemail("Welcome","welcome-1",$row,$row->email);
            log_message('info', $row->email.' new user added.','user');
            return "<p class='alert alert-success'>User added successfully, We have sent you an email on ".$this->input->post("email")." user can complete the verification and then login.</p>";
    }

    function edituser($uid,$data)
    {
            $this->db->where('user_id', $uid);
            $this->db->update("user",$data);
            return "<p class='alert alert-success'>User Updated successfully!</p>";
            
    }

    function editgroup($gid,$data)
    {
            $this->db->where('group_id', $gid);
            $this->db->update("group",$data);
            return "<p class='alert alert-success'>User Updated successfully!</p>";
            
    }

    function viewgroup($gid)
    {
           $result = $this->db->where('group_id',$gid)->get('user')->result();
      return $result;
            
    }

    function deleteuser($uid)
   {
      $this->db->where('user_id', $uid);
      $this->db->delete('user');
      $this->db->where('user_id', $uid);
      $this->db->delete('session');
      $this->db->where('user_id', $uid);
      $this->db->delete('download');
      $this->db->where('user_id', $uid);
      $this->db->delete('files');
      return true;
   }


    function deletegroup($gid)
   {
     $query = $this->db->query("select user_id from user where group_id=".$gid);
    $users = $query->result();
    //echo'<pre>'; print_r($users); die;
    foreach ($users as $value) {
      $ans = $this->deleteuser($value->user_id);
    }
     
        $this->db->where('group_id', $gid);
        $this->db->delete('group');
        return true;
    
    //$this->deleteuser()
      
   }

     function addgroup()
    {
        $data = array(
            'name' => $this->input->post("name")
            );
            $this->db->insert("group",$data);
            

            return "<p class='alert alert-success'>Group added successfully.</p>";

    }
    
    function allgroups()
    {   
        $this->db->select('g.*, COUNT(u.user_id) as totalusers');
        $this->db->from('group g');
        $this->db->join('user u', 'g.group_id = u.group_id',"left"); 
        $this->db->group_by('g.group_id');
        return $this->db->get()->result();;
    }

    function allusers()
    {   
        $this->db->select('u.*,g.name as groupname');
        $this->db->from('user u');
        $this->db->join('group g', 'g.group_id = u.group_id',"left"); 
        return $this->db->get()->result();;
    }

    function myfilessent($user_id)
    {
       /* $query = $this->db->query("select user_id,files_id,group_concat(staff_id) as staffarray,description,validity,timestamp,session_id from files where user_id='$user_id' group by session_id order by `timestamp` desc");*/

        
         $query = $this->db->query("select user_id,subject,files_id,filename,group_concat(staff_id) as staffarray,description,validity,timestamp,session_id from files where user_id='$user_id' and delete_user='0'  group by timestamp order by `timestamp` desc");
        if($query->num_rows()>0)
        {
            foreach ( $query->result() as $key => $value) {
                $data[]=$value;
                $staffarray=explode(",", $value->staffarray);
                foreach ($staffarray as $key2 => $value2) {
                    //echo $value2;
                    $query2 = $this->db->query("select name,email,image from user where user_id='$value2' ");
                    if($query2->num_rows()>0){
                        $query2=$query2->row();
                        $staff[$key2] = new stdClass();                   

                        $data[$key]->staff[$key2]['email']=$query2->email;
                        $data[$key]->staff[$key2]['image']=$query2->image;
                        $data[$key]->staff[$key2]['name']=$query2->name;
                
                    }
                    else{
                        $staff[$key2] = new stdClass();     
                        $data[$key]->staff[$key2]['email']="";
                        $data[$key]->staff[$key2]['image']="";
                        $data[$key]->staff[$key2]['name']="";
                        
                    }
                }
                $query3 = $this->db->query("select * from session where session_id='$value->session_id' ");
                $query3=$query3->row();
                //$data[$key]->session_key=$query3->session_key;
                $data[$key]->filesarray=$this->files_model->getfiles($value->session_id,"","");

            }            
        }
        else
        {
            $data=NULL;
        }
        return $data;
    }

    function myfilesreceived($user_id)
    {
        $query = $this->db->query("select user_id,subject,files_id,filename,group_concat(staff_id) as staffarray,description,validity,timestamp,session_id from files where staff_id='$user_id' and delete_recevier='0' group by timestamp order by `timestamp` desc");
        if($query->num_rows()>0)
        {
            foreach ( $query->result() as $key => $value) {
                $data[]=$value;
                $staffarray=explode(",", $value->staffarray);
                foreach ($staffarray as $key2 => $value2) {
                    //echo $value2;
                    $query2 = $this->db->query("select name,email,image from user where user_id='$value2' ");
                    $query2=$query2->row();                    
                    $staff[$key2] = new stdClass();
                   
                    $data[$key]->staff[$key2]['email']=$query2->email;
                    $data[$key]->staff[$key2]['image']=$query2->image;
                    $data[$key]->staff[$key2]['name']=$query2->name;
                }
                $query3 = $this->db->query("select * from session where session_id='$value->session_id' ");
                $query3=$query3->row();
                //$data[$key]->session_key=$query3->session_key;
                $data[$key]->filesarray=$this->files_model->getfiles($value->session_id,"","");
            }            
        }
        else
        {
            $data=NULL;
        }
        return $data;
    }

    function get_otp($user_id,$type){

        $query=$this->db->query("select * from session where user_id='$user_id' and status='0' and type='$type'");
        if($query->num_rows()<=0)
        {
            //send and insert otp//
            $data = array(
                'session_key' => md5(rand(1,9999999)), 
                'otp' => rand(1000,9999), 
                'user_id' => $user_id, 
                'status' => '0', 
                'type' => $type, 
                );
            //send and insert otp//
            $this->db->insert("session",$data);
            $query = $this->db->query("select * from user where user_id='$user_id'");
            $row=$query->row();
            $datasend['user']=$row;
            $datasend['otp']= $data;
            $this->ouremail->sendemail("OTP Request","otp",$datasend,$row->email);
         }
    }

    function requestotp($user_id,$type){
        $query=$this->db->query("select * from session where user_id='$user_id' and status='0' and type='$type'");
        if($query->num_rows()>0)
        {
            $row=$query->row_array();
            $query2 = $this->db->query("select * from user where user_id='$user_id'");
            $row2=$query2->row();
            $datasend['user']=$row2;
            $datasend['otp']= $row;
            
            $this->ouremail->sendemail("Requested OTP","otp",$datasend,$row2->email);
         }
         else
         {
            $this->get_otp($user_id,$type);
         }
    }

    public function check_otp($user_id,$otp){
        $query=$this->db->query("select * from session where user_id='$user_id' and status='0' and otp='$otp'");
        //echo $otp;
        if($query->num_rows()>0)
            return $query->row();
        else
            return false;
    }

     public function configuration(){
        $query=$this->db->query("select * from configuration where configuration_id='1'");
        //echo $otp;
        if($query->num_rows()>0)
            return $query->row();
        else
            return false;
    }

     public function updateconfiguration(){
       $data = array(
        'title' => $this->input->post('title'),
        'email' => $this->input->post('email'),
        'address' => $this->input->post('address'),
        'phone' => $this->input->post('phone'),
         );
       $this->db->where('configuration_id','1');
       $this->db->update('configuration',$data);
       return "<p class='alert alert-success'>Configuration Updated.</p>";
    }

    public function updatesmtp(){
       $data = array(
        'smtphost' => $this->input->post('smtphost'),
        'smtpport' => $this->input->post('smtpport'),
        'smtpuser' => $this->input->post('smtpuser'),
        'smtppass' => $this->input->post('smtppass'),
         );
       $this->db->where('configuration_id','1');
       $this->db->update('configuration',$data);
       return "<p class='alert alert-success'>Smtp settings Updated.</p>";
    }

    

    public function logoimage($filename){
        $query=$this->db->query("update configuration set logo='$filename' where configuration_id='1'");
        //echo $otp;
       
            return 1;
    }

    public function profileimage($filename,$user_id){
        $query=$this->db->query("update user set image='$filename' where user_id='$user_id'");
        //echo $otp;
       
            return 1;
    }

     public function profileupdate($user_id){
        $name=$this->input->post("name");
        $lname=$this->input->post("lname");
        $phone=$this->input->post("phone");
        $query=$this->db->query("update user set name='$name',lname='$lname',phone='$phone' where user_id='$user_id' ");
       
            return "Updated successfully";
    }

    public function completeupdate($user_id){
        $name=$this->input->post("name");
        $lname=$this->input->post("lname");
        $phone=$this->input->post("phone");
        $password=md5($this->input->post("pass"));
        $query=$this->db->query("update user set name='$name',lname='$lname',phone='$phone',password='$password',status='1' where user_id='$user_id'");
       
            return "Updated successfully";
    }
    

    public function changepass($user_id){
        $oldpass=md5($this->input->post('oldpass'));
        $repeatpassword=md5($this->input->post('repeatpassword'));
        $newpassword=md5($this->input->post('newpassword'));
        $query = $this->db->query("select user_id from user where user_id='$user_id' and password='$oldpass'");            
        if($query->num_rows()>0)
        {
            $query = $this->db->query("update user set password='$newpassword' where user_id='$user_id'");            
            return "<p class='alert alert-success'> Password changed .</p>";
        }
        else
        {
            return "<p class='alert alert-danger'> Old password don't match.</p>";
        }
    }

     public function activity($user_id){        
        $query=$this->db->query("select * from files where user_id='$user_id' order by timestamp desc limit 10");
        
        if($query->num_rows()>0)
        {
            foreach ($query->result() as $key => $value) {
                $data[]=$value;
                $query2=$this->db->query("select * from user where user_id='$value->user_id'");
                $query2=$query2->row();
                $data[$key]->email=$query2->email;

            }
        }
        else
        {
            $data=NULL;
        }
       
            return $data;
    }

    public function summaryupload($user_id){
            
        $query=$this->db->query("select * from files where user_id='$user_id'");
        $size="0";
        foreach ($query->result() as $key => $value) {
            $data[]=$value;
            $query2=$this->db->query("select * from user where user_id='$value->user_id'");
            $query2=$query2->row();
            $data[$key]->email=$query2->email;
            $files=explode(',', $value->filename);
            foreach ($files as $key => $value) {
                # code...
               $file_url = "./server/php/files/".trim($value);
               $size=$size+filesize($file_url);
            }

        }
            $data2['size']=$size;
       
            return $data2;
    }

     public function summarydownload($user_id){
            
        $query=$this->db->query("select sum(filesize) as totalsize from download where user_id='$user_id'");
        $query=$query->row();

        return $query->totalsize;

    }

     public function forgotpass($email){
            
        $query=$this->db->query("select * from user where email='$email'");
        if($query->num_rows()>0)
        {
            $query=$query->row();
            $data = array('temppass' => md5($email));
            $this->db->where('user_id', $query->user_id);
            $this->db->update('user', $data); 
            $this->ouremail->sendemail("Reset Password","forgotpass",$data,$query->email);
            return "<p class='alert alert-success'>Please check your email for reseting the password.</p>";
        }
        else{
            return "<p class='alert alert-danger'> No user with this email exisits found.</p>";
            
        }

    }

    public function newpasscheck($key){
            
        $query=$this->db->query("select * from user where temppass='$key'");
        if($query->num_rows()>0)
        {
            $query=$query->row();
            return true;
        }
        else{
            return false;
            
        }

    }

    public function setnewpass($key){
            
        $query=$this->db->query("select * from user where temppass='$key'");
        if($query->num_rows()>0)
        {
            $query=$query->row();
            $data = array('temppass' => "",'password'=>md5($this->input->post('newpass')));
            $this->db->where('user_id', $query->user_id);
            $this->db->update('user', $data); 
            return true;
        }
        else{
            return false;
            
        }

    }

    public function getmaildata($mailid){
            
        $query=$this->db->query("select F.*,U.name,U.lname,U.image,U.email from files F join user U where F.files_id='$mailid' and U.user_id=F.staff_id");
        if($query->num_rows()>0)
        {            
            return $query->row();
        }
        else{
            return false;            
        }

    }
    
    public function get_otp_email($user_id,$type,$mailid){
        $query=$this->db->query("select * from session where user_id='$user_id' and status='0' and type='$type'");
        if($query->num_rows()<=0)
        {
            //send and insert otp//
            $data = array(
                'session_key' => md5(rand(1,9999999)), 
                'otp' => rand(1000,9999), 
                'user_id' => $user_id, 
                'status' => '0', 
                'type' => $type, 
                'mailid' => $mailid, 
                );
            //send and insert otp//
            $this->db->insert("session",$data);
            $query = $this->db->query("select * from user where user_id='$user_id'");
            $row=$query->row();
            $datasend['user']=$row;
            $datasend['otp']= $data;
            $this->ouremail->sendemail("Requested OTP","otp",$datasend,$row->email);
            log_message('info', $row->email.' requested for OTP over email','user');
         }
         else{
            $query=$this->db->query("select * from session where user_id='$user_id' and status='0' and type='$type'");
            if($query->num_rows()>0)
            {
                $row=$query->row_array();
                $query2 = $this->db->query("select * from user where user_id='$user_id'");
                $row2=$query2->row();
                $datasend['user']=$row2;
                $datasend['otp']= $row;
                
                $this->ouremail->sendemail("Requested OTP","otp",$datasend,$row2->email);
                log_message('info', $row2->email.' requested for OTP over email','user');
             }
         }

         return "<p class='alert alert-success'>OTP has been sent. Please enter OTP below.</p>";
    }

    public function get_otp_emailapi($user_id,$type,$mailid){
        $query=$this->db->query("select * from session where user_id='$user_id' and status='0' and type='$type'");
        if($query->num_rows()<=0)
        {
            //send and insert otp//
            $data = array(
                'session_key' => md5(rand(1,9999999)), 
                'otp' => rand(1000,9999), 
                'user_id' => $user_id, 
                'status' => '0', 
                'type' => $type, 
                'mailid' => $mailid, 
                );
            //send and insert otp//
            $this->db->insert("session",$data);
            $query = $this->db->query("select * from user where user_id='$user_id'");
            $row=$query->row();
            $datasend['user']=$row;
            $datasend['otp']= $data;
            $this->ouremail->sendemail("Requested OTP","otp",$datasend,$row->email);
            log_message('info', $row->email.' requested for OTP over email','user');
            $otpgen=$data['otp'];
         }
         else{
            $query=$this->db->query("select * from session where user_id='$user_id' and status='0' and type='$type'");
            if($query->num_rows()>0)
            {
                $row=$query->row_array();
                $query2 = $this->db->query("select * from user where user_id='$user_id'");
                $row2=$query2->row();
                $datasend['user']=$row2;
                $datasend['otp']= $row;
                
                $this->ouremail->sendemail("Requested OTP","otp",$datasend,$row2->email);
                log_message('info', $row2->email.' requested for OTP over email','user');
                $otpgen=$row['otp'];

             }
         }

         return $otpgen;
    }

    public function get_otp_mobile($user_id,$type){
        //check for api setup
        return "<p class='alert alert-danger'>SMS API is not setup.</p>";
    }

    public function get_otp_mobileapi($user_id,$type){
        //check for api setup
        return "<p class='alert alert-danger'>SMS API is not setup.</p>";
    }

    

     public function dashboard3($user_id){
        //check for api setup
        $return = array();
        $this->db->select('user_id');
        $return['totalusers']=$this->db->get('user')->num_rows();

        $this->db->select_sum('totalfilesize');
        $return['totalfilesizeupload']=$this->db->get('files')->row()->totalfilesize;

        $this->db->select_sum('filesize');
        $return['totalfiledownload']=$this->db->get('download')->row()->filesize;

        $return['totalfreespace']=disk_free_space("/");
        $return['totaldiskspace']=disk_total_space("/");
        //get 
        $return['groups']=$this->allgroups();
        return $return;
    }

    public function dashboard($user_id){
        //check for api setup
        $return = array();
        $this->db->select('user_id');
        /*$return['totalusers']=$this->db->get('user')->num_rows();*/

        $this->db->select_sum('totalfilesize');
        $return['totalfilesizeupload']=$this->db->where("user_id",$user_id)->get('files')->row()->totalfilesize;

        $this->db->select_sum('filesize');
        $return['totalfiledownload']=$this->db->where("user_id",$user_id)->get('download')->row()->filesize;

        /*$return['totalfreespace']=disk_free_space("/");
        $return['totaldiskspace']=disk_total_space("/");*/
        //get 
        /*$return['groups']=$this->allgroups();*/
        return $return;
    }

    public function genTempsession($user_id,$type,$mailid=""){
        $otp=$this->db->where(array('user_id' => $user_id, 'status'=>0))->get("session");
        if($otp->num_rows()>0)
        {
            return $otp->row()->session_id;
        }
        else{
            $data = array(
                    'session_key' => md5(rand(1,9999999)), 
                    'otp' => rand(1000,9999), 
                    'user_id' => $user_id, 
                    'status' => '0', 
                    'type' => $type,
                    'what' => 'none',
                    'mailid'=>$mailid
                    );
            $this->db->insert("session",$data);
            return $this->db->insert_id();
        }
    }
     public function ldap(){
        $query=$this->db->get('ldap');
        return $query->row();

     }
     function checkconnection($host,$port,$username,$password,$domain)
    {
        $adServer = $host;
        $ldap = ldap_connect($adServer);

        $ldaprdn = 'cn=read-only-admin,dc='.$domain;

        ldap_set_option($ldap, LDAP_OPT_PROTOCOL_VERSION, 3);
        ldap_set_option($ldap, LDAP_OPT_REFERRALS, 0);

        $bind = @ldap_bind($ldap, $username, $password);
        if ($bind) {
          echo "1";   
        } 
        else {
          echo "0";
        }
    }
    function updateldap(){

         $data = array(
            'host' => $this->input->post('ldaphost'),
            'port' => $this->input->post('ldapport'),
            'ldapuser' => $this->input->post('ldapuser'),           
            'ldappass' => $this->input->post('ldappass'),           
            'domain' => $this->input->post('domain'),           
            );
            $this->db->update('ldap', $data);
            redirect('settings/ldap');
            
    }
    function general(){
         $query=$this->db->get('configuration');
        return $query->row();
    }
    function UpdateGeneral(){
        $data = array(
            'no_days' => $this->input->post('days'),
            'domain' => $this->input->post('domain'),
            'file_type' => $this->input->post('filetype'),           
                     
            );
            $this->db->update('configuration', $data);
            $this->session->set_flashdata("generalupdate","<p class='alert alert-success' style='margin-top:-4px;margin-bottom:3px;margin-left: -15px;'>Information Updated.</p>");
            redirect('settings/General');
    }
    function gettype($loginid){
            $query=$this->db->where('user_id',$loginid)->get('user');
            return $query->row();
    }
    function viewupload(){
   $hours = $this->time = date('Y-m-d H:i:s', strtotime('-1 hour', time()));
    $newquery=$this->db->select('u.email as sender,cu.*')->
   join("user u","u.user_id=cu.user_id")->
    where('cu.modified_at >',$hours)->where('cu.status',0)->
    get('current_uploads cu');
    return $newquery->result();
    }
    
}