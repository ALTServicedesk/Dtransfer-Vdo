<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Package_model extends My_Model {


	function __construct()
	{
		parent::__construct();      
        $this->load->model('Ouremail','ouremail');
	}


    public function listall(){
        $this->db->where("status",0);
        $re=$this->db->get("package");
        return $re->result();
    }

    public function listallview(){
        $re=$this->db->get("package");
        return $re->result();
    }

    public function requestall($type){
        $this->db->where("status",$type);
        $re=$this->db->get("package_request");
        if($re->num_rows()>0){
            foreach ($re->result() as $key => $value) {
                $return[]=$value;
                $q=$this->db->query("select * from user where user_id='$value->user_id'");
                $q=$q->row();
                $return[$key]->email=$q->email;
                $return[$key]->name=$q->name;
                $q2=$this->db->query("select * from package where package_id='$value->package_id'");
                $q2=$q2->row();
                $return[$key]->packagename=$q2->name;
            }
        }
        else{
            $return=NULL;
        }
        return $return;
    }

    public function get_details($id){
        $this->db->where("package_id",$id);
        $re=$this->db->get("package");
        return $re->row();
    }
	

    public function package_add()
    {
        $data = array(
            'name' => $this->input->post('name'), 
            'price' => $this->input->post('price'), 
            'size' => $this->input->post('size'), 
            'packageorder' => $this->input->post('packageorder'), 
            'bandwidth' => $this->input->post('bandwidth'), 
            'validity' => $this->input->post('validity'), 
            );
        $this->db->insert("package",$data);
         return "<p class='alert alert-success'>Package Added.</p>";
    }

    public function package_update()
    {
        $data = array(
            'name' => $this->input->post('name'), 
            'price' => $this->input->post('price'), 
            'size' => $this->input->post('size'), 
            'packageorder' => $this->input->post('packageorder'), 
            'bandwidth' => $this->input->post('bandwidth'), 
            'validity' => $this->input->post('validity'), 
            'status' => $this->input->post('status'), 
            );
        $this->db->where("package_id", $this->input->post('package_id'));
        $this->db->update("package",$data);
        return 1;
    }
}