<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Reports_model extends My_Model {


	function __construct()
	{
		parent::__construct();      
        $this->load->model('Ouremail','ouremail');
	}

    public function generateuploads($data){
    	//echo'<pre>';print_r($data);die;
    	$this->db->select("f.*,us.name as recivername,us.email reciveremail,u.name as username,u.email as useremail,s.*");
		$this->db->join("user u","f.user_id=u.user_id");
		$this->db->join("user us","f.staff_id=us.user_id");
		$this->db->join("session s","s.session_id=f.session_id");
		$this->db->where('f.timestamp >=', $data['startdate']);
     	$this->db->where('f.timestamp <=', $data['enddate']);
     	if($data['user'] != 'All'){
		$this->db->where('u.user_id', $data['user']);
     	
    	}
		return $data = $this->db->get("files f")->result();
    	
    	
		/*echo'<pre>';print_r($data);
		die;*/
		        
    }

    public function generatedownloads($data){
    	//echo'<pre>';print_r($data);die;
    	$this->db->select("d.*,u.name as username,u.email as useremail");
		$this->db->join("user u","d.user_id = u.user_id");
		$this->db->where('d.timestamp >=', $data['startdate']);
     	$this->db->where('d.timestamp <=', $data['enddate']);
     	if($data['user'] != 'All'){
		$this->db->where('u.user_id', $data['user']);
     	
    	}
		return $data = $this->db->get("download d")->result();
    	
    	
		/*echo'<pre>';print_r($data);
		die;*/
		        
    }

    public function generatestorage($data){
    	//echo'<pre>';print_r($data);die;
    	$this->db->select("sum(f.totalfilesize) as totalsize ,u.name as username,u.email as useremail");
		$this->db->join("user u","f.user_id = u.user_id");
		$this->db->where('f.timestamp >=', $data['startdate']);
     	$this->db->where('f.timestamp <=', $data['enddate']);
     	if($data['user'] != 'All'){
		$this->db->where('u.user_id', $data['user']);
     	
    	}
		return $data = $this->db->get("files f")->result();
    	
    	
		/*echo'<pre>';print_r($data);
		die;*/
		        
    }
}