<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Help_model extends My_Model {


	function __construct()
	{
		parent::__construct();      
        $this->load->model('Ouremail','ouremail');
	}

    public function insertTickets($data){
        return $this->db->insert('help_ticket', $data);
    }
   
    public function alltickets(){
       // $return = array();
        $this->db->select('*');
        $this->db->from('help_ticket');
        $this->db->join('user', 'user.user_id = help_ticket.help_userid');
        //  $this->db->where('Teacher_id', $keyid);
        $query = $this->db->get();
         return $query ;
        
    }



    public function getsingleticket($hid){
      $row = $this->db->where(' help_id',$hid)->limit(1)->get('help_ticket')->row();
      return $row;

    }


    public function getreplies($hid){
      $this->db->select('*');
      $this->db->from('help_replies');
      $this->db->where('help_replies.help_id', $hid);
      $this->db->join('user', 'user.user_id = help_replies.user_id');
      $row = $this->db->get()->result();

      return $row;

    }

    public function addreply($data){

         return $this->db->insert('help_replies', $data);
    }

    public function changeStatus($data,$TK_id){
      try{
          //echo $id;die;
           $this->db->where('help_id',$TK_id)->limit(1)->update('help_ticket', $data);
           return true;
        }catch(Exception $e){
           echo $e->getMessage();
        }


    }

}
