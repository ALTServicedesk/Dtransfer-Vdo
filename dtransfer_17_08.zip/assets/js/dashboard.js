                    var jsonData = [
                      {"name":"daman","upload":"100"}
                  ];

                  var data = {};
                  var sites = [];
                  jsonData.forEach(function(e) {
                      sites.push(e.name);
                      data[e.name] = e.upload;
                  }) 

                      var donutChart = c3.generate({
                      bindto: '#donut-diskspace',
                      data: {
                          columns: [
                              ['Used', dashboard_spaceper],
                              ['Free', 100-dashboard_spaceper]
                          ],
                          type : 'donut',
                          colors: {
                              Used: '#3B5998',
                              Free: '#16B4FC',
                          }
                      },
                      donut: {
                          title: "Disk Space"
                      },
                      size: {
                        height: 240,
                        width: 480
                    },
                  });

                      var donutChart = c3.generate({
                      bindto: '#donut-downloadupload',
                      data: {
                          columns: [
                              ['Upload', dashboard_upload],
                              ['Download', dashboard_download]
                          ],
                          type : 'donut',                          
                          colors: {
                              Upload: '#16B4FC',
                              Download: '#3B5998',
                          }
                      },
                      donut: {
                          title: "Bandwidth"
                      },
                      size: {
                        height: 240,
                        width: 480
                    },
                  });
                      

                    