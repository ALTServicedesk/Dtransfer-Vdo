
	   

	function updateTime() {
        var now = moment().format("dddd, Do MMMM YYYY, hh:mm:ss");
        $('#datetime').html(now);
        }
	setInterval(updateTime, 1000); 
	 


	function readURL(input) {
		  if (input.files && input.files[0]) {
		    var reader = new FileReader();
		    reader.onload = function(e) {
		      $('#previewHolder').attr('src', e.target.result);
		    }
		    reader.readAsDataURL(input.files[0]);
		  }
		}

		function isValidEmailAddress(emailAddress) {
		    var pattern = /^([a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+(\.[a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+)*|"((([ \t]*\r\n)?[ \t]+)?([\x01-\x08\x0b\x0c\x0e-\x1f\x7f\x21\x23-\x5b\x5d-\x7e\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|\\[\x01-\x09\x0b\x0c\x0d-\x7f\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))*(([ \t]*\r\n)?[ \t]+)?")@(([a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.)+([a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.?$/i;
		    return pattern.test(emailAddress);
		};

		function target_popup(form) {
		    window.open('', 'formpopup', 'width=600,height=500,resizeable,scrollbars');
		    form.target = 'formpopup';
		}

		function functionsinit () {
    		//custom initaliszation
		 	$(".myradioswitch").bootstrapSwitch();
		 	$('.summernote').summernote();
		 	$('.scroll-pane').jScrollPane();
		 	$('.selectsearch').select2();
		 	/*$('.email-tag-editor').tagEditor(
		 		{
		 			placeholder:'Email goes here...',
		 			onChange: function(field, editor, tags) {
		 				console.log(editor);
				        var emailtest=tags[tags.length-1];
				        var remove=0;
				        if(!isValidEmailAddress(emailtest))
				        {
				        	alert("Please enter valid emails.");
				        	remove=1;
				        	//$('.email-tag-editor').tagEditor('removeTag', emailtest);
				        	//$(this).editor.removeTag(emailtest,true);
				        	$('.tag-editor li:last-child').remove();
				        }
				        
				    },
		 		});
*/
		 	tinyMCE.init({
				        mode : "textareas",
				        menubar:false,
				        editor_selector : "myeditor",
				        theme: 'modern',
						  plugins: [
						    'advlist autolink lists link image charmap print preview hr anchor pagebreak',
						    'searchreplace wordcount visualblocks visualchars code fullscreen',
						    'insertdatetime media nonbreaking save table contextmenu directionality',
						    'emoticons template paste textcolor colorpicker textpattern imagetools','code'
						  ],
						  toolbar1: 'insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image | code',
						  toolbar2: 'print preview media | forecolor backcolor emoticons',
						  image_advtab: true,
						  templates: [
						    { title: 'Test template 1', content: 'Test 1' },
						    { title: 'Test template 2', content: 'Test 2' }
						  ],
						  content_css: [
						    '//fonts.googleapis.com/css?family=Lato:300,300i,400,400i',
						    '//www.tinymce.com/css/codepen.min.css'
						  ]
			});
			
			$("#uploadform").validate();
			$(".validatetrue").validate();
			$('.dropdown-toggle').dropdown();
			$('.scroll-pane').jScrollPane();
			//$('.datatable').DataTable();
			 var table = $('.datatable').DataTable( {
		        lengthChange: false,
		        responsive: true,
		        buttons: [ 'copy', 'pdf', 'colvis' ]
		    } );
		 
		    table.buttons().container()
		        .appendTo( '.dataTables_wrapper .col-sm-6:eq(0)' );

			var start = moment().subtract(29, 'days');
			    var end = moment();

			    function cb(start, end) {
			        $('.daterange span').html(start.format('D MMMM, YYYY') + ' - ' + end.format('D MMMM, YYYY'));
			    }

			    $('.daterange').daterangepicker({
			        startDate: start,
			        endDate: end,
			        locale: {
            			format: 'DD/MM/YYYY'
        			},
			        ranges: {
			           'Today': [moment(), moment()],
			           'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
			           'Last 7 Days': [moment().subtract(6, 'days'), moment()],
			           'Last 30 Days': [moment().subtract(29, 'days'), moment()],
			           'This Month': [moment().startOf('month'), moment().endOf('month')],
			           'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
			        },
					"showWeekNumbers": true,
					"showDropdowns": true,
				    }, cb);

			cb(start, end);
			$('.cc').tagsinput({
			  confirmKeys: [13, 44, 32],
			  trimValue: true

			 });

			 $('.cc').on('itemAdded', function(event) {
			 	
			  // event.item: contains the item
			  var curemail = event.item;
			  if (!checkEmail(curemail)) {
			   $('.cc').tagsinput('remove', curemail, {
			    preventPost: true
			   });
			   swal("Email Not Valid!");
			  }
			 });
			 
			 $('.tags_1').tagsinput({
			  confirmKeys: [13, 44, 32],
			  trimValue: true

			 });

			 $('.tags_1').on('itemAdded', function(event) {
			 	
			  // event.item: contains the item
			  var curemail = event.item;
			  if (!checkEmail(curemail)) {
			   $('.tags_1').tagsinput('remove', curemail, {
			    preventPost: true
			   });
			   swal("Email Not Valid!");
			  }
			 });
			$('.tags_2').tagsinput({
			  confirmKeys: [13, 44, 32],
			  trimValue: true

			 });

			 $('.tags_2').on('itemAdded', function(event) {
			 	
			  // event.item: contains the item
			  var curemail = event.item;
			  if (!checkEmail(curemail)) {
			   $('.tags_2').tagsinput('remove', curemail, {
			    preventPost: true
			   });
			   swal("Email Not Valid!");
			  }
			 });
			 $('.tags_4').tagsinput({
			  confirmKeys: [13, 44, 32],
			  trimValue: true

			 });

			 $('.tags_4').on('itemAdded', function(event) {
			 	
			  // event.item: contains the item
			  var curemail = event.item;
			  if (!checkEmail(curemail)) {
			   $('.tags_4').tagsinput('remove', curemail, {
			    preventPost: true
			   });
			   swal("Email Not Valid!");
			  }
			 });
			 function checkEmail(email) {
  var pattern = /^([a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+(\.[a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+)*|"((([ \t]*\r\n)?[ \t]+)?([\x01-\x08\x0b\x0c\x0e-\x1f\x7f\x21\x23-\x5b\x5d-\x7e\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|\\[\x01-\x09\x0b\x0c\x0d-\x7f\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))*(([ \t]*\r\n)?[ \t]+)?")@(([a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.)+([a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.?$/i;
  return pattern.test(email);
}
$('.check1').on('click', function(event) {
	 var email= $(".tags_2").val();
	 if (email=="") {
	 	swal("Recipient is empty!");
	 	return false;
	 }
	 });
$('.check').on('click', function(event) {
	 var email= $(".tags_1").val();
	 if (email=="") {
	 	swal("Email is empty!");
	 	return false;
	 }
	 });
$('.check').on('click', function(event) {
	 var email= $(".tags_3").val();
	 if (email=="") {
	 	swal("CC is mandatory!");
	 	return false;
	 }
	 });
/*$('.check').on('click', function(event) {
	 var email= $(".tags_4").val();
	 if (email=="") {
	 	swal("CC is empty!");
	 	return false;
	 }
	 });*/

var getemail=0;
$('.tags_2').on('itemAdded', function(event) {
       var icount=0;
	   getemail=0;
       var curemail = event.item;
       var email= $(".tags_2").val();
       var arr=email.split(',');//split email
       var str=$(".domain").val();
       var domsplt=str.split(',');//split domain
        while (icount < arr.length) {
          var emailnew=arr[icount].split('@');
          var checkemail="@"+emailnew[1];
            if(domsplt.indexOf(checkemail)!="-1"){ 
            	getemail=getemail+1;
            	
            }
            else{
                if(getemail==0 && icount!=0 ){
                $('.tags_2').tagsinput('remove', curemail, {
                  preventPost: true
                 });
                swal("Email is restricted.");
              	}
          	}
           icount++;
        }  
  });


$('.tags_2').on('itemRemoved', function(event) {
	var email = $(".tags_2").val();
       var arr = email.split(',');
       var str=$(".domain").val();
       var domsplt=str.split(',');
	   var icount111=0;
	   var curemail=event.item;
	   /*alert(curemail);*/
	    var emailnew=curemail.split('@');
	    var checkemail="@"+emailnew[1];
        if(domsplt.indexOf(checkemail)!="-1"){ 
        	getemail=getemail-1;
        	
        }
});
$('body').on('click', '.check1',function(event) {
	
       var email = $(".tags_2").val();
       var arr = email.split(',');
       var str=$(".domain").val();
       var domsplt=str.split(',');
	   var icount111=0;
	   var invalcount=0;
	  /*alert(foundemail,'check');*/
		if(getemail<=0){
		while (icount111 < arr.length) {
	    var emailnew=arr[icount111].split('@');
	    var checkemail="@"+emailnew[1];
	    
        if(domsplt.indexOf(checkemail)!="-1"){ 
        
        }
        else{
        	
             invalcount=invalcount+1;
	      }     
	       icount111=icount111+1;	   
		}

		if(invalcount>0){
			swal("You must have atleast one recipient form authorised domain ");
			return false;
		}
	}
});
$('.check').on('click', function(event) {
	 var email= $(".tags_3").val();
	 var email1= $(".tags_1").val();
	 if (email1=="") {
	 	swal(" Email is empty!");
	 	return false;
	 }
	 if (email=="") {
	 	/*swal("CC Email is empty!");*/
	 	/*return false;*/
	 }
	  
	 });

		 	//custom initaliszation
		}
 
 //for cc input
var foundemail=0;
$('.tags_3').on('itemAdded', function(event) {
	   var icount=0;
	   foundemail=0;
       var curemail = event.item;
       var email= $(".tags_3").val();
       var arr=email.split(',');//split email
       var str=$(".domain").val();
       var domsplt=str.split(',');//split domain
        while (icount < arr.length) {
          var emailnew=arr[icount].split('@');
          var checkemail="@"+emailnew[1];
          
            	/*alert(foundemail);*/
            if(domsplt.indexOf(checkemail)!="-1"){ 
            	foundemail=foundemail+1;
            }
            else{
            	/*alert(foundemail);*/
                if(foundemail==0 && icount!=0){
                $('.tags_3').tagsinput('remove', curemail, {
                  preventPost: true
                 });
                swal("Reciever's cc email is restricted.");
              	}
          	}
           icount++;
        }
  });


$('.tags_3').on('itemRemoved', function(event) {
	var email = $(".tags_3").val();
       var arr = email.split(',');
       var str=$(".domain").val();
       var domsplt=str.split(',');
	   var icount111=0;
	   var curemail=event.item;
	   /*alert(curemail);*/
	    var emailnew=curemail.split('@');
	    var checkemail="@"+emailnew[1];
        if(domsplt.indexOf(checkemail)!="-1"){ 
        	foundemail=foundemail-1;
        }
});

$('body').on('click', '.check',function(event) {
       var email = $(".tags_3").val();
       var arr = email.split(',');
       var str=$(".domain").val();
       var domsplt=str.split(',');
	   var icount111=0;
	   var invalcount=0;
	  /*alert(foundemail,'check');*/
		if(foundemail<=0){
		while (icount111 < arr.length) {
	    var emailnew=arr[icount111].split('@');
	    var checkemail="@"+emailnew[1];
	    
        if(domsplt.indexOf(checkemail)!="-1"){ 
        
        }
        else{
        	
             invalcount=invalcount+1;
	      }     
	       icount111=icount111+1;	   
		}

		if(invalcount>0){
			swal("You must have atleast one email form authorised domain in CC");
			return false;
		}
	}
});

//document ready start //

	 $(document).ready(function(){
	 		//custom initaliszation
	 		functionsinit();
			//custom initaliszation	 

	


		//prevent submit from enter on compose start	
		if($("#composestart").length != 0) {
			$(window).keydown(function(event){
		    if(event.keyCode == 13) {
		      event.preventDefault();
		      return false;
		    }
		  });	
		}
		//prevent submit from enter on compose start

	 	// Change Messages From Settings 
	 	$('body').on('click','.save_messages',function (e){
	 			e.preventDefault();
				var data=$("#messages_form").serialize();
	 			$(".transparacy").css({'display': 'block'});
                $(".loader").css({'display': 'block'});
	 			$.ajax({
                        url:""+base_url+'settings/savemessages',
                        type:'post',
                        data:data,
                        success:function(res){
                            $(".transparacy").css({'display': 'none'});
                			$(".loader").css({'display': 'none'});
	 						notie.alert(1, 'Saved!');
                        }

                    });
	 	});
	 	// Change Messages From Settings 

	 	// Change Site configuration From Settings 
	 	$('body').on('click','.save_config',function (e){
	 			e.preventDefault();
				var data=$("#config_form").serialize();
	 			$(".transparacy").css({'display': 'block'});
                $(".loader").css({'display': 'block'});
                $.ajax({
                        url:""+base_url+'settings/saveconfig',
                        type:'post',
                        data:data,
                        success:function(res){
                            $(".transparacy").css({'display': 'none'});
                			$(".loader").css({'display': 'none'});
	 						notie.alert(1, 'Saved!');
                        }

                    });
	 	});
	 	// Change Site configuration From Settings 

	 	//change upload preview
	 	$("#imageuploadpreview").change(function() {
		  readURL(this);
		});
	 	//change upload preview

	 	// Mail Page//
	 		//Load first Mail Data
	 		if($("#mailpage").length != 0) {
 				var mailid=$(".mail-item-link:first").data("mailid");
 				console.log(mailid);
 				if(mailid!=null)
 				{
	 				var type=$("#type").val();
	 				$(".transparacy").css({'display': 'block'});
	                $(".loader").css({'display': 'block'});
	 				$.ajax({
	                        url:""+base_url+'user/getmaildata',
	                        type:'post',
	                        data:{mailid:mailid,type:type},
	                        success:function(res){
	                            $(".transparacy").css({'display': 'none'});
	                			$(".loader").css({'display': 'none'});
		 						$("#viewmail").html(res); 
		 						functionsinit();                    
	                    	}
	                    });
 				}
	 		}
	 		//Load first Mail Data

	 		//load Mail clicked
	 		$('body').on('click','.mail-item-link',function (e){
	 			var mailid=$(this).data('mailid');
 				var type=$("#type").val();	 			
	 			$(".transparacy").css({'display': 'block'});
                $(".loader").css({'display': 'block'});
	 			$.ajax({
                        url:""+base_url+'user/getmaildata',
                        type:'post',
                        data:{mailid:mailid,type:type},
                        success:function(res){
                            $(".transparacy").css({'display': 'none'});
                			$(".loader").css({'display': 'none'});
	 						$("#viewmail").html(res); 
	 						functionsinit();                    
                    	}
                    });
	 		});
	 		//load Mail clicked

	 		//inbox item OTP
	 		$('body').on('click','.mail-item-link-otp',function (e){
	 			var mailid=$(this).data('mailid');
 				var type=$("#type").val();	 			
	 			$(".transparacy").css({'display': 'block'});
                $(".loader").css({'display': 'block'});
	 			$.ajax({
                        url:""+base_url+'user/getajaxotpform',
                        type:'post',
                        data:{mailid:mailid,type:type},
                        success:function(res){
                            $("#ajaxModal").modal('show');
	 						$("#ajaxModalLabel").html("OTP");
	 						$("#ajaxModalbody").html(res);
	 						$("#ajaxModal").modal('show');
                            $(".transparacy").css({'display': 'none'});
                			$(".loader").css({'display': 'none'});                 
                    	}
                    });
	 		});
	 		//inbox item OTP

	 		//send otp inbox item OTP
	 		$('body').on('click','#otp-sentitem',function (e){
	 			e.preventDefault();
	 			var mailid=$(this).data('mailid');
	 			var sentto=$(this).data('sentto');
 				var type=$("#type").val();	 			
	 			$(".transparacy").css({'display': 'block'});
                $(".loader").css({'display': 'block'});
	 			$.ajax({
                        url:""+base_url+'user/getajaxotpformsubmit',
                        type:'post',
                        data:{sentto,mailid},
                        success:function(res){
                            $("#ajaxModal").modal('show');
	 						$("#ajaxModalLabel").html("OTP");
	 						$("#ajaxModalbody").html(res);
	 						$("#ajaxModal").modal('show');
                            $(".transparacy").css({'display': 'none'});
                			$(".loader").css({'display': 'none'});                 
                    	}
                    });
	 		});
	 		//send otp inbox OTP

	 		//send otp inbox item OTP
	 		$('body').on('click','#checkotpformailview',function (e){
	 			e.preventDefault();
	 			var mailid=$(this).data('mailid');			
	 			var otp=$("#otp").val();			
	 			$(".transparacy").css({'display': 'block'});
                $(".loader").css({'display': 'block'});
	 			$.ajax({
                        url:""+base_url+'user/checkotpformailview',
                        type:'post',
                        data:{mailid,otp},
                        context:this,
                        success:function(res){
                            $("#ajaxModal").modal('show');
	 						$("#ajaxModalLabel").html("OTP");
	 						if(res=="true"){	 							
	 							$(".transparacy").css({'display': 'block'});
                				$(".loader").css({'display': 'block'});
	 							$("#ajaxModalbody").html("");
	 							$("#ajaxModal").modal('hide');
	 							$('[data-mailid="'+mailid+'"]').attr("class","mail-item-link");
	 							$('[data-mailid="'+mailid+'"]').click();
	 						}
	 						else{
	 							$("#ajaxModalbody").html("<p class='alert alert-danger'>Wrong OTP entered.</p>");
	 							                           
	 						}
	 						$(".transparacy").css({'display': 'none'});
                			$(".loader").css({'display': 'none'}); 
	 						                
                    	}
                    });
	 		});
	 		//send otp inbox OTP

	 		//send otp for download item OTP
	 		$('body').on('click','#otp-requestdownload',function (e){
	 			e.preventDefault();
	 			var mailid=$(this).data('mailid');
	 			var sentto=$(this).data('sentto'); 			
	 			var userid=$(this).data('userid'); 			
	 			$(".transparacy").css({'display': 'block'});
                $(".loader").css({'display': 'block'});
	 			$.ajax({
                        url:""+base_url+'user/requestdownloadotp',
                        type:'post',
                        data:{sentto,mailid,userid},
                        success:function(res){
	 						$("#msg").html("<p class='alert alert-success'>OTP has been sent. Please enter OTP below.</p>");
                            $(".transparacy").css({'display': 'none'});
                			$(".loader").css({'display': 'none'});            
                    	}
                    });
	 		});
	 		//send otp for download item OTP

	 		//check otp for download
	 		$('body').on('click','#checkotpfordownload',function (e){
	 			e.preventDefault();
	 			var mailid=$(this).data('mailid');			
	 			var userid=$(this).data('userid');			
	 			var otp=$("#otp").val();			
	 			$(".transparacy").css({'display': 'block'});
                $(".loader").css({'display': 'block'});
	 			$.ajax({
                        url:""+base_url+'user/checkotpfordownload',
                        type:'post',
                        data:{mailid,otp,userid},
                        context:this,
                        success:function(res){
	 						if(res=="true"){	 		
	 							window.location=base_url+'files/viewallfiles/'+btoa(userid)+'/'+btoa(mailid)+'/'+btoa(otp);
	 						}
	 						else{
	 							$("#msg").html("<p class='alert alert-danger'>Wrong OTP entered.</p>");
	 						}
	 						$(".transparacy").css({'display': 'none'});
                			$(".loader").css({'display': 'none'}); 
	 						                
                    	}
                    });
	 		});

	 		//check otp for download
	 		$('body').on('click','#checkotpfordownloadsingle',function (e){
	 			e.preventDefault();
	 			var mailid=$(this).data('mailid');			
	 			var userid=$(this).data('userid');			
	 			var filename=$(this).data('filename');			
	 			var otp=$("#otp").val();			
	 			$(".transparacy").css({'display': 'block'});
                $(".loader").css({'display': 'block'});
	 			$.ajax({
                        url:""+base_url+'user/checkotpfordownloadsingle',
                        type:'post',
                        data:{mailid,otp,userid,filename},
                        context:this,
                        success:function(res){
	 						if(res=="true"){	 		
	 							window.location=base_url+'files/viewfile/'+btoa(userid)+'/'+btoa(mailid)+'/'+btoa(otp)+'/'+btoa(filename);
	 						}
	 						else{
	 							$("#msg").html("<p class='alert alert-danger'>Wrong OTP entered.</p>");
	 						}
	 						$(".transparacy").css({'display': 'none'});
                			$(".loader").css({'display': 'none'}); 
	 						                
                    	}
                    });
	 		});
	 		//check otp for download
	 	// Mail Page//


	 	//load log file
	 	$('body').on('click','.loadlogfile',function (e){
	 			var logfilename=$(this).data('logfilename');
	 			$(".transparacy").css({'display': 'block'});
                $(".loader").css({'display': 'block'});
	 			$.ajax({
                        url:""+base_url+'logs/getlogfile',
                        type:'post',
                        data:{logfilename:logfilename},
                        success:function(res){
	 						$("#ajaxModal").modal('show');
	 						$("#ajaxModalLabel").html("Log Details of : "+logfilename);
	 						$("#ajaxModalbody").html(res);
	 						$("#ajaxModal").modal('show');
                            $(".transparacy").css({'display': 'none'});
                			$(".loader").css({'display': 'none'});
                    	}
                    });
	 		});
	 	//load log file

 
		$('.scroll-pane').jScrollPane();

		$('#newpass').keyup(function(e){
			if($("#newpass").val()!=""){
			$("#confpass").attr("required","required");	
			}
			else{
				$("#confpass").removeAttr("required");	
			}
		});

		//load single file details
	 	$('body').on('click','#downloadfile',function (e){
	 			var filename=$.trim($(this).data('filename'));
	 			$(".transparacy").css({'display': 'block'});
                $(".loader").css({'display': 'block'});
	 			$.ajax({
                        url:""+base_url+'files/getFile/'+filename,
                        type:'post',
                        data:{filename},
                        success:function(res){
	 						$("#ajaxModal").modal('show');
	 						$("#ajaxModalLabel").html("Download : "+filename);
	 						$("#ajaxModalbody").html(res);
	 						$("#ajaxModal").modal('show');
                            $(".transparacy").css({'display': 'none'});
                			$(".loader").css({'display': 'none'});
                    	}
                    });
	 		});
	 	//load log file

	 	$("#downloadselected").click(function(){
	 		/*$( "a" ).each(function (el) {
			   var link = $(this).attr('href');
			   window.open=link;
			});*/


			 var urls = [];

			    $('a').each(function() {
			        urls.push(this.href); // Store the URLs from the links...
			    });

			    var multilink = $('<a href="#">Click here</a>'); // Create a new link...
			    multilink.click(function() {
			        for (var i in urls) {
			            window.open(urls[i]); // ...that opens each stored link in its own window when clicked...
			        }
			    });

			    $('.yourlinks').replaceWith(multilink);
	 	});


	 	//viewpage
	 	$('body').on('click','#pageview',function (e){
	 		e.preventDefault();
	 		var slug=$(this).data("slug");
	 		var title=$(this).data("title");
	 		$(".transparacy").css({'display': 'block'});
                $(".loader").css({'display': 'block'});
	 			$.ajax({
                        url:""+base_url+'page/getpage',
                        type:'post',
                        data:{slug},
                        success:function(res){
	 						$("#ajaxModal").modal('show');
	 						$("#ajaxModalLabel").html(title);
	 						$("#ajaxModalbody").html(res);
	 						$("#ajaxModal").modal('show');
                            $(".transparacy").css({'display': 'none'});
                			$(".loader").css({'display': 'none'});
                    	}
                    });
	 	});

	 	//viewpage

	 	if( $('#composestartfinal').length ){ 
		 	
		 	window.onbeforeunload = function(){
			  return 'Are you sure you want to leave?';
			};
	 	}

	 	$('body').on('click','#uploadman',function (e){

	 	if($('input[name="filename[]"]').length){
	 		$(".transparacy").css({'display': 'block'});
	        $(".loader").css({'display': 'block'});
		 	var sentdata=$('#fileupload').serialize();
	             $.ajax({
	                    url:base_url+'user/uploadfile',
	                    type:'POST',
	                    data:sentdata,
	                    success:function(result){
	                        $("#fileupload").html(result).show(1000);
	                        $("#messagewarning").hide();
	                        $(".transparacy").css({'display': 'none'});
	                        $(".loader").css({'display': 'none'});
	                    }

	            });
	 		}
	 		else{
	 			alert("No files uploaded yet. Please upload atleast one file first.");
	 		}
	    });
	 	
	 	$("body").on('click','#change_password',function(e){
        e.preventDefault();
       $(".transparacy").css({'display': 'block'});
	    $(".loader").css({'display': 'block'});
        var oldpass=$("#oldpass").val();
        var newpassword=$("#newpassword").val();
        var repeatpassword=$("#repeatpassword").val();
        var user_id=$("#user_id").val();
        if(oldpass==""){ 
            $("#password_result").html("<p class='alert alert-danger'> Old Password is required</p>"); 
            $(".transparacy").css({'display': 'none'});
	                        $(".loader").css({'display': 'none'});
        }
        else{
            if(newpassword==""){ 
                $("#password_result").html("<p class='alert alert-danger'> Password is required</p>"); 
                $(".transparacy").css({'display': 'none'});
	            $(".loader").css({'display': 'none'});
            }
            else if(repeatpassword==""){ 
                $("#password_result").html("<p class='alert alert-danger'> Confirm Password is required</p>"); 
            	$(".transparacy").css({'display': 'none'});
	            $(".loader").css({'display': 'none'});
            }
            else{

                    if(newpassword!=repeatpassword)
                    {
                        $("#password_result").html("<p class='alert alert-danger'> New paswords not matached.</p>");
                    	$(".transparacy").css({'display': 'none'});
	                    $(".loader").css({'display': 'none'});
                    }
                    else
                    {
                        $.ajax({
                            url: base_url+"user/changepass",
                            method: "post",
                            data: {oldpass:oldpass,newpassword:newpassword,repeatpassword:repeatpassword} ,
                            success: function(result){
                                $("#password_result").html(result);
                                $(".transparacy").css({'display': 'none'});
	                    		$(".loader").css({'display': 'none'});
                            }
                        });
                    }

            }
            
        }

    });
	 	
$("body").on("click", "#checkconnection", function(e) {
        e.preventDefault();
      
        var host= $("#host").val();
        var port= $("#port").val();
        var username= $("#ldapuser").val();
        var password= $("#ldappass").val();
        var domains= $("#domain").val();
         //alert(domains);
        $('#check1').html("<i class='fa fa-spinner fa-spin' style='font-size:24px; margin-top:8px;'></i>");
        $.ajax({
            url:""+base_url+'settings/CheckConnection/',
            type: 'POST',
            data: {host:host,port:port,username:username,password:password,domains:domains}, 
            success: function(res){
                 //$('#result').html(res);
                 if(res==1){
                  $("#update").prop("disabled", false );
                  $('#check1').html("<p class='alert alert-success' style='font-size:15px;height:34px;padding:5px;width:100%;    margin-top: 6px;'>Successfully Connected.</p>");
                  //$("#check1").css("color", " #008000"); 
                }else{
                  $("#update").prop("disabled", true );
                  $('#check1').html("<p class='alert alert-danger' style='font-size:15px;height:34px;padding:5px;width:100%;margin-top: 6px;'>Connection Failed.</p>");
                  //$("#check1").css("color", "#008000");
                }
            }
        });
    });

function insertNew(){
	var email =$('.email').val();
	var cc_email =$('.cc_email').val();
	var subject =$('.subject').val();
	var des =$('.description').val();
	var validity =$('.validity').val();
	var file_data= $('body #get_prog').html();
	var arr = file_data.split('|');
	if(arr.length>0){
		var percentage=arr[2];
		var arr3=arr[3].split('/');
		var current_file_size=arr3[0];
		var total_file_size=arr3[1];
		$.ajax({
	            url:""+base_url+'Upload/current_upload/',
	            type: 'POST',
	            data: {email:email,cc_email:cc_email,subject:subject,des:des,validity:validity,percentage:percentage,current_file_size:current_file_size,total_file_size:total_file_size}, 
	            dataType: 'json',
	            success: function(data){
	            	$('.insert_id').val(data.insert_id);
	            	setInterval( function() { current_upload(); }, 10000 );
	            }
	        });
	}
}

$("body").on("click", ".start", function(e) {
        e.preventDefault();
 setTimeout(function(){ insertNew(); }, 2000);
	});

function current_upload(){
	var insert_id =$('.insert_id').val();
	var file_data= $('body #get_prog').html();
	var arr = file_data.split('|');
	var percentage=arr[2];
	var arr3=arr[3].split('/');
	var current_file_size=arr3[0];
	var total_file_size=arr3[1];
	$.ajax({
            url:""+base_url+'Upload/current_upload_update/',
            type: 'POST',
            data: {insert_id:insert_id,percentage:percentage,current_file_size:current_file_size,total_file_size:total_file_size}, 
            dataType: 'json',
            success: function(data){
            	
            }
        });
};

if($("#currentUpload").length){
setInterval( function() { current_view(); }, 20000 );
    };
function current_view(){
	$.ajax({
            url:""+base_url+'Upload/view_current_update_ajax/',
            type: 'POST',
            data: {}, 
            success: function(data){
            	var kkk = $('body .newtable').html(data);
            	 $( ".refresh" ).trigger( "click" );
            }
        });
};


});//document ready end
$(document).ready(function(){
    // Alloted time in seconds
    var timeVal = 20;
    // Set timer
    $('.timer').html(timeVal);
    // Load timer function
    refreshTimer();
    // Refresh button
    $('.refresh').click(function(){
        // Reset timer
        $('.timer').html( timeVal );
        // Clear interval
        clearInterval( loadTimer );
        // Load interval again
		loadTimer = setInterval( refreshTimer, timerInterval );
        // Set timer
		refreshTimer();
    });
    // Interval
    var timerInterval = 1000;
	var loadTimer = setInterval(refreshTimer, timerInterval);
});
// Refresh Timer
function refreshTimer() {
    // Set counter
    setTimeout(function() {
        // Get timer value and decrement in 1
        var myTime = parseInt( $('.timer').html() ) - 1;
        // If timer has not reached 0
        if( myTime > 0 ) {
            // Set timer
            $('.timer').html(myTime);
        } /*else {
           $( ".refresh" ).trigger( "click" );
        }*/
    }, 1);
}