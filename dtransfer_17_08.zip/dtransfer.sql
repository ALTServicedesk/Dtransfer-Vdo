-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 31, 2017 at 01:36 PM
-- Server version: 5.5.27
-- PHP Version: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `dtransfer`
--

-- --------------------------------------------------------

--
-- Table structure for table `config`
--

CREATE TABLE IF NOT EXISTS `config` (
  `config_id` int(11) NOT NULL AUTO_INCREMENT,
  `category` text NOT NULL,
  `name` varchar(200) NOT NULL,
  `key` text NOT NULL,
  `description` text NOT NULL,
  `lang` text NOT NULL,
  `token` text NOT NULL,
  `type` varchar(100) NOT NULL COMMENT 'type eg, radio,checkbox,select,textarea,text',
  `data` text NOT NULL COMMENT 'should be seprated by comma',
  PRIMARY KEY (`config_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `config`
--

INSERT INTO `config` (`config_id`, `category`, `name`, `key`, `description`, `lang`, `token`, `type`, `data`) VALUES
(1, 'general', 'Site Title', 'sitetitle', 'Site title which will be displayed in title bar of browser', 'english', 'ALT Digital Media Entertainment Limited', '', ''),
(2, 'general', 'Copyright Message', 'copyright', 'Copyright text in the footer.', 'english', '© ALT Digital Media Entertainment Limited', '', ''),
(3, 'user', 'Public signup', 'allow_signup', 'Copyright text in the footer.', 'english', 'yes', 'radiotoggle', 'yes,no'),
(4, 'general', 'Date Format', 'dateformat', 'd=date, i-', 'english', 'd-m-Y', 'text', ''),
(5, 'general', 'Date/Time Format', 'datetimeformat', 'd=date, i-', 'english', 'd-M-Y H:m:s', 'text', ''),
(6, 'user', 'OTP on Phone', 'allow_otp_phone', 'allow otp ', 'english', 'no', 'radiotoggle', 'yes,no'),
(7, 'user', 'OTP on Email', 'allow_otp_email', 'allow otp ', 'english', 'no', 'radiotoggle', 'yes,no'),
(8, 'user', 'Domain Restriction', 'domain_restriction', 'If this is enabled we will verify atleast one email in to,cc,bcc will be from this domain', 'english', 'no', 'radiotoggle', 'yes,no');

-- --------------------------------------------------------

--
-- Table structure for table `configuration`
--

CREATE TABLE IF NOT EXISTS `configuration` (
  `configuration_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `phone` bigint(20) NOT NULL,
  `smtphost` varchar(255) NOT NULL,
  `smtpport` varchar(255) NOT NULL,
  `smtpuser` varchar(255) NOT NULL,
  `smtppass` varchar(255) NOT NULL,
  `no_days` text NOT NULL,
  `domain` text NOT NULL,
  `file_type` text NOT NULL,
  PRIMARY KEY (`configuration_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `configuration`
--

INSERT INTO `configuration` (`configuration_id`, `title`, `logo`, `email`, `address`, `phone`, `smtphost`, `smtpport`, `smtpuser`, `smtppass`, `no_days`, `domain`, `file_type`) VALUES
(1, 'ALT Digital Media Entertainment Limited', '', 'nikunjkaria@gmail.com', '302, Satyadev Plaza, Behind Hardrock Cafe, Off Veera Desai Road, Andheri West, Mumbai - 400 053', 9920266551, 'ssl://smtp.gmail.com', '465', 'mydigitaldelivery@gmail.com', 'Lotus@123', '1,3,5,7', '@afterdoor.com,@gmail.com', 'jpeg,png');

-- --------------------------------------------------------

--
-- Table structure for table `download`
--

CREATE TABLE IF NOT EXISTS `download` (
  `download_id` int(11) NOT NULL AUTO_INCREMENT,
  `filename` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `filesize` bigint(20) NOT NULL,
  `ip` varchar(20) NOT NULL,
  PRIMARY KEY (`download_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `files`
--

CREATE TABLE IF NOT EXISTS `files` (
  `files_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL COMMENT 'reciver''s id',
  `session_id` int(11) DEFAULT NULL,
  `filename` varchar(2000) NOT NULL,
  `filesize` varchar(1000) NOT NULL COMMENT 'bytes',
  `totalfilesize` bigint(20) NOT NULL,
  `onetime` int(11) NOT NULL COMMENT 'one time download 1 for yes 0 for no',
  `description` text NOT NULL,
  `subject` varchar(255) NOT NULL,
  `validity` int(11) NOT NULL,
  `expiry` datetime NOT NULL,
  `delete_user` int(11) NOT NULL DEFAULT '0',
  `delete_recevier` int(11) NOT NULL DEFAULT '0',
  `delete_all` int(11) NOT NULL DEFAULT '0',
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`files_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `group`
--

CREATE TABLE IF NOT EXISTS `group` (
  `group_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `default` int(11) NOT NULL DEFAULT '0' COMMENT '1:default group',
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`group_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `group`
--

INSERT INTO `group` (`group_id`, `name`, `default`, `timestamp`) VALUES
(1, 'Admin', 0, '2017-05-31 08:11:18');

-- --------------------------------------------------------

--
-- Table structure for table `help_replies`
--

CREATE TABLE IF NOT EXISTS `help_replies` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `help_id` int(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `file` varchar(255) NOT NULL,
  `user_id` int(255) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `help_ticket`
--

CREATE TABLE IF NOT EXISTS `help_ticket` (
  `help_id` int(100) NOT NULL AUTO_INCREMENT,
  `help_department` varchar(255) NOT NULL,
  `help_subject` varchar(255) NOT NULL,
  `help_priority` varchar(255) NOT NULL,
  `help_description` varchar(255) NOT NULL,
  `help_file` varchar(255) NOT NULL,
  `help_status` varchar(255) NOT NULL DEFAULT 'open',
  `help_userid` int(100) NOT NULL,
  `help_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`help_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `language`
--

CREATE TABLE IF NOT EXISTS `language` (
  `language_id` int(11) NOT NULL AUTO_INCREMENT,
  `category` text NOT NULL,
  `name` varchar(200) NOT NULL,
  `key` text NOT NULL,
  `description` text NOT NULL,
  `lang` text NOT NULL,
  `token` text NOT NULL,
  PRIMARY KEY (`language_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `language`
--

INSERT INTO `language` (`language_id`, `category`, `name`, `key`, `description`, `lang`, `token`) VALUES
(1, 'error', 'No Email', 'noMail', '', 'english', 'You must submit a valid email address336434545'),
(2, 'success', 'User Not found', 'noUser', '', 'english', 'You must submit a username2324'),
(3, 'general', '', 'noUser', 'You must submit a username', 'english', 'You must submit a username2324'),
(4, 'warning', '', 'noUser', '', 'english', 'You must submit a username4235235'),
(5, 'information', '', 'noUser', '', 'english', 'You must submit a username436436'),
(6, 'information', 'Settings Message', 'settings_config', '', 'english', '* Some settings will affect after reloading the page');

-- --------------------------------------------------------

--
-- Table structure for table `ldap`
--

CREATE TABLE IF NOT EXISTS `ldap` (
  `ldap_id` int(11) NOT NULL AUTO_INCREMENT,
  `host` varchar(225) NOT NULL,
  `port` varchar(225) NOT NULL,
  `ldapuser` varchar(225) NOT NULL,
  `ldappass` varchar(225) NOT NULL,
  `domain` text NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `modified_at` datetime NOT NULL,
  PRIMARY KEY (`ldap_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `ldap`
--

INSERT INTO `ldap` (`ldap_id`, `host`, `port`, `ldapuser`, `ldappass`, `domain`, `status`, `modified_at`) VALUES
(1, '192.168.0.150', '465', 'dmokha@domain.local', 'Windows@2017', 'domain.local', 0, '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `licence`
--

CREATE TABLE IF NOT EXISTS `licence` (
  `licence_id` int(11) NOT NULL AUTO_INCREMENT,
  `domains` text NOT NULL,
  `key` varchar(40) NOT NULL,
  `startdate` varchar(100) NOT NULL,
  `enddate` varchar(100) NOT NULL,
  `packagename` varchar(100) NOT NULL,
  `curver` varchar(10) NOT NULL,
  `status` varchar(15) NOT NULL,
  PRIMARY KEY (`licence_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `licence`
--

INSERT INTO `licence` (`licence_id`, `domains`, `key`, `startdate`, `enddate`, `packagename`, `curver`, `status`) VALUES
(10, 'a:2:{i:0;s:11:"www.dam.com";i:1;s:17:"www.afterdoor.com";}', '456', '2016/07/31', '2019/01/31', 'Test Package', '1.2', 'activated');

-- --------------------------------------------------------

--
-- Table structure for table `package`
--

CREATE TABLE IF NOT EXISTS `package` (
  `package_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `price` int(11) NOT NULL,
  `size` int(11) NOT NULL,
  `packageorder` int(11) NOT NULL,
  `bandwidth` int(11) NOT NULL,
  `validity` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`package_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `package`
--

INSERT INTO `package` (`package_id`, `name`, `price`, `size`, `packageorder`, `bandwidth`, `validity`, `status`, `timestamp`) VALUES
(1, 'Basic', 0, 500000, 0, 0, 0, 1, '2016-05-06 06:22:56');

-- --------------------------------------------------------

--
-- Table structure for table `package_request`
--

CREATE TABLE IF NOT EXISTS `package_request` (
  `package_request_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `package_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `status` int(11) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`package_request_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `session`
--

CREATE TABLE IF NOT EXISTS `session` (
  `session_id` int(11) NOT NULL AUTO_INCREMENT,
  `session_key` varchar(128) NOT NULL,
  `otp` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `type` text NOT NULL,
  `what` varchar(100) NOT NULL DEFAULT '0',
  `mailid` int(11) DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `lname` varchar(255) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `image` varchar(255) NOT NULL DEFAULT '',
  `department` varchar(255) DEFAULT NULL,
  `type` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  `status` int(11) NOT NULL COMMENT '0-pending; 1-accpeted;2-registeration pending; 3 inactive by admin',
  `package_id` int(11) NOT NULL DEFAULT '1',
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `temppass` varchar(200) NOT NULL,
  `package_validity` varchar(20) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=168 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES
(1, 'drophere@altdigital.in', '81dc9bdb52d04dc20036dbd8313ed055', 'Admin', 'Admin', '912242575900', 'bann.jpg', NULL, 3, 5, 1, 1, '2017-05-31 11:36:18', '', '');


-- --------------------------------------------------------

--
-- Table structure for table `current_uploads`
--

CREATE TABLE IF NOT EXISTS `current_uploads` (
  `current_uploads_id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `user_id` text NOT NULL,
  `cc_email` varchar(255) DEFAULT NULL,
  `subject` varchar(255) NOT NULL,
  `description` text,
  `validity` varchar(255) NOT NULL,
  `percentage` text NOT NULL,
  `current_file_size` text NOT NULL,
  `total_file_size` text NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL,
  `modified_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`current_uploads_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
