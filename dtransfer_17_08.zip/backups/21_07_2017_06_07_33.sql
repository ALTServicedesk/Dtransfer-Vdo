#
# TABLE STRUCTURE FOR: config
#

DROP TABLE IF EXISTS `config`;

CREATE TABLE `config` (
  `config_id` int(11) NOT NULL AUTO_INCREMENT,
  `category` text NOT NULL,
  `name` varchar(200) NOT NULL,
  `key` text NOT NULL,
  `description` text NOT NULL,
  `lang` text NOT NULL,
  `token` text NOT NULL,
  `type` varchar(100) NOT NULL COMMENT 'type eg, radio,checkbox,select,textarea,text',
  `data` text NOT NULL COMMENT 'should be seprated by comma',
  PRIMARY KEY (`config_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

INSERT INTO `config` (`config_id`, `category`, `name`, `key`, `description`, `lang`, `token`, `type`, `data`) VALUES ('1', 'general', 'Site Title', 'sitetitle', 'Site title which will be displayed in title bar of browser', 'english', 'ALT Digital Media Entertainment Limited', '', '');
INSERT INTO `config` (`config_id`, `category`, `name`, `key`, `description`, `lang`, `token`, `type`, `data`) VALUES ('2', 'general', 'Copyright Message', 'copyright', 'Copyright text in the footer.', 'english', '© ALT Digital Media Entertainment Limited', '', '');
INSERT INTO `config` (`config_id`, `category`, `name`, `key`, `description`, `lang`, `token`, `type`, `data`) VALUES ('3', 'user', 'Public signup', 'allow_signup', 'Copyright text in the footer.', 'english', 'yes', 'radiotoggle', 'yes,no');
INSERT INTO `config` (`config_id`, `category`, `name`, `key`, `description`, `lang`, `token`, `type`, `data`) VALUES ('4', 'general', 'Date Format', 'dateformat', 'd=date, i-', 'english', 'd-m-Y', 'text', '');
INSERT INTO `config` (`config_id`, `category`, `name`, `key`, `description`, `lang`, `token`, `type`, `data`) VALUES ('5', 'general', 'Date/Time Format', 'datetimeformat', 'd=date, i-', 'english', 'd-M-Y H:m:s', 'text', '');
INSERT INTO `config` (`config_id`, `category`, `name`, `key`, `description`, `lang`, `token`, `type`, `data`) VALUES ('6', 'user', 'OTP on Phone', 'allow_otp_phone', 'allow otp ', 'english', 'no', 'radiotoggle', 'yes,no');
INSERT INTO `config` (`config_id`, `category`, `name`, `key`, `description`, `lang`, `token`, `type`, `data`) VALUES ('7', 'user', 'OTP on Email', 'allow_otp_email', 'allow otp ', 'english', 'no', 'radiotoggle', 'yes,no');
INSERT INTO `config` (`config_id`, `category`, `name`, `key`, `description`, `lang`, `token`, `type`, `data`) VALUES ('8', 'user', 'Domain Restriction', 'domain_restriction', 'If this is enabled we will verify atleast one email in to,cc,bcc will be from this domain', 'english', 'no', 'radiotoggle', 'yes,no');


#
# TABLE STRUCTURE FOR: configuration
#

DROP TABLE IF EXISTS `configuration`;

CREATE TABLE `configuration` (
  `configuration_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `phone` bigint(20) NOT NULL,
  `smtphost` varchar(255) NOT NULL,
  `smtpport` varchar(255) NOT NULL,
  `smtpuser` varchar(255) NOT NULL,
  `smtppass` varchar(255) NOT NULL,
  `no_days` text NOT NULL,
  `domain` text NOT NULL,
  `file_type` text NOT NULL,
  PRIMARY KEY (`configuration_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `configuration` (`configuration_id`, `title`, `logo`, `email`, `address`, `phone`, `smtphost`, `smtpport`, `smtpuser`, `smtppass`, `no_days`, `domain`, `file_type`) VALUES ('1', 'ALT Digital Media Entertainment Limited', '', 'nikunjkaria@gmail.com', '302, Satyadev Plaza, Behind Hardrock Cafe, Off Veera Desai Road, Andheri West, Mumbai - 400 053', '9920266551', 'ssl://smtp.gmail.com', '465', 'mydigitaldelivery@gmail.com', 'Lotus@123', '1,3,5,7', '@afterdoor.com,@gmail.com,@domain.local', 'jpg,png');


#
# TABLE STRUCTURE FOR: download
#

DROP TABLE IF EXISTS `download`;

CREATE TABLE `download` (
  `download_id` int(11) NOT NULL AUTO_INCREMENT,
  `filename` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `filesize` bigint(20) NOT NULL,
  `ip` varchar(20) NOT NULL,
  PRIMARY KEY (`download_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `download` (`download_id`, `filename`, `user_id`, `timestamp`, `filesize`, `ip`) VALUES ('1', 'Untitled.png', '21', '2017-07-02 19:35:17', '51874', '::1');
INSERT INTO `download` (`download_id`, `filename`, `user_id`, `timestamp`, `filesize`, `ip`) VALUES ('2', 'Untitled (1).png', '22', '2017-07-02 19:37:32', '51874', '::1');
INSERT INTO `download` (`download_id`, `filename`, `user_id`, `timestamp`, `filesize`, `ip`) VALUES ('3', 'test4 (2).jpg', '22', '2017-07-02 19:43:44', '66938', '::1');
INSERT INTO `download` (`download_id`, `filename`, `user_id`, `timestamp`, `filesize`, `ip`) VALUES ('4', 'test4 (2).jpg', '22', '2017-07-02 19:43:56', '66938', '::1');
INSERT INTO `download` (`download_id`, `filename`, `user_id`, `timestamp`, `filesize`, `ip`) VALUES ('5', 'wood-coffee-iphone-notebook (3).jpg', '20', '2017-07-02 20:11:42', '6813372', '::1');


#
# TABLE STRUCTURE FOR: files
#

DROP TABLE IF EXISTS `files`;

CREATE TABLE `files` (
  `files_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL COMMENT 'reciver''s id',
  `session_id` int(11) DEFAULT NULL,
  `filename` varchar(2000) NOT NULL,
  `filesize` varchar(1000) NOT NULL COMMENT 'bytes',
  `totalfilesize` bigint(20) NOT NULL,
  `onetime` int(11) NOT NULL COMMENT 'one time download 1 for yes 0 for no',
  `description` text NOT NULL,
  `subject` varchar(255) NOT NULL,
  `validity` int(11) NOT NULL,
  `expiry` datetime NOT NULL,
  `delete_user` int(11) NOT NULL DEFAULT '0',
  `delete_recevier` int(11) NOT NULL DEFAULT '0',
  `delete_all` int(11) NOT NULL DEFAULT '0',
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`files_id`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=latin1;

INSERT INTO `files` (`files_id`, `user_id`, `staff_id`, `session_id`, `filename`, `filesize`, `totalfilesize`, `onetime`, `description`, `subject`, `validity`, `expiry`, `delete_user`, `delete_recevier`, `delete_all`, `timestamp`) VALUES ('1', '2', '3', '2', ' ukphlogo.PNG', ' 22942', '22942', '1', '<p>sdfg</p>', 'dfg', '7', '0000-00-00 00:00:00', '0', '0', '0', '2017-06-02 17:40:11');
INSERT INTO `files` (`files_id`, `user_id`, `staff_id`, `session_id`, `filename`, `filesize`, `totalfilesize`, `onetime`, `description`, `subject`, `validity`, `expiry`, `delete_user`, `delete_recevier`, `delete_all`, `timestamp`) VALUES ('2', '2', '3', '2', ' ukphlogo (1).PNG', ' 22942', '22942', '1', '<p>sdfg</p>', 'dfg', '7', '2017-06-09 17:42:38', '0', '0', '0', '2017-06-02 17:42:38');
INSERT INTO `files` (`files_id`, `user_id`, `staff_id`, `session_id`, `filename`, `filesize`, `totalfilesize`, `onetime`, `description`, `subject`, `validity`, `expiry`, `delete_user`, `delete_recevier`, `delete_all`, `timestamp`) VALUES ('3', '2', '4', '3', ' ukphlogo (2).PNG', ' 22942', '22942', '1', '<p>gn</p>', 'cgnc', '7', '0000-00-00 00:00:00', '0', '0', '0', '2017-06-02 17:43:50');
INSERT INTO `files` (`files_id`, `user_id`, `staff_id`, `session_id`, `filename`, `filesize`, `totalfilesize`, `onetime`, `description`, `subject`, `validity`, `expiry`, `delete_user`, `delete_recevier`, `delete_all`, `timestamp`) VALUES ('4', '2', '4', '3', ' ukphlogo (3).PNG', ' 22942', '22942', '1', '<p>gn</p>', 'cgnc', '7', '2017-06-09 17:45:04', '0', '0', '0', '2017-06-02 17:45:04');
INSERT INTO `files` (`files_id`, `user_id`, `staff_id`, `session_id`, `filename`, `filesize`, `totalfilesize`, `onetime`, `description`, `subject`, `validity`, `expiry`, `delete_user`, `delete_recevier`, `delete_all`, `timestamp`) VALUES ('5', '4', '5', '4', ' ukphlogo (4).PNG', ' 22942', '22942', '1', '<p>asf</p>', 'asd', '7', '0000-00-00 00:00:00', '0', '0', '0', '2017-06-02 17:55:09');
INSERT INTO `files` (`files_id`, `user_id`, `staff_id`, `session_id`, `filename`, `filesize`, `totalfilesize`, `onetime`, `description`, `subject`, `validity`, `expiry`, `delete_user`, `delete_recevier`, `delete_all`, `timestamp`) VALUES ('6', '4', '5', '4', ' ukphlogo (5).PNG', ' 22942', '22942', '1', '<p>asf</p>', 'asd', '7', '2017-06-09 17:56:41', '0', '0', '0', '2017-06-02 17:56:41');
INSERT INTO `files` (`files_id`, `user_id`, `staff_id`, `session_id`, `filename`, `filesize`, `totalfilesize`, `onetime`, `description`, `subject`, `validity`, `expiry`, `delete_user`, `delete_recevier`, `delete_all`, `timestamp`) VALUES ('7', '4', '6', '5', ' ukphlogo (6).PNG', ' 22942', '22942', '1', '<p>SD</p>', 'asD', '7', '0000-00-00 00:00:00', '0', '0', '0', '2017-06-02 17:57:46');
INSERT INTO `files` (`files_id`, `user_id`, `staff_id`, `session_id`, `filename`, `filesize`, `totalfilesize`, `onetime`, `description`, `subject`, `validity`, `expiry`, `delete_user`, `delete_recevier`, `delete_all`, `timestamp`) VALUES ('8', '4', '6', '6', ' ukphlogo (7).PNG', ' 22942', '22942', '1', '<p>xfh</p>', 'dfg', '7', '2017-06-09 17:59:04', '0', '0', '0', '2017-06-02 17:59:04');
INSERT INTO `files` (`files_id`, `user_id`, `staff_id`, `session_id`, `filename`, `filesize`, `totalfilesize`, `onetime`, `description`, `subject`, `validity`, `expiry`, `delete_user`, `delete_recevier`, `delete_all`, `timestamp`) VALUES ('9', '2', '6', '8', ' phoenixother.jpg', ' 658247', '658247', '1', '<p>sdfg</p>', 'qedg', '3', '2017-06-30 11:42:03', '0', '0', '0', '2017-06-27 11:42:03');
INSERT INTO `files` (`files_id`, `user_id`, `staff_id`, `session_id`, `filename`, `filesize`, `totalfilesize`, `onetime`, `description`, `subject`, `validity`, `expiry`, `delete_user`, `delete_recevier`, `delete_all`, `timestamp`) VALUES ('10', '2', '6', '8', ' phoenixother.jpg', ' 658247', '658247', '1', '<p>sdfg</p>', 'qedg', '3', '2017-06-30 11:42:03', '0', '0', '0', '2017-06-27 11:42:08');
INSERT INTO `files` (`files_id`, `user_id`, `staff_id`, `session_id`, `filename`, `filesize`, `totalfilesize`, `onetime`, `description`, `subject`, `validity`, `expiry`, `delete_user`, `delete_recevier`, `delete_all`, `timestamp`) VALUES ('11', '2', '6', '9', ' Phoenix.jpg', ' 267276', '267276', '1', '<p>df</p>', 'dfgh', '3', '2017-06-30 11:47:31', '0', '0', '0', '2017-06-27 11:47:31');
INSERT INTO `files` (`files_id`, `user_id`, `staff_id`, `session_id`, `filename`, `filesize`, `totalfilesize`, `onetime`, `description`, `subject`, `validity`, `expiry`, `delete_user`, `delete_recevier`, `delete_all`, `timestamp`) VALUES ('12', '2', '6', '9', ' Phoenix.jpg', ' 267276', '267276', '1', '<p>df</p>', 'dfgh', '3', '2017-06-30 11:47:31', '0', '0', '0', '2017-06-27 11:47:36');
INSERT INTO `files` (`files_id`, `user_id`, `staff_id`, `session_id`, `filename`, `filesize`, `totalfilesize`, `onetime`, `description`, `subject`, `validity`, `expiry`, `delete_user`, `delete_recevier`, `delete_all`, `timestamp`) VALUES ('13', '1', '7', '1', ' IMG201706120003.jpg', ' 1540701', '1540701', '1', '<p>dfg</p>', 'sh', '3', '2017-06-30 12:34:16', '0', '0', '0', '2017-06-27 12:34:16');
INSERT INTO `files` (`files_id`, `user_id`, `staff_id`, `session_id`, `filename`, `filesize`, `totalfilesize`, `onetime`, `description`, `subject`, `validity`, `expiry`, `delete_user`, `delete_recevier`, `delete_all`, `timestamp`) VALUES ('14', '1', '8', '10', ' Phoenix (1).jpg', ' 267276', '267276', '1', '<p>asd</p>', 'sdgv', '7', '0000-00-00 00:00:00', '0', '0', '0', '2017-06-27 12:40:21');
INSERT INTO `files` (`files_id`, `user_id`, `staff_id`, `session_id`, `filename`, `filesize`, `totalfilesize`, `onetime`, `description`, `subject`, `validity`, `expiry`, `delete_user`, `delete_recevier`, `delete_all`, `timestamp`) VALUES ('15', '1', '9', '10', ' IMG201706120003 (2).jpg', ' 1540701', '1540701', '1', '<p>asd</p>', 'sdgv', '7', '0000-00-00 00:00:00', '0', '0', '0', '2017-06-27 12:43:13');
INSERT INTO `files` (`files_id`, `user_id`, `staff_id`, `session_id`, `filename`, `filesize`, `totalfilesize`, `onetime`, `description`, `subject`, `validity`, `expiry`, `delete_user`, `delete_recevier`, `delete_all`, `timestamp`) VALUES ('16', '10', '11', '12', ' IMG201706120003 (3).jpg', ' 1540701', '1540701', '1', '<p>jo</p>', 'Test', '7', '0000-00-00 00:00:00', '0', '0', '0', '2017-06-27 14:47:11');
INSERT INTO `files` (`files_id`, `user_id`, `staff_id`, `session_id`, `filename`, `filesize`, `totalfilesize`, `onetime`, `description`, `subject`, `validity`, `expiry`, `delete_user`, `delete_recevier`, `delete_all`, `timestamp`) VALUES ('17', '10', '12', '12', ' IMG201706120003 (3).jpg', ' 1540701', '1540701', '1', '<p>jo</p>', 'Test', '7', '0000-00-00 00:00:00', '0', '0', '0', '2017-06-27 14:47:19');
INSERT INTO `files` (`files_id`, `user_id`, `staff_id`, `session_id`, `filename`, `filesize`, `totalfilesize`, `onetime`, `description`, `subject`, `validity`, `expiry`, `delete_user`, `delete_recevier`, `delete_all`, `timestamp`) VALUES ('18', '2', '15', '14', ' IMG20170604211050.jpg', ' 454715', '454715', '1', '<p>test</p>', 'test', '3', '0000-00-00 00:00:00', '0', '0', '0', '2017-06-28 13:25:07');
INSERT INTO `files` (`files_id`, `user_id`, `staff_id`, `session_id`, `filename`, `filesize`, `totalfilesize`, `onetime`, `description`, `subject`, `validity`, `expiry`, `delete_user`, `delete_recevier`, `delete_all`, `timestamp`) VALUES ('19', '2', '11', '14', ' IMG20170604211050.jpg', ' 454715', '454715', '1', '<p>test</p>', 'test', '3', '0000-00-00 00:00:00', '0', '0', '0', '2017-06-28 13:25:11');
INSERT INTO `files` (`files_id`, `user_id`, `staff_id`, `session_id`, `filename`, `filesize`, `totalfilesize`, `onetime`, `description`, `subject`, `validity`, `expiry`, `delete_user`, `delete_recevier`, `delete_all`, `timestamp`) VALUES ('20', '2', '15', '15', ' IMG201706120003 (1).jpg', ' 1540701', '1540701', '1', '<p>dfg</p>', 'fg', '3', '2017-07-01 13:44:15', '0', '0', '0', '2017-06-28 13:44:15');
INSERT INTO `files` (`files_id`, `user_id`, `staff_id`, `session_id`, `filename`, `filesize`, `totalfilesize`, `onetime`, `description`, `subject`, `validity`, `expiry`, `delete_user`, `delete_recevier`, `delete_all`, `timestamp`) VALUES ('21', '2', '6', '15', ' IMG201706120003 (1).jpg', ' 1540701', '1540701', '1', '<p>dfg</p>', 'fg', '3', '2017-07-01 13:44:15', '0', '0', '0', '2017-06-28 13:44:19');
INSERT INTO `files` (`files_id`, `user_id`, `staff_id`, `session_id`, `filename`, `filesize`, `totalfilesize`, `onetime`, `description`, `subject`, `validity`, `expiry`, `delete_user`, `delete_recevier`, `delete_all`, `timestamp`) VALUES ('22', '2', '15', '16', ' NEW.jpg', ' 243751', '243751', '1', '<p>df</p>', 'dr', '3', '2017-07-01 13:45:35', '0', '0', '0', '2017-06-28 13:45:35');
INSERT INTO `files` (`files_id`, `user_id`, `staff_id`, `session_id`, `filename`, `filesize`, `totalfilesize`, `onetime`, `description`, `subject`, `validity`, `expiry`, `delete_user`, `delete_recevier`, `delete_all`, `timestamp`) VALUES ('23', '2', '11', '16', ' NEW.jpg', ' 243751', '243751', '1', '<p>df</p>', 'dr', '3', '2017-07-01 13:45:35', '0', '0', '0', '2017-06-28 13:45:39');
INSERT INTO `files` (`files_id`, `user_id`, `staff_id`, `session_id`, `filename`, `filesize`, `totalfilesize`, `onetime`, `description`, `subject`, `validity`, `expiry`, `delete_user`, `delete_recevier`, `delete_all`, `timestamp`) VALUES ('24', '2', '6', '16', ' NEW.jpg', ' 243751', '243751', '1', '<p>df</p>', 'dr', '3', '2017-07-01 13:45:35', '0', '0', '0', '2017-06-28 13:45:43');
INSERT INTO `files` (`files_id`, `user_id`, `staff_id`, `session_id`, `filename`, `filesize`, `totalfilesize`, `onetime`, `description`, `subject`, `validity`, `expiry`, `delete_user`, `delete_recevier`, `delete_all`, `timestamp`) VALUES ('25', '2', '15', '16', ' IMG201706120003 (2).jpg', ' 1540701', '1540701', '1', '<p>df</p>', 'dr', '3', '2017-07-01 13:49:40', '0', '0', '0', '2017-06-28 13:49:40');
INSERT INTO `files` (`files_id`, `user_id`, `staff_id`, `session_id`, `filename`, `filesize`, `totalfilesize`, `onetime`, `description`, `subject`, `validity`, `expiry`, `delete_user`, `delete_recevier`, `delete_all`, `timestamp`) VALUES ('26', '2', '11', '16', ' IMG201706120003 (2).jpg', ' 1540701', '1540701', '1', '<p>df</p>', 'dr', '3', '2017-07-01 13:49:40', '0', '0', '0', '2017-06-28 13:49:44');
INSERT INTO `files` (`files_id`, `user_id`, `staff_id`, `session_id`, `filename`, `filesize`, `totalfilesize`, `onetime`, `description`, `subject`, `validity`, `expiry`, `delete_user`, `delete_recevier`, `delete_all`, `timestamp`) VALUES ('27', '2', '6', '16', ' IMG201706120003 (2).jpg', ' 1540701', '1540701', '1', '<p>df</p>', 'dr', '3', '2017-07-01 13:49:40', '0', '0', '0', '2017-06-28 13:49:49');
INSERT INTO `files` (`files_id`, `user_id`, `staff_id`, `session_id`, `filename`, `filesize`, `totalfilesize`, `onetime`, `description`, `subject`, `validity`, `expiry`, `delete_user`, `delete_recevier`, `delete_all`, `timestamp`) VALUES ('28', '2', '15', '16', ' IMG20170604211050 (4).jpg', ' 454715', '454715', '1', '<p>df</p>', 'dr', '3', '2017-07-01 13:57:52', '0', '0', '0', '2017-06-28 13:57:52');
INSERT INTO `files` (`files_id`, `user_id`, `staff_id`, `session_id`, `filename`, `filesize`, `totalfilesize`, `onetime`, `description`, `subject`, `validity`, `expiry`, `delete_user`, `delete_recevier`, `delete_all`, `timestamp`) VALUES ('29', '2', '11', '16', ' IMG20170604211050 (4).jpg', ' 454715', '454715', '1', '<p>df</p>', 'dr', '3', '2017-07-01 13:57:52', '0', '0', '0', '2017-06-28 13:57:56');
INSERT INTO `files` (`files_id`, `user_id`, `staff_id`, `session_id`, `filename`, `filesize`, `totalfilesize`, `onetime`, `description`, `subject`, `validity`, `expiry`, `delete_user`, `delete_recevier`, `delete_all`, `timestamp`) VALUES ('30', '2', '6', '16', ' IMG20170604211050 (4).jpg', ' 454715', '454715', '1', '<p>df</p>', 'dr', '3', '2017-07-01 13:57:52', '0', '0', '0', '2017-06-28 13:57:56');
INSERT INTO `files` (`files_id`, `user_id`, `staff_id`, `session_id`, `filename`, `filesize`, `totalfilesize`, `onetime`, `description`, `subject`, `validity`, `expiry`, `delete_user`, `delete_recevier`, `delete_all`, `timestamp`) VALUES ('31', '2', '15', '16', ' phoenixother.jpg', ' 658247', '658247', '1', '<p>df</p>', 'dr', '3', '2017-07-01 13:58:58', '0', '0', '0', '2017-06-28 13:58:58');
INSERT INTO `files` (`files_id`, `user_id`, `staff_id`, `session_id`, `filename`, `filesize`, `totalfilesize`, `onetime`, `description`, `subject`, `validity`, `expiry`, `delete_user`, `delete_recevier`, `delete_all`, `timestamp`) VALUES ('32', '2', '11', '16', ' phoenixother.jpg', ' 658247', '658247', '1', '<p>df</p>', 'dr', '3', '2017-07-01 13:58:58', '0', '0', '0', '2017-06-28 13:59:02');
INSERT INTO `files` (`files_id`, `user_id`, `staff_id`, `session_id`, `filename`, `filesize`, `totalfilesize`, `onetime`, `description`, `subject`, `validity`, `expiry`, `delete_user`, `delete_recevier`, `delete_all`, `timestamp`) VALUES ('33', '2', '6', '16', ' phoenixother.jpg', ' 658247', '658247', '1', '<p>df</p>', 'dr', '3', '2017-07-01 13:58:58', '0', '0', '0', '2017-06-28 13:59:02');
INSERT INTO `files` (`files_id`, `user_id`, `staff_id`, `session_id`, `filename`, `filesize`, `totalfilesize`, `onetime`, `description`, `subject`, `validity`, `expiry`, `delete_user`, `delete_recevier`, `delete_all`, `timestamp`) VALUES ('34', '1', '16', '11', ' Phoenix.jpg', ' 267276', '267276', '1', '<p>Test</p>', 'Test', '7', '0000-00-00 00:00:00', '0', '0', '0', '2017-06-29 13:23:14');
INSERT INTO `files` (`files_id`, `user_id`, `staff_id`, `session_id`, `filename`, `filesize`, `totalfilesize`, `onetime`, `description`, `subject`, `validity`, `expiry`, `delete_user`, `delete_recevier`, `delete_all`, `timestamp`) VALUES ('35', '1', '11', '11', ' Phoenix.jpg', ' 267276', '267276', '1', '<p>Test</p>', 'Test', '7', '0000-00-00 00:00:00', '0', '0', '0', '2017-06-29 13:23:18');
INSERT INTO `files` (`files_id`, `user_id`, `staff_id`, `session_id`, `filename`, `filesize`, `totalfilesize`, `onetime`, `description`, `subject`, `validity`, `expiry`, `delete_user`, `delete_recevier`, `delete_all`, `timestamp`) VALUES ('36', '1', '17', '11', ' mins.png', ' 49138', '49138', '1', '<p>Test</p>', 'Test', '7', '0000-00-00 00:00:00', '0', '0', '0', '2017-06-29 13:37:32');
INSERT INTO `files` (`files_id`, `user_id`, `staff_id`, `session_id`, `filename`, `filesize`, `totalfilesize`, `onetime`, `description`, `subject`, `validity`, `expiry`, `delete_user`, `delete_recevier`, `delete_all`, `timestamp`) VALUES ('37', '1', '18', '11', ' mins.png', ' 49138', '49138', '1', '<p>Test</p>', 'Test', '7', '0000-00-00 00:00:00', '0', '0', '0', '2017-06-29 13:37:40');
INSERT INTO `files` (`files_id`, `user_id`, `staff_id`, `session_id`, `filename`, `filesize`, `totalfilesize`, `onetime`, `description`, `subject`, `validity`, `expiry`, `delete_user`, `delete_recevier`, `delete_all`, `timestamp`) VALUES ('38', '1', '19', '11', ' IMG201706120003.jpg', ' 1540701', '1540701', '1', '<p>Test</p>', 'Test', '7', '0000-00-00 00:00:00', '0', '0', '0', '2017-06-29 13:40:49');
INSERT INTO `files` (`files_id`, `user_id`, `staff_id`, `session_id`, `filename`, `filesize`, `totalfilesize`, `onetime`, `description`, `subject`, `validity`, `expiry`, `delete_user`, `delete_recevier`, `delete_all`, `timestamp`) VALUES ('39', '1', '20', '11', ' IMG201706120003.jpg', ' 1540701', '1540701', '1', '<p>Test</p>', 'Test', '7', '0000-00-00 00:00:00', '0', '0', '0', '2017-06-29 13:40:57');
INSERT INTO `files` (`files_id`, `user_id`, `staff_id`, `session_id`, `filename`, `filesize`, `totalfilesize`, `onetime`, `description`, `subject`, `validity`, `expiry`, `delete_user`, `delete_recevier`, `delete_all`, `timestamp`) VALUES ('40', '19', '21', '18', ' Untitled.png, rwdvYME9.jpg, ss-home-1-desktop-blur-only-bg.jpg, test4.jpg, wood-coffee-iphone-notebook.jpg', ' 51874, 24875, 80730, 66938, 6813372', '7037789', '1', '<p>one time</p>', 'One time', '7', '0000-00-00 00:00:00', '0', '0', '0', '2017-07-02 19:34:36');
INSERT INTO `files` (`files_id`, `user_id`, `staff_id`, `session_id`, `filename`, `filesize`, `totalfilesize`, `onetime`, `description`, `subject`, `validity`, `expiry`, `delete_user`, `delete_recevier`, `delete_all`, `timestamp`) VALUES ('41', '19', '22', '18', ' Untitled.png, rwdvYME9.jpg, ss-home-1-desktop-blur-only-bg.jpg, test4.jpg, wood-coffee-iphone-notebook.jpg', ' 51874, 24875, 80730, 66938, 6813372', '7037789', '1', '<p>one time</p>', 'One time', '7', '0000-00-00 00:00:00', '0', '0', '0', '2017-07-02 19:34:44');
INSERT INTO `files` (`files_id`, `user_id`, `staff_id`, `session_id`, `filename`, `filesize`, `totalfilesize`, `onetime`, `description`, `subject`, `validity`, `expiry`, `delete_user`, `delete_recevier`, `delete_all`, `timestamp`) VALUES ('42', '19', '22', '20', ' rwdvYME9 (1).jpg, ss-home-1-desktop-blur-only-bg (1).jpg, test4 (1).jpg, wood-coffee-iphone-notebook (1).jpg, Untitled (1).png', ' 24875, 80730, 66938, 6813372, 51874', '7037789', '1', '<p>hi</p>', 'ADMIN IN CC', '7', '2017-07-09 19:36:23', '0', '0', '0', '2017-07-02 19:36:23');
INSERT INTO `files` (`files_id`, `user_id`, `staff_id`, `session_id`, `filename`, `filesize`, `totalfilesize`, `onetime`, `description`, `subject`, `validity`, `expiry`, `delete_user`, `delete_recevier`, `delete_all`, `timestamp`) VALUES ('43', '19', '20', '20', ' rwdvYME9 (1).jpg, ss-home-1-desktop-blur-only-bg (1).jpg, test4 (1).jpg, wood-coffee-iphone-notebook (1).jpg, Untitled (1).png', ' 24875, 80730, 66938, 6813372, 51874', '7037789', '1', '<p>hi</p>', 'ADMIN IN CC', '7', '2017-07-09 19:36:23', '0', '0', '0', '2017-07-02 19:36:27');
INSERT INTO `files` (`files_id`, `user_id`, `staff_id`, `session_id`, `filename`, `filesize`, `totalfilesize`, `onetime`, `description`, `subject`, `validity`, `expiry`, `delete_user`, `delete_recevier`, `delete_all`, `timestamp`) VALUES ('44', '19', '22', '22', ' test4 (2).jpg, Untitled (2).png, wood-coffee-iphone-notebook (2).jpg', ' 66938, 51874, 6813372', '6932184', '1', '<p>hi</p>', 'Test', '1', '2017-07-03 19:40:57', '0', '0', '0', '2017-07-02 19:40:57');
INSERT INTO `files` (`files_id`, `user_id`, `staff_id`, `session_id`, `filename`, `filesize`, `totalfilesize`, `onetime`, `description`, `subject`, `validity`, `expiry`, `delete_user`, `delete_recevier`, `delete_all`, `timestamp`) VALUES ('45', '19', '23', '22', ' test4 (2).jpg, Untitled (2).png, wood-coffee-iphone-notebook (2).jpg', ' 66938, 51874, 6813372', '6932184', '1', '<p>hi</p>', 'Test', '1', '0000-00-00 00:00:00', '0', '0', '0', '2017-07-02 19:41:05');
INSERT INTO `files` (`files_id`, `user_id`, `staff_id`, `session_id`, `filename`, `filesize`, `totalfilesize`, `onetime`, `description`, `subject`, `validity`, `expiry`, `delete_user`, `delete_recevier`, `delete_all`, `timestamp`) VALUES ('46', '19', '20', '24', ' test4 (3).jpg, Untitled (3).png, wood-coffee-iphone-notebook (3).jpg', ' 66938, 51874, 6813372', '6932184', '1', '<p>hi</p>', 'hi', '7', '2017-07-09 20:02:06', '0', '0', '0', '2017-07-02 20:02:06');
INSERT INTO `files` (`files_id`, `user_id`, `staff_id`, `session_id`, `filename`, `filesize`, `totalfilesize`, `onetime`, `description`, `subject`, `validity`, `expiry`, `delete_user`, `delete_recevier`, `delete_all`, `timestamp`) VALUES ('47', '19', '23', '24', ' test4 (3).jpg, Untitled (3).png, wood-coffee-iphone-notebook (3).jpg', ' 66938, 51874, 6813372', '6932184', '1', '<p>hi</p>', 'hi', '7', '2017-07-09 20:02:06', '0', '0', '0', '2017-07-02 20:02:11');
INSERT INTO `files` (`files_id`, `user_id`, `staff_id`, `session_id`, `filename`, `filesize`, `totalfilesize`, `onetime`, `description`, `subject`, `validity`, `expiry`, `delete_user`, `delete_recevier`, `delete_all`, `timestamp`) VALUES ('48', '19', '22', '24', ' test4 (3).jpg, Untitled (3).png, wood-coffee-iphone-notebook (3).jpg', ' 66938, 51874, 6813372', '6932184', '1', '<p>hi</p>', 'hi', '7', '2017-07-09 20:02:06', '0', '0', '0', '2017-07-02 20:02:11');


#
# TABLE STRUCTURE FOR: group
#

DROP TABLE IF EXISTS `group`;

CREATE TABLE `group` (
  `group_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `default` int(11) NOT NULL DEFAULT '0' COMMENT '1:default group',
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`group_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `group` (`group_id`, `name`, `default`, `timestamp`) VALUES ('1', 'Admin', '0', '2017-05-31 13:41:18');


#
# TABLE STRUCTURE FOR: help_replies
#

DROP TABLE IF EXISTS `help_replies`;

CREATE TABLE `help_replies` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `help_id` int(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `file` varchar(255) NOT NULL,
  `user_id` int(255) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: help_ticket
#

DROP TABLE IF EXISTS `help_ticket`;

CREATE TABLE `help_ticket` (
  `help_id` int(100) NOT NULL AUTO_INCREMENT,
  `help_department` varchar(255) NOT NULL,
  `help_subject` varchar(255) NOT NULL,
  `help_priority` varchar(255) NOT NULL,
  `help_description` varchar(255) NOT NULL,
  `help_file` varchar(255) NOT NULL,
  `help_status` varchar(255) NOT NULL DEFAULT 'open',
  `help_userid` int(100) NOT NULL,
  `help_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`help_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: language
#

DROP TABLE IF EXISTS `language`;

CREATE TABLE `language` (
  `language_id` int(11) NOT NULL AUTO_INCREMENT,
  `category` text NOT NULL,
  `name` varchar(200) NOT NULL,
  `key` text NOT NULL,
  `description` text NOT NULL,
  `lang` text NOT NULL,
  `token` text NOT NULL,
  PRIMARY KEY (`language_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO `language` (`language_id`, `category`, `name`, `key`, `description`, `lang`, `token`) VALUES ('1', 'error', 'No Email', 'noMail', '', 'english', 'You must submit a valid email address336434545');
INSERT INTO `language` (`language_id`, `category`, `name`, `key`, `description`, `lang`, `token`) VALUES ('2', 'success', 'User Not found', 'noUser', '', 'english', 'You must submit a username2324');
INSERT INTO `language` (`language_id`, `category`, `name`, `key`, `description`, `lang`, `token`) VALUES ('3', 'general', '', 'noUser', 'You must submit a username', 'english', 'You must submit a username2324');
INSERT INTO `language` (`language_id`, `category`, `name`, `key`, `description`, `lang`, `token`) VALUES ('4', 'warning', '', 'noUser', '', 'english', 'You must submit a username4235235');
INSERT INTO `language` (`language_id`, `category`, `name`, `key`, `description`, `lang`, `token`) VALUES ('5', 'information', '', 'noUser', '', 'english', 'You must submit a username436436');
INSERT INTO `language` (`language_id`, `category`, `name`, `key`, `description`, `lang`, `token`) VALUES ('6', 'information', 'Settings Message', 'settings_config', '', 'english', '* Some settings will affect after reloading the page');


#
# TABLE STRUCTURE FOR: ldap
#

DROP TABLE IF EXISTS `ldap`;

CREATE TABLE `ldap` (
  `ldap_id` int(11) NOT NULL AUTO_INCREMENT,
  `host` varchar(225) NOT NULL,
  `port` varchar(225) NOT NULL,
  `ldapuser` varchar(225) NOT NULL,
  `ldappass` varchar(225) NOT NULL,
  `domain` text NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `modified_at` datetime NOT NULL,
  PRIMARY KEY (`ldap_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `ldap` (`ldap_id`, `host`, `port`, `ldapuser`, `ldappass`, `domain`, `status`, `modified_at`) VALUES ('1', '192.168.0.150', '465', 'dtransfer@domain.local', 'Daman0587', 'domain.local', '0', '0000-00-00 00:00:00');


#
# TABLE STRUCTURE FOR: licence
#

DROP TABLE IF EXISTS `licence`;

CREATE TABLE `licence` (
  `licence_id` int(11) NOT NULL AUTO_INCREMENT,
  `domains` text NOT NULL,
  `key` varchar(40) NOT NULL,
  `startdate` varchar(100) NOT NULL,
  `enddate` varchar(100) NOT NULL,
  `packagename` varchar(100) NOT NULL,
  `curver` varchar(10) NOT NULL,
  `status` varchar(15) NOT NULL,
  PRIMARY KEY (`licence_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

INSERT INTO `licence` (`licence_id`, `domains`, `key`, `startdate`, `enddate`, `packagename`, `curver`, `status`) VALUES ('10', 'a:2:{i:0;s:11:\"www.dam.com\";i:1;s:17:\"www.afterdoor.com\";}', '456', '2016/07/31', '2019/01/31', 'Test Package', '1.2', 'activated');


#
# TABLE STRUCTURE FOR: package
#

DROP TABLE IF EXISTS `package`;

CREATE TABLE `package` (
  `package_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `price` int(11) NOT NULL,
  `size` int(11) NOT NULL,
  `packageorder` int(11) NOT NULL,
  `bandwidth` int(11) NOT NULL,
  `validity` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`package_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `package` (`package_id`, `name`, `price`, `size`, `packageorder`, `bandwidth`, `validity`, `status`, `timestamp`) VALUES ('1', 'Basic', '0', '500000', '0', '0', '0', '1', '2016-05-06 11:52:56');


#
# TABLE STRUCTURE FOR: package_request
#

DROP TABLE IF EXISTS `package_request`;

CREATE TABLE `package_request` (
  `package_request_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `package_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `status` int(11) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`package_request_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: session
#

DROP TABLE IF EXISTS `session`;

CREATE TABLE `session` (
  `session_id` int(11) NOT NULL AUTO_INCREMENT,
  `session_key` varchar(128) NOT NULL,
  `otp` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `type` text NOT NULL,
  `what` varchar(100) NOT NULL DEFAULT '0',
  `mailid` int(11) DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`session_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;

INSERT INTO `session` (`session_id`, `session_key`, `otp`, `user_id`, `status`, `type`, `what`, `mailid`, `timestamp`) VALUES ('1', '8ed489b3fdc83284fb41edbc9fe7d501', '3888', '1', '1', 'upload', 'none', '0', '2017-06-27 12:34:16');
INSERT INTO `session` (`session_id`, `session_key`, `otp`, `user_id`, `status`, `type`, `what`, `mailid`, `timestamp`) VALUES ('2', '164f6e593bee7a6a9ec17d973d5923d3', '4909', '2', '1', 'upload', 'none', '0', '2017-06-02 17:40:11');
INSERT INTO `session` (`session_id`, `session_key`, `otp`, `user_id`, `status`, `type`, `what`, `mailid`, `timestamp`) VALUES ('3', '5356baa99c4f5a37b6fcc9864802194e', '8751', '2', '1', 'upload', 'none', '0', '2017-06-02 17:43:50');
INSERT INTO `session` (`session_id`, `session_key`, `otp`, `user_id`, `status`, `type`, `what`, `mailid`, `timestamp`) VALUES ('4', '0557961c2b32511050515fe2970cf802', '9058', '4', '1', 'upload', 'none', '0', '2017-06-02 17:55:09');
INSERT INTO `session` (`session_id`, `session_key`, `otp`, `user_id`, `status`, `type`, `what`, `mailid`, `timestamp`) VALUES ('5', '45b9b5357f71110df898602935d2708c', '2273', '4', '1', 'upload', 'none', '0', '2017-06-02 17:57:46');
INSERT INTO `session` (`session_id`, `session_key`, `otp`, `user_id`, `status`, `type`, `what`, `mailid`, `timestamp`) VALUES ('6', '411279b0ba364b993e1bc60ff6cf9a0e', '6130', '4', '1', 'upload', 'none', '0', '2017-06-02 17:59:04');
INSERT INTO `session` (`session_id`, `session_key`, `otp`, `user_id`, `status`, `type`, `what`, `mailid`, `timestamp`) VALUES ('7', '760cd5d09a1925e30c2f5b2bf9fbb4ef', '9957', '4', '0', 'upload', 'none', '0', '2017-06-02 18:00:26');
INSERT INTO `session` (`session_id`, `session_key`, `otp`, `user_id`, `status`, `type`, `what`, `mailid`, `timestamp`) VALUES ('8', 'e0b2afe98b056f951f9db3ff100774c2', '7716', '2', '1', 'upload', 'none', '0', '2017-06-27 11:42:03');
INSERT INTO `session` (`session_id`, `session_key`, `otp`, `user_id`, `status`, `type`, `what`, `mailid`, `timestamp`) VALUES ('9', '8a13d780be997fc190d11214a91bada6', '1519', '2', '1', 'upload', 'none', '0', '2017-06-27 11:47:31');
INSERT INTO `session` (`session_id`, `session_key`, `otp`, `user_id`, `status`, `type`, `what`, `mailid`, `timestamp`) VALUES ('10', 'c2d7ca9b9f42bb6144805f7b4d4d568d', '2243', '1', '1', 'upload', 'none', '0', '2017-06-27 12:40:21');
INSERT INTO `session` (`session_id`, `session_key`, `otp`, `user_id`, `status`, `type`, `what`, `mailid`, `timestamp`) VALUES ('11', '876057941f50379045421b5ff9bb7f1e', '5667', '1', '1', 'upload', 'none', '0', '2017-06-29 13:23:14');
INSERT INTO `session` (`session_id`, `session_key`, `otp`, `user_id`, `status`, `type`, `what`, `mailid`, `timestamp`) VALUES ('12', '21252678b96b1e616daec5a5882daa0e', '7686', '10', '1', 'upload', 'none', '0', '2017-06-27 14:47:11');
INSERT INTO `session` (`session_id`, `session_key`, `otp`, `user_id`, `status`, `type`, `what`, `mailid`, `timestamp`) VALUES ('13', '4ecee67640e995d3bb3eb6bd317c1efa', '1623', '14', '0', 'upload', 'none', '0', '2017-06-27 18:44:11');
INSERT INTO `session` (`session_id`, `session_key`, `otp`, `user_id`, `status`, `type`, `what`, `mailid`, `timestamp`) VALUES ('14', '62acc3393a570d206bbee275389b99b6', '7746', '2', '1', 'upload', 'none', '0', '2017-06-28 13:25:07');
INSERT INTO `session` (`session_id`, `session_key`, `otp`, `user_id`, `status`, `type`, `what`, `mailid`, `timestamp`) VALUES ('15', 'ba8bf8552fda3d6b6066d945edae2c82', '5870', '2', '1', 'upload', 'none', '0', '2017-06-28 13:44:15');
INSERT INTO `session` (`session_id`, `session_key`, `otp`, `user_id`, `status`, `type`, `what`, `mailid`, `timestamp`) VALUES ('16', '662e769cd03c5983e0ce86bd59af3f5c', '8066', '2', '1', 'upload', 'none', '0', '2017-06-28 13:45:35');
INSERT INTO `session` (`session_id`, `session_key`, `otp`, `user_id`, `status`, `type`, `what`, `mailid`, `timestamp`) VALUES ('17', '7d18be85d199aca697a71b99c34a5ea9', '9514', '2', '0', 'upload', 'none', '0', '2017-06-28 16:17:00');
INSERT INTO `session` (`session_id`, `session_key`, `otp`, `user_id`, `status`, `type`, `what`, `mailid`, `timestamp`) VALUES ('18', '2a7b47d42cec688eca03f169e86c08d9', '6655', '19', '1', 'upload', 'none', '0', '2017-07-02 19:34:37');
INSERT INTO `session` (`session_id`, `session_key`, `otp`, `user_id`, `status`, `type`, `what`, `mailid`, `timestamp`) VALUES ('19', '59115585ff9aba7ef51c2f3ae2901e81', '6728', '21', '1', 'download', 'none', '40', '2017-07-02 19:35:12');
INSERT INTO `session` (`session_id`, `session_key`, `otp`, `user_id`, `status`, `type`, `what`, `mailid`, `timestamp`) VALUES ('20', '7170afe7bc58a9bbc46e4eba89af5b40', '2326', '19', '1', 'upload', 'none', '0', '2017-07-02 19:36:23');
INSERT INTO `session` (`session_id`, `session_key`, `otp`, `user_id`, `status`, `type`, `what`, `mailid`, `timestamp`) VALUES ('21', '22a6ca7f4ba781727b13b73c9ba5b444', '5861', '22', '1', 'download', 'none', '42', '2017-07-02 19:37:27');
INSERT INTO `session` (`session_id`, `session_key`, `otp`, `user_id`, `status`, `type`, `what`, `mailid`, `timestamp`) VALUES ('22', '535c853ed36a0193dbad6937a39a8458', '9989', '19', '1', 'upload', 'none', '0', '2017-07-02 19:40:57');
INSERT INTO `session` (`session_id`, `session_key`, `otp`, `user_id`, `status`, `type`, `what`, `mailid`, `timestamp`) VALUES ('23', 'a1a2b8856d35c9610466ff902341c24b', '2367', '22', '1', 'download', 'none', '44', '2017-07-02 19:43:34');
INSERT INTO `session` (`session_id`, `session_key`, `otp`, `user_id`, `status`, `type`, `what`, `mailid`, `timestamp`) VALUES ('24', 'a39a7a4e4f47eb5be8591ebf40a78cc0', '5129', '19', '1', 'upload', 'none', '0', '2017-07-02 20:02:06');
INSERT INTO `session` (`session_id`, `session_key`, `otp`, `user_id`, `status`, `type`, `what`, `mailid`, `timestamp`) VALUES ('25', 'f277e994e7a51ebe924e0368906c1cce', '2159', '20', '1', 'download', 'none', '46', '2017-07-02 20:11:36');


#
# TABLE STRUCTURE FOR: user
#

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `lname` varchar(255) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `image` varchar(255) NOT NULL DEFAULT '',
  `department` varchar(255) DEFAULT NULL,
  `type` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  `status` int(11) NOT NULL COMMENT '0-pending; 1-accpeted;2-registeration pending; 3 inactive by admin',
  `package_id` int(11) NOT NULL DEFAULT '1',
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `temppass` varchar(200) NOT NULL,
  `package_validity` varchar(20) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=241 DEFAULT CHARSET=latin1;

INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('1', 'admin@dtransfer.in', '81dc9bdb52d04dc20036dbd8313ed055', 'Admin', 'Admin', '912242575900', 'bann.jpg', NULL, '3', '5', '1', '1', '2017-07-20 11:55:25', '', '');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('29', 'daman@afterdoor.com', '58ba7dfcfc0718df66e940a9d483b7bc', 'Daman', 'Mokha', '9729883551', '', NULL, '3', '4', '1', '1', '2016-11-14 09:53:10', '', '11-02-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('30', 'nikunjkaria@gmail.com', '63bb82b18f110b7b4d52a07cab2e406a', 'Nikunj', 'Karia', '9729883551', '', '', '3', '6', '1', '1', '2017-06-26 15:43:08', '', '11-02-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('33', 'info@afterdoor.com', 'fc7c0f1c834878f94e88258af2690d3e', '', '', '', '', '', '1', '0', '2', '1', '2016-11-14 16:42:06', '', '12-02-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('38', 'lijot97@rediffmail.com', 'aa1cbddbb1667f7227bcfdb25772f85c', 'lijot', 'thomas', '9820815063', '', NULL, '1', '4', '1', '1', '2016-11-17 09:49:10', '', '15-02-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('39', 'mailtome.rb@gmail.com', '1597cf70fbdaad1589805168b7d8038c', 'kaushik ', 'lakshmanan', '9884748777', '', NULL, '1', '4', '1', '1', '2016-11-21 06:29:20', '', '19-02-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('42', 'devddpost@gmail.com', 'a726c5c9f772f9eddd2539c0bc89cbeb', 'DEV ', 'DD', '9820840553', '', NULL, '1', '4', '1', '1', '2016-12-14 14:35:23', '', '20-02-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('43', 'jaintushar52@gmail.com', '6a86e99a16de17578884867207d4f062', 'tushar', 'jain', '9833967307', '', NULL, '1', '4', '1', '1', '2016-11-29 18:41:24', '', '27-02-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('44', 'prerit@solworld.net', '7ef0cd461b1f7d3346dcf91f64269bf6', '', '', '', '', '', '1', '0', '2', '1', '2016-11-29 19:04:16', '', '27-02-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('45', 'kashifmulla04@gmail.com', '5cf6c8c7cae0f80bf148e3648fd0ca36', 'kashif', 'mulla', '8879441612', '', NULL, '1', '4', '1', '1', '2016-12-01 10:51:16', '', '01-03-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('46', 'swapnil.gfx@gmail.com', '9692c018c970dc90171404cbfcccdc03', 'swapnil', 'bhalerao', '9768815033', '', NULL, '1', '4', '1', '1', '2016-12-01 17:08:05', '', '01-03-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('50', 'shyam.kabe@gmail.com', 'ced1deca88a60c90d6b3a684dfec2f68', '', '', '', '', '', '1', '0', '2', '1', '2016-12-13 15:36:55', '', '13-03-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('51', 'shyam.kabe@gmail.cm', '9e4ecc59e58af7c3e6fdd8cccb2f81a2', '', '', '', '', '', '1', '0', '2', '1', '2016-12-13 15:38:03', '', '13-03-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('52', 'ushameed2002@yahoo.com', 'f0dc92c5936efa92d97a11ff471dc694', 'SHAHUL', 'HAMEED', '9821188329', '', NULL, '1', '4', '1', '1', '2016-12-13 17:03:38', '', '13-03-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('55', 'rbhowmik313@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 'Rajib', 'Bhowmik', '7303166353', '', NULL, '1', '4', '1', '1', '2016-12-13 17:54:31', '', '13-03-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('58', 'vidushi.goel@maxusglobal.com', '7a1396039d60a8f3474ec36d11f68cfc', '', '', '', '', '', '1', '0', '2', '1', '2016-12-16 12:32:33', '', '16-03-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('59', 'jennifer.rodrigues@maxusglobal.com', '5ed9e75b6153801770a6490db2fcc960', '', '', '', '', '', '1', '0', '2', '1', '2016-12-16 12:32:41', '', '16-03-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('66', 'anisha.jain1911@gmail.com', '9404ae8f07f193e34a72f38125d49df8', '', '', '', '', '', '1', '0', '2', '1', '2016-12-24 12:54:26', '', '24-03-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('67', 'kaushiklakshminarasimhan@gmail.com', 'bbd8d3c351b71fc9fa02ee204485ef37', '', '', '', '', '', '1', '0', '2', '1', '2016-12-24 12:54:38', '', '24-03-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('69', 'singhakey47@gmail.com', '8459ff939b6be1ea635c60b1f3e90790', 'singh', 'akey ', '9930466747', '', NULL, '1', '4', '1', '1', '2016-12-26 15:48:25', '', '26-03-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('70', 'samreendingankar91@gmail.com', '176ac24d42807d91908e642690dd3e88', '', '', '', '', '', '1', '0', '2', '1', '2016-12-26 19:18:59', '', '26-03-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('71', 'abhinav.shrivastava345@gmail.com', '6a5018f0e48ba3d4189a7db7570d463b', 'Rishu', 'Shukla', '9773910562', '', '', '1', '0', '1', '1', '2016-12-27 13:41:16', '', '26-03-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('72', 'rudolf.dsa@shelroymedia.com', 'a745db267dd3b8eefde30e37a43eb2ec', '', '', '', '', '', '1', '0', '2', '1', '2016-12-26 19:49:10', '', '26-03-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('73', 'jennifershelroy@gmail.com', '908c62b5731f625f43a12d0199555211', 'jennifer', 'Tauro', '9833555074', '', '', '1', '0', '1', '1', '2016-12-27 15:26:44', '', '26-03-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('74', 'tejas121190@gmail.com', '95c390b1107bd31f7b89660adecae8c8', '', '', '', '', '', '1', '0', '2', '1', '2016-12-27 16:42:41', '', '27-03-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('75', 'kordelalit@yahoo.com', '55587bac1648d0f274ca85a5e076e428', '', '', '', '', '', '1', '0', '2', '1', '2016-12-27 16:54:43', '', '27-03-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('77', 'greshwal@gmail.com', 'b0e9af5d44db9c7124a82e2d9242cb26', 'ganesh', 'reshwal', '9970934234', '', NULL, '1', '4', '1', '1', '2016-12-30 12:19:01', '', '30-03-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('81', 'arya gupta', '894fdff42c90b845164b4182a6835c47', '', '', '', '', '', '1', '0', '2', '1', '2016-12-30 17:05:26', '', '30-03-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('82', 'asok@toonzanimationindia.com', '98af7adfb2766df0ffb2c765b424cc00', 'Asokan', 'KR', '9847701380', '', NULL, '1', '4', '1', '1', '2016-12-30 17:13:48', '', '30-03-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('84', 'ketan@balajitelefilms.com', '990d7384dd3f9f3749e38539cfd2b590', '', '', '', '', '', '1', '0', '2', '1', '2016-12-30 17:35:21', '', '30-03-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('85', 'anish@toonzanimationindia.com', 'fd9a9d0851f4e5ac0ff42f3790e82ba7', '', '', '', '', '', '1', '0', '2', '1', '2017-01-01 12:02:58', '', '01-04-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('86', 'shoeb.hu', '9434a8c9c276b045598c7a0c5fdd4d3b', '', '', '', '', '', '1', '0', '2', '1', '2017-01-05 18:27:45', '', '05-04-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('88', 'ashok@flyingtoads.com', '245addd142e42c500c707c31d0bb645f', '', '', '', '', '', '1', '0', '2', '1', '2017-01-10 11:45:07', '', '10-04-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('91', 'ushameed2002@gmail.com', 'f243b2323e6008e0229747a2c0557b30', '', '', '', '', '', '1', '0', '2', '1', '2017-01-12 18:26:26', '', '12-04-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('93', 'kuttypadmini@gmail.com', 'fb872cf94a696b811b34c63e7b95a31f', '', '', '', '', '', '1', '0', '2', '1', '2017-01-14 15:22:51', '', '14-04-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('95', 'shivngibaabar@gmail.com', '71b53f11bc182bb6fe531a760f3a2a00', '', '', '', '', '', '1', '0', '2', '1', '2017-01-14 17:18:44', '', '14-04-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('96', 'shadab.peshimam@balajitelefilms.com', '97b141b46310bba1f843e891ef30aa36', '', '', '', '', '', '1', '0', '2', '1', '2017-01-14 17:18:56', '', '14-04-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('97', 'karan.singh@balajitelefilms.com', 'd14fc3b7eeff21e92399762a33349be7', '', '', '', '', '', '1', '0', '2', '1', '2017-01-14 17:19:03', '', '14-04-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('98', 'ganesh@flyingtoads.com', 'a4e6d1ffa0deb5786cc659211967146d', '', '', '', '', '', '1', '0', '2', '1', '2017-01-17 18:22:21', '', '17-04-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('100', 'nihal.kotian@mayadigitalstudios.com', '3df436f85c318cf2eeb78385212aa39f', '', '', '', '', '', '1', '0', '2', '1', '2017-01-17 18:43:30', '', '17-04-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('101', 'devdatta.potnis@cosmos-maya.com', 'cb50610753e75369cb91abe628ac0803', '', '', '', '', '', '1', '0', '2', '1', '2017-01-17 18:43:39', '', '17-04-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('102', 'abbas.sayed@mayadigitalstudios.com', '10d135913084f7fba018d42d47a2a50d', '', '', '', '', '', '1', '0', '2', '1', '2017-01-17 18:43:47', '', '17-04-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('103', 'poonam.palnitkar@mayadigitalstudios.com', 'c781ef2f08df6cd7913281df2262a5ef', '', '', '', '', '', '1', '0', '2', '1', '2017-01-17 18:43:56', '', '17-04-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('104', 'devdatta.waghmare@mayadigitalstudios.com', 'b1614bc319f3cc311377308377f310f5', '', '', '', '', '', '1', '0', '2', '1', '2017-01-20 20:34:24', '', '20-04-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('106', 'ushameed2002@gmai.com', '73d9d68c7012f94c060803a587b05cdf', '', '', '', '', '', '1', '0', '2', '1', '2017-01-25 15:10:03', '', '25-04-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('107', 'kamna@solworld.net', 'f01d472128f8856ada52016b3b7714bf', 'kamna', 'menezes', '9821218328', '', '', '1', '0', '1', '1', '2017-01-30 12:58:13', '', '25-04-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('108', 'fazila@solworld.net', '850aa1ca666fe7913151c84443ff0fa0', '', '', '', '', '', '1', '0', '2', '1', '2017-01-25 15:51:07', '', '25-04-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('109', 'ambershri62@gmail.com', '022e86a7c8ad269e0c3551d140b28f03', '', '', '', '', '', '1', '0', '2', '1', '2017-01-25 15:51:16', '', '25-04-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('110', 'sandeep@solworld.net', '7d699c911f937772fe68879daa723905', '', '', '', '', '', '1', '0', '2', '1', '2017-01-25 15:51:23', '', '25-04-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('111', 'samreendingankar2016@gmail.com', 'dd2bd2e73b23a3b93e77086bc1f91520', '', '', '', '', '', '1', '0', '2', '1', '2017-01-30 14:42:09', '', '30-04-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('112', 'rnjpost@gmail.com', 'e045ffc046f29f411b10f5cf96aa6da0', 'Jitendra ', 'Yadav', '9867272973', '', '', '1', '0', '1', '1', '2017-01-30 15:03:12', '', '30-04-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('113', 'tanveer@theding.in', 'f3241af5f0eef4b7f6f8a20c1b5608c2', '', '', '', '', '', '1', '0', '2', '1', '2017-01-30 15:10:54', '', '30-04-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('114', 'dipika@theding.in', '2bd91b0c75f7f6360c600af535a4775a', '', '', '', '', '', '1', '0', '2', '1', '2017-01-30 15:11:03', '', '30-04-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('117', 'nachiket pantvaidya <nachiket.pantvaidya@altdigita', 'e21553a3aad67e7caff868e0e780cdb5', '', '', '', '', '', '1', '0', '2', '1', '2017-02-07 12:43:39', '', '08-05-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('120', 'parakram07sunny@gmail.com', '519cc9cd62f0b06cffb92f2bb7587b64', '', '', '', '', '', '1', '0', '2', '1', '2017-02-15 21:17:54', '', '16-05-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('122', 'abhishek.bhoyar6691@gmail.com', '1f78119b5739b8c30aa5350c5b0a30f6', 'Abhishek', 'Bhoyar', '8983702899', '', NULL, '1', '4', '1', '1', '2017-02-16 11:50:13', '', '17-05-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('123', 'ajayfilmeditor@gmail.com', '40a331e689c36f5b289ff60eb0970e97', 'ajay', 'sharma', '9819502708', '', '', '1', '0', '1', '1', '2017-02-16 16:32:21', '', '17-05-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('124', 'kaushikiakshminarasimhan@gmail.com', '7b7f8ab8fc29fb30f212801b2e93ac0a', '', '', '', '', '', '1', '0', '2', '1', '2017-02-16 13:57:22', '', '17-05-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('125', 'mrinalini.khanna@endemolshine.co.in', 'df8097928ba3ef5c365df8b829a109cf', '', '', '', '', '', '1', '0', '2', '1', '2017-02-18 10:00:03', '', '19-05-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('126', 'samar@samarkhan.com', '9c5a5a8bb3604661eddff7f36df595c9', '', '', '', '', '', '1', '0', '2', '1', '2017-02-18 10:00:21', '', '19-05-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('127', 'nbr.patra@endemolshine.co.in', '5b1bf699f77fb7c7fdfe6ff9d278c6ef', '', '', '', '', '', '1', '0', '2', '1', '2017-02-18 10:00:37', '', '19-05-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('128', 'gundeepsingh.kohli@endemolshine.co.in', 'fbb0664ff485d65eb61ee0f6d36d4a12', '', '', '', '', '', '1', '0', '2', '1', '2017-02-18 10:00:53', '', '19-05-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('129', 'prashantbhatt47@gmail.com', '8ab0b4ecc974fd5217db69576ca7829a', 'Prashant ', 'Bhatt', '9619990115', '', '', '1', '0', '1', '1', '2017-02-18 21:19:21', '', '19-05-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('130', 'creative.attract@gmail.com', 'bf8331f241756059fb213f08d94ad782', '', '', '', '', '', '1', '0', '2', '1', '2017-02-18 16:08:10', '', '19-05-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('132', 'tanveer <tanveer@theding.in>', 'b20a3c28897eb53229c046c1af5a11e6', '', '', '', '', '', '1', '0', '2', '1', '2017-02-21 18:58:19', '', '22-05-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('133', 'ouansol@gmail.com', '531b331818dcb5b309a1cde3b1d80628', '', '', '', '', '', '1', '0', '2', '1', '2017-02-21 19:41:03', '', '22-05-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('134', 'lakshmi28.singh@gmail.com', '7a70f4e1eafd07a9cb1a4328c5d47a37', '', '', '', '', '', '1', '0', '2', '1', '2017-02-22 19:03:16', '', '23-05-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('135', 'mfrancois@xilam.com', '2ff8aebed094fe2ae5b833303be7c471', '', '', '', '', '', '1', '0', '2', '1', '2017-02-23 18:31:24', '', '24-05-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('136', 'acolle@xilam.com', 'aeaf1a4fc330e9bf478481d57af4a178', '', '', '', '', '', '1', '0', '2', '1', '2017-02-23 18:31:33', '', '24-05-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('137', 'gfittante@xilam.com', '10f5cfc11b1b7111e02617889f38e9d1', '', '', '', '', '', '1', '0', '2', '1', '2017-02-23 18:31:40', '', '24-05-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('138', 'rahul.bhatia@bolmedia.in', 'f86687ab44ad06632a7f027c37e5cf07', '', '', '', '', '', '1', '0', '2', '1', '2017-02-24 09:52:53', '', '25-05-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('139', 'rajesh.nair@bolmedia.in', '250f6360a3977f08743a004d9b783008', 'Rajesh', 'Nair', '9871397488', '', '', '1', '0', '1', '1', '2017-02-24 11:10:23', '', '25-05-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('141', 'kaushiklakshminarasimhan@gmail.com mailtome.rb@gmail.com ', 'ffe39a737db41e802fa541505d7ae866', '', '', '', '', '', '1', '0', '2', '1', '2017-03-06 11:10:09', '', '04-06-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('143', 'info@humorbeings.in', '7066f9e53f521392f22cdca1afef2b63', 'Nitin ', 'Gupta ', '9873711197', '', NULL, '1', '4', '1', '1', '2017-03-07 16:11:12', '', '05-06-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('144', 'appurv.gupta@gmail.com', 'e8dc4081b13434b45189a720b77b6818', 'Appurv ', 'Gupta', '9718280887', '', NULL, '1', '4', '1', '1', '2017-03-07 16:19:02', '', '05-06-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('145', 'vasanth@evam.in', '3370b6b7f24b0dac76f3df456ca02699', 'Vasanth', 'Subramaniam', '9620999202', '', NULL, '1', '4', '1', '1', '2017-03-17 22:10:14', '', '15-06-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('146', 'dr.jagdishc@ymail.com', '094c23ad084f8aed2aa55c547a12eb74', 'Jagdish', 'Chaturvedi', '9650928582', 'Jagdish_profile_pic_stand_up_comedy_.jpg', NULL, '1', '4', '1', '1', '2017-03-18 10:11:03', '', '16-06-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('148', 'sham.kabe@gmail.com', '2c3d10b626b60fe4d4c8143b5ea8ecdf', '', '', '', '', '', '1', '0', '2', '1', '2017-03-21 21:32:02', '', '19-06-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('149', 'vikramjit.singh86@gmail.com', '5c42015f094bf7011aed3372271a12dd', 'Vikramjit', 'Singh', '9582548461', '', NULL, '1', '4', '1', '1', '2017-03-30 23:34:27', '', '28-06-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('150', 'khemkaran.chhabra@gmail.com', '7ee61c99440b443095fec7dff64f7aaa', '', '', '', '', '', '1', '0', '2', '1', '2017-04-03 17:01:21', '', '02-07-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('151', 'aarizmeer@gmail.com', '26b47461aa5d9fe1f2ac62983ee18ba8', 'Aariz', 'Saiyed', '9998128208', '', NULL, '1', '4', '1', '1', '2017-04-04 15:52:29', '', '03-07-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('152', 'thecomedyfactoryindia@gmail.com', '7888e73f486ad8d5533b2b6329f5df84', '', '', '', '', '', '1', '0', '2', '1', '2017-04-04 16:37:15', '', '03-07-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('153', 'thecomedyfactoryindia@gmai.com', '70d067a7607d5f99da1cd2434b146d6b', '', '', '', '', '', '1', '0', '2', '1', '2017-04-08 17:39:27', '', '07-07-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('154', 'sandeepkumar.gupta@altgidital.in', 'c364fb81fae7eaa424baaa62c493b6c3', 'sandeepkumar', 'gupta', '9167056090', '', NULL, '1', '4', '0', '1', '2017-04-10 22:20:26', '', '09-07-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('156', 'balajipost308@gmail.com', '9fedc27cbe459a8a1e5ba02a844614be', 'balaji', 'telefilms', '9819051564', '', NULL, '1', '4', '1', '1', '2017-04-10 23:14:48', '', '09-07-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('158', 'rishu.shukla@altdigital.com', '9bbf040f5178a06bd58e88c71695ebd1', 'RAVI', 'BHATTARAI', '9820446323', '', '', '1', '0', '1', '1', '2017-04-11 11:08:08', '', '10-07-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('159', 'post.technical@balajitelefilms.com', '6fdab6c6970ec276976041afed2d0e96', '', '', '', '', '', '1', '0', '2', '1', '2017-04-11 01:21:44', '', '10-07-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('160', 'mohitv1988@gmail.com', 'a6655c99eebf73de5f9e6338932cb146', 'Mohit', 'Varshney', '9820970892', '', NULL, '1', '4', '1', '1', '2017-04-11 02:04:01', '', '10-07-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('162', 'ravi@balajitelefilms.com', '9d179db6cfcb59504f5f68af03d8e237', '', '', '', '', '', '1', '0', '2', '1', '2017-04-13 19:22:10', '', '12-07-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('163', 'khamma@balajitelefilms.com', 'be047851d97506885b99bddfa7a13360', '', '', '', '', '', '1', '0', '2', '1', '2017-04-13 19:22:18', '', '12-07-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('164', 'ganesh@balajitelefilms.com', 'fbb6db286f32726ee71e47630ddce12d', '', '', '', '', '', '1', '0', '2', '1', '2017-04-13 19:22:26', '', '12-07-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('165', 'jo', 'e9248d38e812adecb595032a3bc0bb56', '', '', '', '', '', '1', '0', '2', '1', '2017-04-15 01:01:12', '', '14-07-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('166', 'mitesh@wrd.co.in', '3d10319094a535c5069f3835858640ae', '', '', '', '', '', '1', '0', '2', '1', '2017-04-20 16:38:04', '', '19-07-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('169', 'saumitra.raj@olacabs.com', 'c063b2d930b19b8a378ea05c38936252', '', '', '', '', '', '1', '0', '2', '1', '2017-04-26 19:36:38', '', '25-07-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('170', 'samar.haldey@olacabs.com', 'e867df3b2f3d5c9efc36606d6474e3a5', '', '', '', '', '', '1', '0', '2', '1', '2017-04-26 20:33:53', '', '25-07-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('171', 'prayana.naithani@altdigital.com', 'f72f880605748d5479bf248a1abc90c8', '', '', '', '', '', '1', '0', '2', '1', '2017-04-30 20:24:47', '', '29-07-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('172', 'jashan.dullat@olacabs.com', '25748174714fde93cd053b73fd6ca011', 'Jashan', 'Dullat', '9855553717', '', '', '1', '0', '1', '1', '2017-05-02 10:20:36', '', '29-07-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('173', 'manishkumar@afterdoor.com', '81dc9bdb52d04dc20036dbd8313ed055', 'manish', 'kumar', '8529559694', '', NULL, '1', '4', '1', '1', '2017-05-02 15:39:53', '', '30-07-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('176', 'madhumita.pathak@olacabs.com', 'c54990a509827f7380bce0bea3b48e4c', '', '', '', '', '', '1', '0', '2', '1', '2017-05-03 18:50:53', '', '01-08-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('179', 'ajay@comedymunch.com', 'fb4eaa218bb72cd86d44890dd91767b7', 'ajay', 'singh', '9990675957', '', NULL, '1', '4', '1', '1', '2017-05-05 13:33:28', '', '03-08-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('182', 'amarkargutkar@gmail.com', '50bd473566076f6861843f429e4a1e9b', '', '', '', '', '', '1', '0', '2', '1', '2017-05-15 08:57:44', '', '13-08-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('186', 'abhijit.sen@di5global.com', '08c9798393cf7ef559014d418a6a5cd9', '', '', '', '', '', '1', '0', '2', '1', '2017-05-17 19:00:08', '', '15-08-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('187', 'subhash@lemon-group.biz', '556890ff151399942d4994fa4d47fc0f', '', '', '', '', '', '1', '0', '2', '1', '2017-05-17 19:00:17', '', '15-08-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('189', 'anish@wrd.co.in', 'e24fe09e559169a1300b13757b4eef65', '', '', '', '', '', '1', '0', '2', '1', '2017-05-18 12:13:39', '', '16-08-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('190', 'njoshi@autumnworldwide.com', '18f45572694928dc011d88e45b270b23', '', '', '', '', '', '1', '0', '2', '1', '2017-05-18 12:37:35', '', '16-08-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('191', 'mncotha@autumnworldwide.com', '1b3333be1f0324be06f4c62d0bab2617', '', '', '', '', '', '1', '0', '2', '1', '2017-05-18 12:37:43', '', '16-08-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('192', 'kkumar@autumnworldwide.com', 'b8bfbbe9eac5b484647aace743b7161f', '', '', '', '', '', '1', '0', '2', '1', '2017-05-18 12:37:51', '', '16-08-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('193', 'renuka@wrd.co.in', 'fccd7c0b758a9343cb2d016ddda42933', '', '', '', '', '', '1', '0', '2', '1', '2017-05-18 16:53:29', '', '16-08-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('195', 'kunj.adhiya@gravicks.com', '87f1fa2e96ac98e7c63f3ebb32882c7b', '', '', '', '', '', '1', '0', '2', '1', '2017-05-23 18:53:28', '', '21-08-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('196', 'lordsvision9@gmail.com', '9538e7b8f9ff7e8de609b055d6831906', 'PUNEET ', 'Raajpal ', '9780354315', '', '', '1', '0', '1', '1', '2017-05-25 16:29:54', '', '23-08-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('197', 'abbas.khalooi@gmail.com', 'cc0fa5e0cbb0d97c9576b5c637fae0e1', '', '', '', '', '', '1', '0', '2', '1', '2017-05-25 16:27:42', '', '23-08-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('198', 'piiyush@muvizz.com', '489ae052595b22bbeac4014d98659f32', '', '', '', '', '', '1', '0', '2', '1', '2017-05-25 16:27:50', '', '23-08-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('199', 'saugata_nandi@yahoo.com', '8305fa4e85975d081da21dfea8ada329', '', '', '', '', '', '1', '0', '2', '1', '2017-05-25 19:34:56', '', '23-08-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('200', 'writuparna.81@gmail.com', '64c23ed82da6b327dc7abc5f15458e5d', '', '', '', '', '', '1', '0', '2', '1', '2017-05-25 19:35:16', '', '23-08-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('201', 'sourav.ghosh2006@gmail.com', 'cae383b47ded4a90afe45e2a140410ba', 'Sourav ', 'Ghosh', '9632860891', '', NULL, '1', '4', '1', '1', '2017-05-25 20:58:34', '', '23-08-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('202', 'shikha.sharma@verse.in', '1bf4cc45d38b4792f7e870fadb003b4c', '', '', '', '', '', '1', '0', '2', '1', '2017-05-26 16:06:47', '', '24-08-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('203', 'pankaj.malani@verse.in', 'e7502b78fceb3cb960397fe787256a1a', '', '', '', '', '', '1', '0', '2', '1', '2017-05-26 16:06:59', '', '24-08-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('204', 'xxxaltpost@gmail.com', '1d9c975fe152791418cf4ede0f8fd5f6', 'XXX', 'ALT', '9820840553', '', NULL, '1', '4', '1', '1', '2017-05-27 23:33:57', '', '25-08-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('205', 'anuj.s@comedymunch.com', '148dd50bb5b76203252c994034d68498', '', '', '', '', '', '1', '0', '2', '1', '2017-05-30 11:06:18', '', '28-08-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('207', 'rakeshrishu.m@gmail.com', '720cef0947e6511ead2548fe61d3059b', '', '', '', '', '', '1', '0', '2', '1', '2017-06-01 18:14:38', '', '30-08-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('208', 'nitin.fcp@gmail.com', 'ead9af0f3c67c07ed1dcaa23ded235e6', '', '', '', '', '', '1', '0', '2', '1', '2017-06-01 18:14:50', '', '30-08-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('209', 'ketkib308@gmail.com', '734053f9960e37b85a2b68837c545528', '', '', '', '', '', '1', '0', '2', '1', '2017-06-01 18:14:58', '', '30-08-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('210', 'oswin.reveredo619@gmail.com', '1b26b8d1f6f79799341971a355fe09ce', '', '', '', '', '', '1', '0', '2', '1', '2017-06-01 18:15:04', '', '30-08-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('211', 'sabahdalvi68@gmail.com', '33748dd094cfed77da0395b9ee68f08b', '', '', '', '', '', '1', '0', '2', '1', '2017-06-02 17:43:24', '', '31-08-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('212', 'anirban.dasgupta5@gmail.com', '0fe0e33127270f9e3d9e5dcbe24e55c0', 'Anirban', 'Dasgupta', '9836887326', '', NULL, '1', '4', '1', '1', '2017-06-06 01:44:00', '', '04-09-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('213', 'dhimanerdinkaal.post@gmail.com', '3d56ca439b762cd96b2ee4f2309d5cca', 'ASHIM', 'MURSHED', '9836434222', '', NULL, '1', '4', '1', '1', '2017-06-07 11:14:53', '', '05-09-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('214', 'anmolsingh3012@gmail.com', '73ab9d471d607b10d01348ab491a3af9', '', '', '', '', '', '1', '0', '2', '1', '2017-06-08 16:09:54', '', '06-09-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('215', 'vgworkings@gmail.com', 'd44f9514cbf066118cbcf09728656740', '', '', '', '', '', '1', '0', '2', '1', '2017-06-08 16:10:02', '', '06-09-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('216', 'narottam54321@gmail.com', '2563cf30207bab240a97675edf8d1fca', 'Narottam', 'Kumar', '7045836101', '', '', '1', '0', '1', '1', '2017-06-24 22:06:13', '', '06-09-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('217', 'shivangi <shivngibaabar@gmail.com>', '7a8226821c4d20db368ecc2c81fd7996', '', '', '', '', '', '1', '0', '2', '1', '2017-06-08 20:06:02', '', '06-09-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('218', 'subhashni143@gmail.com', '79e4b05fc8f12c70115e4ce9d8aa4633', '', '', '', '', '', '1', '0', '2', '1', '2017-06-08 20:06:10', '', '06-09-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('219', 'hamavvand chwda <hamavvand@balajitelefilms.com>', 'e8f69e0acd5854574526d93056207547', '', '', '', '', '', '1', '0', '2', '1', '2017-06-08 20:06:18', '', '06-09-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('220', 'hamavvand@balajitelefilms.com', 'd3101293897e0f726ece7ea524c4440e', '', '', '', '', '', '1', '0', '2', '1', '2017-06-08 20:31:45', '', '06-09-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('221', 'shridhar.nagolkar@gmail.com', '20abaf8cea8e6c255ed808fd6254dc91', '', '', '', '', '', '1', '0', '2', '1', '2017-06-08 20:31:52', '', '06-09-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('222', 'ashim.director2017@gmail.com', '0887ffae21c7088bf8417182a9cd3635', '', '', '', '', '', '1', '0', '2', '1', '2017-06-13 20:03:55', '', '11-09-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('225', 'parthiv.bhavsar@vodafone.com', '36f36f287a849fede78fa5c71967358b', '', '', '', '', '', '1', '0', '2', '1', '2017-06-21 16:17:48', '', '19-09-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('227', 'madhumita pathak <madhumita.pathak@olacabs.com>', '15f6ddeb9a26bccab101d75ec7074860', '', '', '', '', '', '1', '0', '2', '1', '2017-07-10 17:04:07', '', '08-10-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('229', 'asia.mukadam@dolby.com', 'ec13340c38cce9f1267dead4e8ce5795', '', '', '', '', '', '1', '0', '2', '1', '2017-07-10 17:43:37', '', '08-10-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('230', 'asif.mukadam@dolby.com', '43321dfabba00b9bd484c913beb4e48a', 'Asif', 'Mukadam', '9820359100', '', '', '1', '0', '1', '1', '2017-07-10 17:52:22', '', '08-10-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('231', 'myohofilmsindia@gmail.com', '416cd126d96d7f45f34740e1b063cb9c', 'Myoho', 'Films', '9769473082', '', NULL, '1', '4', '1', '1', '2017-07-11 14:27:02', '', '09-10-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('232', 'sanjeet.das@primefocus.com', 'b4e9a449d775a5868f4f5d4cdf583dcb', '', '', '', '', '', '1', '0', '2', '1', '2017-07-11 19:34:50', '', '09-10-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('233', 'amit.das@primefocus.com', '733f8cf485215283263ec53845865a21', '', '', '', '', '', '1', '0', '2', '1', '2017-07-11 19:34:59', '', '09-10-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('234', 'mansi.darbar@altdigital.com', 'ced7263e185853a0e4acaeb1564152e2', '', '', '', '', '', '1', '0', '2', '1', '2017-07-11 19:35:08', '', '09-10-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('239', 'sundeepshawarma@gmail.com', '58629c0886121877873f45726cf67f98', 'Sundeep', 'Sharma', '9619928934', '', NULL, '1', '4', '1', '1', '2017-07-14 19:28:41', '', '12-10-2017');
INSERT INTO `user` (`user_id`, `email`, `password`, `name`, `lname`, `phone`, `image`, `department`, `type`, `group_id`, `status`, `package_id`, `timestamp`, `temppass`, `package_validity`) VALUES ('240', 'vishal.bijlani@balajitelefilms.com', '01e70ef35b60ca856a22d974811c9611', 'Vishal', 'bijlani', '2242575918', '', NULL, '2', '6', '1', '1', '2017-07-14 20:50:34', '', '');


