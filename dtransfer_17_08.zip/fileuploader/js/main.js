/*
 * jQuery File Upload Plugin JS Example
 * https://github.com/blueimp/jQuery-File-Upload
 *
 * Copyright 2010, Sebastian Tschan
 * https://blueimp.net
 *
 * Licensed under the MIT license:
 * http://www.opensource.org/licenses/MIT
 */

/* global $, window */
function bytesToSize(bytes,decimals) {
   if(bytes == 0) return '0 Byte';
   var k = 1000; // or 1024 for binary
   var dm = decimals + 1 || 3;
   var sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
   var i = Math.floor(Math.log(bytes) / Math.log(k));
   return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) ; //+ ' ' + sizes[i];
};



var data = [],
totalPoints = 300;
var bandwidth=0;
        function getRandomData(bandwidth) {

            if (data.length > 0)
                data = data.slice(1);

            // Do a random walk

            while (data.length < totalPoints) {

                var prev = data.length > 0 ? data[data.length - 1] : 50,
                    y = bandwidth;

                /*if (y < 0) {
                    y = 0;
                } else if (y > 100) {
                    y = 100;
                }*/

                data.push(y);
            }

            // Zip the generated y values with the x values

            var res = [];
            for (var i = 0; i < data.length; ++i) {
                res.push([i, data[i]])
            }

            return res;
        }



$(function () {
    'use strict';

var plot = $.plot("#containergraph", [ getRandomData() ], {
            series: {
                shadowSize: 0,   // Drawing is faster without shadows
                lines: { show: true },
            },
            yaxis: {
                show: true,
            },
            xaxis: {
                show: false,
            }
        });

        function update(bandwidth) {

            plot.setData([getRandomData(bandwidth)]);

            // Since the axes don't change, we don't need to call plot.setupGrid()
            plot.setupGrid();
            plot.draw();
            //setTimeout(update, 1000);
        }

        update(bandwidth);


var total=0;
$('#fileupload').bind('fileuploadchange', function (e, data) {

    //alert(dynamicchunk);
});
    
    // Initialize the jQuery File Upload widget:
    $('#fileupload').fileupload({
        // Uncomment the following to send cross-domain cookies:
        //xhrFields: {withCredentials: true},
        dataType: 'json',
        url: base_url+'server/php/',
        maxChunkSize: 20000000, // 100 MB
    add: function (e, data) {
        var that = this;
        var uploadErrors = [];
        var str=$('.file_type').val();
         var tps=str.split(",");
         var ext = data.originalFiles[0].name.split('.').pop().toLowerCase();
        if($.inArray(ext, tps) == -1) {
            uploadErrors.push('Not an accepted file type');
            swal('Allowed file types are '+ str);
            return false;
        }
        $.get( base_url+'server/php/', {file: data.files[0].name}, function (result) {
            var file = result.file;
            data.uploadedBytes = file && file.size;
            $.blueimp.fileupload.prototype
                .options.add.call(that, e, data);
        });
    },
 maxRetries: 100,
    retryTimeout: 500,
    fail: function (e, data) {
        // jQuery Widget Factory uses "namespace-widgetname" since version 1.10.0:
        var fu = $(this).data('blueimp-fileupload') || $(this).data('fileupload'),
            retries = data.context.data('retries') || 0,
            retry = function () {
                $.get( base_url+'server/php/', {file: data.files[0].name})
                    .done(function (result) {
                        var file = result.file;
                        data.uploadedBytes = file && file.size;
                        // clear the previous data:
                        data.data = null;
                        data.submit();
                    })
                    .fail(function () {
                        fu._trigger('fail', e, data);
                    });
            };
        if (data.errorThrown !== 'abort' &&
                data.uploadedBytes < data.files[0].size &&
                retries < fu.options.maxRetries) {
            retries += 1;
            data.context.data('retries', retries);
            window.setTimeout(retry, retries * fu.options.retryTimeout);
            return;
        }
        data.context.removeData('retries');
        $.blueimp.fileupload.prototype
            .options.fail.call(this, e, data);
    }
    });

   

var fileCount = 0, fails = 0, successes = 0;
var _totalCountOfFilesToUpload = -1;

$('#fileupload').bind('fileuploaddone', function (e, data) {

    if (_totalCountOfFilesToUpload < 0) {
         _totalCountOfFilesToUpload = data.getNumberOfFiles();
    }
    fileCount++;
    successes++;
    console.log(data.getNumberOfFiles() );
    if (fileCount === _totalCountOfFilesToUpload) {
        console.log('all done, successes: ' + successes + ', fails: ' + fails);
        $(".transparacy").css({'display': 'block'});
        $(".loader").css({'display': 'block'});
        // refresh page
         setTimeout(function(){
            var sentdata=$('#fileupload').serialize();
             $.ajax({
                    url:base_url+'user/uploadfile',
                    type:'POST',
                    data:sentdata,
                    success:function(result){
                        $("#fileupload").html(result).show(1000);
                        $("#messagewarning").hide();
                        $(".transparacy").css({'display': 'none'});
                        $(".loader").css({'display': 'none'});
                    }

            });

        }, 2000);
    }
}).bind('fileuploadfail', function(e, data) {
    fileCount++;
    fails++;
    if (fileCount === _totalCountOfFilesToUpload) {
        console.log('all done, successes: ' + successes + ', fails: ' + fails);
        // refresh page
        //location.reload();
    }
});

    // Enable iframe cross-domain access via redirect option:
    $('#fileupload').fileupload(
        'option',
        'redirect',
        window.location.href.replace(
            /\/[^\/]*$/,
            '/cors/result.html?%s'
        )
    );


 
   $('#fileupload').bind('fileuploadprogressall', function (e, data) {
        //console.log(data);
        //$(".listbitrate ul").append('<li>'+bytesToSize(data.bitrate,1)+'</li>');

       update(bytesToSize(data.bitrate,1));
        
    });


});//ready main
