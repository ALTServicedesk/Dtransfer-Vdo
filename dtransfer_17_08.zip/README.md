Starting GIT on 6/15/2016

* Inital upload of V 1.0